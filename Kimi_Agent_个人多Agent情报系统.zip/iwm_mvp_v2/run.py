#!/usr/bin/env python3
"""IWM v2 - 九Agent投资参谋系统入口

用法:
    python run.py init                          # 初始化系统
    python run.py morning                       # 执行早报工作流
    python run.py evening                       # 执行晚报工作流
    python run.py industry --name AI            # AI行业深度分析
    python run.py company --ticker NVDA --market US  # NVDA公司分析
    python run.py macro                         # 宏观通判分析
    python run.py timing                        # 时机分析
    python run.py cio                           # CIO汇总（需前置分析完成）
    python run.py devil                         # 反驳者审查
    python run.py reports                       # 列出历史报告
    python run.py config                        # 查看配置
    python run.py help                          # 帮助
"""
import sys
import json
import argparse
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))


def cmd_init():
    """初始化：创建默认配置和目录结构"""
    from core.config import load_config, save_config, DEFAULT_CONFIG
    from core.storage import Storage, KB, REPORTS

    # 保存默认配置
    save_config(DEFAULT_CONFIG)
    print("[OK] 配置已初始化")

    # 确保所有目录存在
    for subdir in ["industries", "companies", "macro_history", "news_history", "agent_outputs"]:
        (KB / subdir).mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    print("[OK] 目录结构已创建")
    print("\n系统初始化完成！")
    print("使用方法：告诉我你的需求，我调度Agent完成分析")


def cmd_morning():
    """执行早报工作流"""
    from scheduler import WorkflowRunner
    runner = WorkflowRunner()
    plan = runner.run_morning_workflow()
    print("="*60)
    print(f"早报工作流计划 ({plan['timestamp']})")
    print("="*60)
    for step in plan['steps']:
        print(f"  Step{step['step']}: [{step['agent']}] {step['description']}")
    print("\n请通知我执行此工作流，我将调度各Agent完成分析")
    return plan


def cmd_evening():
    """执行晚报工作流"""
    from scheduler import WorkflowRunner
    runner = WorkflowRunner()
    plan = runner.run_evening_workflow()
    print("="*60)
    print(f"晚报工作流计划 ({plan['timestamp']})")
    print("="*60)
    for step in plan['steps']:
        print(f"  Step{step['step']}: [{step['agent']}] {step['description']}")
    print("\n请通知我执行此工作流，我将调度各Agent完成分析")
    return plan


def cmd_industry(name: str):
    """行业深度分析"""
    from scheduler import WorkflowRunner
    runner = WorkflowRunner()
    plan = runner.run_industry_deep_workflow(name)
    print(f"\n行业深度分析计划: {name}")
    for step in plan['steps']:
        print(f"  Step{step['step']}: [{step['agent']}] {step['description']}")
    return plan


def cmd_company(ticker: str, market: str):
    """公司深度分析"""
    from scheduler import WorkflowRunner
    runner = WorkflowRunner()
    plan = runner.run_company_deep_workflow(ticker, market)
    print(f"\n公司深度分析计划: {ticker}.{market}")
    for step in plan['steps']:
        print(f"  Step{step['step']}: [{step['agent']}] {step['description']}")
    return plan


def cmd_reports():
    """列出历史报告"""
    from core.storage import Storage
    reports = Storage.list_reports(limit=20)
    print(f"\n历史报告 ({len(reports)}份):")
    print("-"*60)
    for r in reports:
        print(f"  {r['file']} ({r['size']} bytes)")


def cmd_config():
    """查看配置"""
    from core.config import load_config
    config = load_config()
    print(json.dumps(config, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description="IWM v2 - 九Agent投资参谋系统")
    parser.add_argument("command", choices=[
        "init", "morning", "evening", "industry", "company",
        "macro", "timing", "cio", "devil", "reports", "config", "help"
    ], help="命令")
    parser.add_argument("--name", help="行业名称（用于industry命令）")
    parser.add_argument("--ticker", help="股票代码（用于company命令）")
    parser.add_argument("--market", default="US", help="市场（US/HK/CN）")
    args = parser.parse_args()

    if args.command == "init":
        cmd_init()
    elif args.command == "morning":
        cmd_morning()
    elif args.command == "evening":
        cmd_evening()
    elif args.command == "industry":
        if not args.name:
            print("请指定行业名称: --name AI")
            return
        cmd_industry(args.name)
    elif args.command == "company":
        if not args.ticker:
            print("请指定股票代码: --ticker NVDA")
            return
        cmd_company(args.ticker, args.market)
    elif args.command == "reports":
        cmd_reports()
    elif args.command == "config":
        cmd_config()
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
