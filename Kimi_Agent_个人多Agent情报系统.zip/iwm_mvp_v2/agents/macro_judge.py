from datetime import datetime
from .agent_base import Agent


class MacroJudge(Agent):
    def __init__(self):
        super().__init__("macro_judge", "宏观通判")

    def analyze(self, context: dict) -> dict:
        """
        context: {"macro_data": [...], "date": str}
        返回: MacroAssessment结构
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "us_market": {
                    "verdict": "",
                    "score": 0,
                    "key_drivers": [],
                    "risk_flags": []
                },
                "cn_market": {
                    "verdict": "",
                    "score": 0,
                    "key_drivers": [],
                    "risk_flags": []
                },
                "global_market": {
                    "verdict": "",
                    "score": 0,
                    "key_drivers": [],
                    "risk_flags": []
                },
                "sentiment_gauge": {
                    "level": "",
                    "vix": 0,
                    "fear_greed_index": 0
                },
                "recession_probability": 0.0,
                "key_signals": [],
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        macro_data = context.get("macro_data", [])
        date = context.get("date", "")
        lines = [f"宏观数据分析 ({date})", "=" * 50]
        for item in macro_data:
            lines.append(f"- {item['name']}: {item.get('current', 'N/A')} ({item.get('note', '')})")
        lines.append("\n请基于以上数据，按照系统提示词的要求进行分析。")
        return "\n".join(lines)
