from datetime import datetime
from .agent_base import Agent


class NewsScanner(Agent):
    def __init__(self):
        super().__init__("news_scanner", "新闻扫描")

    def analyze(self, context: dict) -> dict:
        """
        context: {"news_items": [...], "date": str}
        news_item: {"title": str, "source": str, "time": str, "summary": str, "sentiment": str}
        返回: NewsScanResult结构
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "total_news": 0,
                "key_headlines": [],
                "by_category": {
                    "policy": {"count": 0, "items": [], "impact": ""},
                    "earnings": {"count": 0, "items": [], "impact": ""},
                    "macro": {"count": 0, "items": [], "impact": ""},
                    "geopolitical": {"count": 0, "items": [], "impact": ""},
                    "sector": {"count": 0, "items": [], "impact": ""},
                    "other": {"count": 0, "items": [], "impact": ""}
                },
                "sentiment_distribution": {
                    "positive": 0,
                    "neutral": 0,
                    "negative": 0
                },
                "top_risks_from_news": [],
                "top_opportunities_from_news": [],
                "overall_news_sentiment": "",
                "breaking_alerts": [],
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        news_items = context.get("news_items", [])
        date = context.get("date", "")
        lines = [f"新闻扫描分析 ({date})", "=" * 50, f"共 {len(news_items)} 条新闻\n"]
        for item in news_items:
            lines.append(
                f"[{item.get('time', '')}] {item.get('source', '')}\n"
                f"  标题: {item.get('title', '')}\n"
                f"  摘要: {item.get('summary', '')}\n"
                f"  情绪: {item.get('sentiment', 'neutral')}\n"
            )
        lines.append("\n请基于以上新闻，按照系统提示词的要求进行分类、情绪评估和重要性排序。")
        return "\n".join(lines)
