from datetime import datetime
from .agent_base import Agent


class ScenarioForecast(Agent):
    def __init__(self):
        super().__init__("scenario_forecast", "推演分析")

    def analyze(self, context: dict) -> dict:
        """
        context: {"macro_assessment": dict, "news_scan": dict, "date": str}
        返回: ScenarioForecastResult结构，包含三种情景推演
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "scenarios": {
                    "bull": {
                        "name": "乐观情景",
                        "probability": 0.0,
                        "description": "",
                        "key_assumptions": [],
                        "market_impact": {"us": "", "cn": "", "global": ""},
                        "affected_sectors": [],
                        "recommended_actions": []
                    },
                    "base": {
                        "name": "基准情景",
                        "probability": 0.0,
                        "description": "",
                        "key_assumptions": [],
                        "market_impact": {"us": "", "cn": "", "global": ""},
                        "affected_sectors": [],
                        "recommended_actions": []
                    },
                    "bear": {
                        "name": "悲观情景",
                        "probability": 0.0,
                        "description": "",
                        "key_assumptions": [],
                        "market_impact": {"us": "", "cn": "", "global": ""},
                        "affected_sectors": [],
                        "recommended_actions": []
                    }
                },
                "key_catalysts": [],
                "key_risks": [],
                "scenario_shift_triggers": [],
                "time_horizon": "",
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        macro = context.get("macro_assessment", {})
        news = context.get("news_scan", {})
        date = context.get("date", "")
        lines = [
            f"情景推演分析 ({date})",
            "=" * 50,
            "\n【宏观评估输入】",
            f"- 美股判断: {macro.get('us_market', {}).get('verdict', 'N/A')}",
            f"- A股判断: {macro.get('cn_market', {}).get('verdict', 'N/A')}",
            f"- 全球市场: {macro.get('global_market', {}).get('verdict', 'N/A')}",
            f"- 衰退概率: {macro.get('recession_probability', 'N/A')}",
            f"- 情绪水平: {macro.get('sentiment_gauge', {}).get('level', 'N/A')}",
            "\n【新闻情绪输入】",
            f"- 整体新闻情绪: {news.get('overall_news_sentiment', 'N/A')}",
            f"- 正面/中性/负面: {news.get('sentiment_distribution', {})}",
            f"- 关键风险: {news.get('top_risks_from_news', [])}",
            "\n请基于以上输入，按照系统提示词的要求进行三种情景推演（乐观/基准/悲观）。"
        ]
        return "\n".join(lines)
