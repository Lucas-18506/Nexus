from datetime import datetime
from .agent_base import Agent


class TimingAnalyst(Agent):
    def __init__(self):
        super().__init__("timing_analyst", "时机分析")

    def analyze(self, context: dict) -> dict:
        """
        context: {"watchlist": [...], "market_data": dict, "date": str}
        watchlist_item: {"ticker": str, "market": str, "price": float, "name": str}
        返回: TimingAnalysisResult结构，对关注列表中每只股票输出技术信号
        """
        prompt = self._build_prompt(context)
        watchlist = context.get("watchlist", [])
        per_stock_template = {
            ticker: {
                "ticker": ticker,
                "market": item.get("market", ""),
                "name": item.get("name", ""),
                "technical_analysis": {
                    "trend": "",
                    "trend_strength": 0,
                    "rsi": 0.0,
                    "rsi_interpretation": "",
                    "macd": {"signal": "", "histogram": 0.0, "divergence": False},
                    "moving_averages": {
                        "ma20": 0.0,
                        "ma50": 0.0,
                        "ma200": 0.0,
                        "golden_cross": False,
                        "death_cross": False
                    },
                    "bollinger_bands": {
                        "upper": 0.0,
                        "lower": 0.0,
                        "position": ""
                    },
                    "volume_analysis": {
                        "trend": "",
                        "obv_trend": "",
                        "volume_spike": False
                    },
                    "support_resistance": {
                        "nearest_support": 0.0,
                        "nearest_resistance": 0.0,
                        "key_levels": []
                    },
                    "chart_patterns": []
                },
                "entry_exit": {
                    "suggested_entry": 0.0,
                    "stop_loss": 0.0,
                    "take_profit": 0.0,
                    "risk_reward_ratio": 0.0
                },
                "timing_verdict": {
                    "action": "",
                    "urgency": "",
                    "rationale": ""
                },
                "confidence": 0.0
            }
            for ticker, item in {w["ticker"]: w for w in watchlist}.items()
        }
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "market_breadth": {
                    "advance_decline_ratio": 0.0,
                    "new_highs_new_lows": "",
                    "breadth_trend": ""
                },
                "market_timing": {
                    "overall_phase": "",
                    "seasonality": "",
                    "best_sectors_now": []
                },
                "per_stock_signals": per_stock_template,
                "top_opportunities": [],
                "top_risks": [],
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        watchlist = context.get("watchlist", [])
        market_data = context.get("market_data", {})
        date = context.get("date", "")
        lines = [
            f"时机与技术分析 ({date})",
            "=" * 50,
            f"\n【市场环境】",
            f"- 大盘趋势: {market_data.get('index_trend', 'N/A')}",
            f"- 成交量: {market_data.get('volume_status', 'N/A')}",
            f"- 波动率: {market_data.get('volatility', 'N/A')}",
            f"\n【关注列表 — {len(watchlist)} 只标的】",
        ]
        for item in watchlist:
            lines.append(
                f"- {item.get('ticker', '')} ({item.get('market', '')}): "
                f"{item.get('name', '')} @ {item.get('price', 'N/A')}"
            )
        lines.append(
            "\n请基于以上数据，对关注列表中每只标的进行技术面分析，"
            "输出入场/出场时机建议。按照系统提示词的要求输出结构化结果。"
        )
        return "\n".join(lines)
