from datetime import datetime
from .agent_base import Agent


class IndustryAnalyst(Agent):
    def __init__(self):
        super().__init__("industry_analyst", "行业分析")

    def analyze(self, context: dict, industry_name: str) -> dict:
        """
        context: {"industry_data": [...], "date": str}
        industry_name: 要分析的行业名称，如"半导体", "新能源"
        返回: IndustryAnalysisResult结构
        """
        prompt = self._build_prompt(context, industry_name)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "industry_name": industry_name,
            "analysis_prompt": prompt,
            "template": {
                "industry_overview": {
                    "name": industry_name,
                    "sector": "",
                    "lifecycle_stage": "",
                    "market_size": "",
                    "growth_rate": 0.0
                },
                "industry_health": {
                    "score": 0,
                    "trend": "",
                    "key_metrics": {}
                },
                "supply_chain": {
                    "status": "",
                    "bottlenecks": [],
                    "opportunities": []
                },
                "policy_environment": {
                    "regulatory_risk": "",
                    "policy_support": "",
                    "key_policies": []
                },
                "competitive_landscape": {
                    "concentration": "",
                    "key_players": [],
                    "competitive_dynamics": ""
                },
                "valuation": {
                    "current_pe": 0.0,
                    "historical_pe_avg": 0.0,
                    "pb_ratio": 0.0,
                    "valuation_assessment": ""
                },
                "top_stocks": [],
                "risk_factors": [],
                "investment_thesis": "",
                "verdict": "",
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict, industry_name: str) -> str:
        industry_data = context.get("industry_data", [])
        date = context.get("date", "")
        lines = [
            f"行业深度分析: {industry_name} ({date})",
            "=" * 50,
            f"\n分析目标行业: {industry_name}\n"
        ]
        for item in industry_data:
            lines.append(
                f"- {item.get('metric', '')}: {item.get('value', 'N/A')} "
                f"({item.get('note', '')})"
            )
        lines.append(
            f"\n请基于以上行业数据，对「{industry_name}」行业进行深度分析，"
            "按照系统提示词的要求输出结构化结果。"
        )
        return "\n".join(lines)
