from datetime import datetime
from .agent_base import Agent


class RiskAssessor(Agent):
    def __init__(self):
        super().__init__("risk_assessor", "风险评估")

    def analyze(self, context: dict) -> dict:
        """
        context: {
            "macro_assessment": dict,
            "news_scan": dict,
            "scenario_forecast": dict,
            "portfolio": [...],
            "date": str
        }
        返回: RiskAssessmentResult结构
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "overall_risk_level": "",
                "overall_risk_score": 0,
                "risk_matrix": {
                    "market_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "credit_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "liquidity_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "geopolitical_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "policy_regulatory_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "concentration_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    },
                    "tail_risk": {
                        "score": 0,
                        "level": "",
                        "description": "",
                        "mitigation": ""
                    }
                },
                "top_risks_ranked": [],
                "stress_test_summary": {
                    "max_drawdown_estimate": 0.0,
                    "worst_case_scenario": "",
                    "recovery_time_estimate": ""
                },
                "correlation_risk": {
                    "concentration_warning": False,
                    "highly_correlated_pairs": []
                },
                "hedging_recommendations": [],
                "risk_adjusted_position_sizing": {},
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        macro = context.get("macro_assessment", {})
        news = context.get("news_scan", {})
        scenario = context.get("scenario_forecast", {})
        portfolio = context.get("portfolio", [])
        date = context.get("date", "")
        lines = [
            f"风险评估分析 ({date})",
            "=" * 50,
            "\n【宏观风险输入】",
            f"- 衰退概率: {macro.get('recession_probability', 'N/A')}",
            f"- VIX指数: {macro.get('sentiment_gauge', {}).get('vix', 'N/A')}",
            f"- 恐惧贪婪指数: {macro.get('sentiment_gauge', {}).get('fear_greed_index', 'N/A')}",
            f"- 关键风险信号: {macro.get('key_signals', [])}",
            "\n【新闻风险输入】",
            f"- 新闻中的顶级风险: {news.get('top_risks_from_news', [])}",
            "\n【情景推演输入】",
            f"- 悲观情景概率: {scenario.get('scenarios', {}).get('bear', {}).get('probability', 'N/A')}",
            f"- 悲观情景描述: {scenario.get('scenarios', {}).get('bear', {}).get('description', 'N/A')}",
            f"\n【持仓组合】({len(portfolio)} 只标的)",
        ]
        for holding in portfolio:
            lines.append(
                f"- {holding.get('ticker', '')}: {holding.get('name', '')} "
                f"权重{holding.get('weight', 0)}%"
            )
        lines.append("\n请基于以上数据，按照系统提示词的要求进行全面风险评估。")
        return "\n".join(lines)
