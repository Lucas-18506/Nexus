from datetime import datetime
from .agent_base import Agent


class CompanyAnalyst(Agent):
    def __init__(self):
        super().__init__("company_analyst", "公司分析")

    def analyze(self, context: dict, ticker: str, market: str) -> dict:
        """
        context: {"company_data": [...], "financial_data": dict, "date": str}
        ticker: 股票代码，如 "AAPL", "00700"
        market: 市场标识，如 "US", "HK", "CN"
        返回: CompanyAnalysisResult结构
        """
        prompt = self._build_prompt(context, ticker, market)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "ticker": ticker,
            "market": market,
            "analysis_prompt": prompt,
            "template": {
                "company_profile": {
                    "name": "",
                    "ticker": ticker,
                    "market": market,
                    "sector": "",
                    "industry": "",
                    "market_cap": ""
                },
                "financial_health": {
                    "score": 0,
                    "revenue_growth": 0.0,
                    "profit_margin": 0.0,
                    "roe": 0.0,
                    "debt_to_equity": 0.0,
                    "free_cash_flow": "",
                    "assessment": ""
                },
                "valuation": {
                    "pe_ttm": 0.0,
                    "pb_ratio": 0.0,
                    "ps_ratio": 0.0,
                    "ev_ebitda": 0.0,
                    "peg_ratio": 0.0,
                    "dcf_estimate": 0.0,
                    "valuation_verdict": ""
                },
                "competitive_moat": {
                    "score": 0,
                    "moat_type": "",
                    "competitive_advantages": [],
                    "threats": []
                },
                "management_quality": {
                    "score": 0,
                    "insider_buying": False,
                    "capital_allocation": "",
                    "governance_concerns": []
                },
                "technical_signals": {
                    "trend": "",
                    "rsi": 0.0,
                    "macd_signal": "",
                    "support_level": 0.0,
                    "resistance_level": 0.0,
                    "volume_trend": ""
                },
                "earnings_outlook": {
                    "next_quarter_eps_estimate": 0.0,
                    "full_year_eps_estimate": 0.0,
                    "guidance": "",
                    "beat_probability": 0.0
                },
                "esg_score": {
                    "environmental": 0,
                    "social": 0,
                    "governance": 0,
                    "overall": 0
                },
                "catalysts": [],
                "risk_factors": [],
                "price_target": {
                    "bull": 0.0,
                    "base": 0.0,
                    "bear": 0.0,
                    "current_price": 0.0
                },
                "verdict": "",
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict, ticker: str, market: str) -> str:
        company_data = context.get("company_data", [])
        financial_data = context.get("financial_data", {})
        date = context.get("date", "")
        lines = [
            f"公司深度分析: {ticker} ({market}) — {date}",
            "=" * 50,
            f"\n分析标的: {ticker} | 市场: {market}\n"
        ]
        for item in company_data:
            lines.append(f"- {item.get('metric', '')}: {item.get('value', 'N/A')}")
        if financial_data:
            lines.append("\n【财务数据】")
            for k, v in financial_data.items():
                lines.append(f"- {k}: {v}")
        lines.append(
            f"\n请基于以上数据，对「{ticker}」（{market}市场）进行深度公司分析，"
            "按照系统提示词的要求输出结构化结果。"
        )
        return "\n".join(lines)
