from datetime import datetime
from .agent_base import Agent


class CIOSynthesizer(Agent):
    def __init__(self):
        super().__init__("cio_synthesizer", "CIO汇总")

    def analyze(self, context: dict) -> dict:
        """
        context: {
            "agent_outputs": dict,  # 所有其他Agent的输出 {agent_name: output_dict}
            "portfolio": [...],
            "constraints": dict,
            "date": str
        }
        返回: CIOSynthesisResult结构 — 汇总所有Agent分析，输出最终投资决策
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "executive_summary": {
                    "market_outlook": "",
                    "risk_level": "",
                    "recommended_action": "",
                    "key_theme": ""
                },
                "agent_consensus": {
                    "bullish_agents": [],
                    "neutral_agents": [],
                    "bearish_agents": [],
                    "dissenting_views": []
                },
                "portfolio_recommendation": {
                    "target_allocation": {
                        "equity": 0.0,
                        "bond": 0.0,
                        "cash": 0.0,
                        "alternative": 0.0
                    },
                    "sector_tilts": [],
                    "position_adjustments": [],
                    "new_positions": [],
                    "exit_positions": []
                },
                "trade_signals": {
                    "strong_buy": [],
                    "buy": [],
                    "hold": [],
                    "sell": [],
                    "strong_sell": []
                },
                "risk_management": {
                    "max_position_size": 0.0,
                    "stop_loss_policy": "",
                    "hedge_recommendation": "",
                    "cash_buffer_target": 0.0
                },
                "watchlist_update": {
                    "add": [],
                    "remove": [],
                    "monitor": []
                },
                "key_risks": [],
                "key_catalysts": [],
                "scenario_readiness": {
                    "if_bull_market": "",
                    "if_bear_market": "",
                    "if_sideways": ""
                },
                "devil_advocate_response": {
                    "concerns_acknowledged": [],
                    "mitigation_plan": "",
                    "final_stance": ""
                },
                "next_review_trigger": "",
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        agent_outputs = context.get("agent_outputs", {})
        portfolio = context.get("portfolio", [])
        constraints = context.get("constraints", {})
        date = context.get("date", "")
        lines = [
            f"CIO投资决策汇总 ({date})",
            "=" * 50,
            "\n【各Agent分析结果汇总】",
        ]
        for agent_name, output in agent_outputs.items():
            template = output.get("template", {})
            verdict_keys = [k for k in template.keys() if "verdict" in k or "level" in k]
            summary_parts = []
            for vk in verdict_keys[:3]:
                val = template.get(vk)
                if isinstance(val, dict):
                    summary_parts.append(f"{vk}={val}")
                else:
                    summary_parts.append(f"{vk}={val}")
            conf = template.get("confidence", "N/A")
            lines.append(
                f"- {agent_name}: "
                f"{', '.join(summary_parts) if summary_parts else '详见模板'} "
                f"(信心度: {conf})"
            )
        lines.extend([
            f"\n【当前持仓】({len(portfolio)} 只标的)",
        ])
        for holding in portfolio:
            lines.append(
                f"- {holding.get('ticker', '')}: {holding.get('name', '')} "
                f"权重{holding.get('weight', 0)}% 成本{holding.get('cost_basis', 'N/A')}"
            )
        if constraints:
            lines.extend([
                "\n【投资约束】",
                f"- 风险偏好: {constraints.get('risk_profile', 'N/A')}",
                f"- 最大回撤限制: {constraints.get('max_drawdown', 'N/A')}",
                f"- 现金下限: {constraints.get('min_cash', 'N/A')}",
                f"- 行业上限: {constraints.get('max_sector_weight', 'N/A')}",
            ])
        lines.append(
            "\n你作为CIO，请综合以上所有Agent的分析结果，做出最终的投资决策。"
            "考虑各Agent的共识与分歧，结合当前持仓和投资约束，"
            "按照系统提示词的要求输出结构化投资决策报告。"
        )
        return "\n".join(lines)
