from datetime import datetime
from .agent_base import Agent


class DevilAdvocate(Agent):
    def __init__(self):
        super().__init__("devil_advocate", "反驳者")

    def analyze(self, context: dict) -> dict:
        """
        context: {
            "macro_assessment": dict,
            "scenario_forecast": dict,
            "industry_analyses": [...],
            "company_analyses": [...],
            "date": str
        }
        返回: DevilAdvocateResult结构 — 对其他Agent的分析结果提出质疑和反面论证
        """
        prompt = self._build_prompt(context)
        return {
            "agent_name": self.name,
            "agent_role": self.role,
            "analysis_prompt": prompt,
            "template": {
                "challenges": {
                    "macro": {
                        "original_view": "",
                        "counter_arguments": [],
                        "blind_spots": [],
                        "confidence_override": 0.0
                    },
                    "scenarios": {
                        "original_view": "",
                        "counter_arguments": [],
                        "missed_scenarios": [],
                        "confidence_override": 0.0
                    },
                    "industries": {
                        "original_view": "",
                        "counter_arguments": [],
                        "contrarian_indicators": [],
                        "confidence_override": 0.0
                    },
                    "companies": {
                        "original_view": "",
                        "counter_arguments": [],
                        "valuation_concerns": [],
                        "confidence_override": 0.0
                    }
                },
                "contrarian_signals": [],
                "what_could_go_wrong": [],
                "groupthink_warning": False,
                "herd_behavior_analysis": "",
                "alternative_interpretations": [],
                "base_rate_neglect_flags": [],
                "recommendation": {
                    "action": "",
                    "reasoning": "",
                    "caveats": []
                },
                "overall_skepticism_score": 0,
                "confidence": 0.0
            },
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M")
        }

    def _build_prompt(self, context: dict) -> str:
        macro = context.get("macro_assessment", {})
        scenario = context.get("scenario_forecast", {})
        industries = context.get("industry_analyses", [])
        companies = context.get("company_analyses", [])
        date = context.get("date", "")
        lines = [
            f"反驳者分析 — 质疑与反面论证 ({date})",
            "=" * 50,
            "\n【宏观通判结论（待质疑）】",
            f"- 美股判断: {macro.get('us_market', {}).get('verdict', 'N/A')}",
            f"- A股判断: {macro.get('cn_market', {}).get('verdict', 'N/A')}",
            f"- 衰退概率: {macro.get('recession_probability', 'N/A')}",
            f"- 信心度: {macro.get('confidence', 'N/A')}",
            "\n【推演分析结论（待质疑）】",
            f"- 乐观情景概率: {scenario.get('scenarios', {}).get('bull', {}).get('probability', 'N/A')}",
            f"- 基准情景概率: {scenario.get('scenarios', {}).get('base', {}).get('probability', 'N/A')}",
            f"- 悲观情景概率: {scenario.get('scenarios', {}).get('bear', {}).get('probability', 'N/A')}",
            f"\n【行业分析结论（待质疑） — {len(industries)} 个行业】",
        ]
        for ia in industries:
            lines.append(
                f"- {ia.get('industry_name', '')}: {ia.get('template', {}).get('verdict', 'N/A')} "
                f"(信心度: {ia.get('template', {}).get('confidence', 'N/A')})"
            )
        lines.append(f"\n【公司分析结论（待质疑） — {len(companies)} 家公司】")
        for ca in companies:
            lines.append(
                f"- {ca.get('ticker', '')}: {ca.get('template', {}).get('verdict', 'N/A')} "
                f"(信心度: {ca.get('template', {}).get('confidence', 'N/A')})"
            )
        lines.append(
            "\n你的任务：以批判性思维审视以上所有分析结论，"
            "找出逻辑漏洞、认知偏差、被忽略的风险和反面证据。"
            "按照系统提示词的要求输出质疑报告。"
        )
        return "\n".join(lines)
