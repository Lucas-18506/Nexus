"""Agent基类"""
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime


class Agent(ABC):
    """所有Agent的基类"""

    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role
        self.prompt_path = Path(__file__).parent / "prompts" / f"{name}.txt"
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        if self.prompt_path.exists():
            return self.prompt_path.read_text(encoding="utf-8")
        return f"你是{self.role}。请基于提供的数据进行专业分析，输出结构化JSON。"

    @abstractmethod
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """执行分析，返回结构化结果"""
        pass

    def save_output(self, output: Dict[str, Any], timestamp: str = None) -> str:
        """保存分析结果到本地"""
        from core.storage import Storage
        ts = timestamp or datetime.now().strftime("%Y%m%d_%H%M")
        return Storage.save_agent_output(self.name, ts, output)

    def load_latest_output(self) -> Optional[Dict[str, Any]]:
        """加载最近的一次分析结果"""
        from core.storage import Storage
        outputs = Storage.list_agent_outputs(self.name)
        if outputs:
            latest = sorted(outputs)[-1]
            return Storage.load_agent_output(self.name, latest.split("_")[-1].replace(".json", ""))
        return None

    def format_json_output(self, result: Dict[str, Any]) -> str:
        """格式化输出为JSON字符串"""
        return json.dumps(result, ensure_ascii=False, indent=2)
