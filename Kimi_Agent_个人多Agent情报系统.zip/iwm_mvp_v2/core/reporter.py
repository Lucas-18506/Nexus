"""报告渲染模块 —— 纯字符串拼接，零依赖.

所有渲染函数接收结构化 ``context`` 字典，返回高质量中文 Markdown 字符串。
设计原则：
1. 防御式编程：``context`` 中任意字段缺失时不报错，以占位符展示。
2. 纯函数：无 IO、无全局状态。
3. 视觉层次：通过 emoji、表格、分隔线构建可读性。
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _safe(value: Any, fallback: str = "—") -> str:
    """将值转为字符串；空值或 None 时返回 *fallback*."""
    if value is None:
        return fallback
    if isinstance(value, str) and not value.strip():
        return fallback
    return str(value)


def _header(title: str, subtitle: str = "") -> str:
    """生成一级标题块。"""
    lines = [f"# {title}"]
    if subtitle:
        lines.append(f"> {subtitle}")
    lines.append("")
    return "\n".join(lines)


def _section_header(icon: str, title: str) -> str:
    """生成带 emoji 的二级标题。"""
    return f"## {icon} {title}\n"


def _subsection(icon: str, title: str) -> str:
    """生成带 emoji 的三级标题。"""
    return f"### {icon} {title}\n"


def _divider() -> str:
    """生成分隔线。"""
    return "\n---\n"


def _render_table(headers: list[str], rows: list[list[str]]) -> str:
    """渲染 Markdown 表格。

    Args:
        headers: 表头字符串列表。
        rows: 每行字符串列表的列表。

    Returns:
        Markdown 表格字符串；无数据时返回提示文本。
    """
    if not rows:
        return "*暂无数据*\n"

    header_line = "| " + " | ".join(headers) + " |"
    sep_line = "| " + " | ".join([":---"] * len(headers)) + " |"
    row_lines = ["| " + " | ".join(row) + " |" for row in rows]
    return "\n".join([header_line, sep_line] + row_lines) + "\n"


def _tag(label: str, tone: str = "neutral") -> str:
    """生成文本标签（用 emoji 颜色区分情绪）。

    tone: neutral / positive / negative / warning / info
    """
    emoji_map = {
        "positive": "🟢",
        "negative": "🔴",
        "warning": "🟡",
        "info": "🔵",
        "neutral": "⚪",
    }
    return f"{emoji_map.get(tone, '⚪')} {label}"


# ---------------------------------------------------------------------------
# 早报
# ---------------------------------------------------------------------------

def render_morning_report(context: dict) -> str:
    """渲染早报（Morning Report）。

    Expected *context* keys::

        date               -- 日期，如 "2025-01-15"
        macro_assessment   -- dict，宏观评估结果
        news_digest        -- dict，要闻摘要结果
        scenario_forecast  -- dict，情景推演结果
        timing_signals     -- list[dict]，时机信号列表
        risk_matrix        -- dict，风险评估结果
        devil_refutation   -- dict，反驳者审查结果
        cio_conclusion     -- dict，CIO 综合结论

    Returns:
        完整 Markdown 早报字符串。
    """
    lines: list[str] = []
    date = _safe(context.get("date"), "今日")
    now_str = datetime.now().strftime("%H:%M") if 'datetime' in globals() else "—"

    # 报头
    lines.append(_header("📊 IWM 早报", f"{date} 08:30 | 投资智慧矩阵 Investment Wisdom Matrix"))
    lines.append(f"**生成时间**: {now_str}  |  **数据版本**: MVP v2  |  **Agent集群**: 9-Agent协作\n")
    lines.append(_divider())

    # === 1. 宏观环境评估 ===
    lines.append(_section_header("🌍", "宏观环境评估"))
    ma = context.get("macro_assessment", {})
    if ma:
        lines.append(f"| 市场 | 判断 | 关键信号 |")
        lines.append(f"|------|------|----------|")
        lines.append(f"| 🇺🇸 美国 | {ma.get('us_verdict', '—')} | VIX {ma.get('vix', '—')} / 10Y {ma.get('yield_10y', '—')} |")
        lines.append(f"| 🇨🇳 中国 | {ma.get('cn_verdict', '—')} | PMI {ma.get('china_pmi', '—')} |")
        lines.append(f"| 🌐 全球 | {ma.get('global_verdict', '—')} | 原油 {ma.get('oil_wti', '—')} / DXY {ma.get('dxy', '—')} |")
        lines.append("")
        lines.append(f"**市场情绪**: {ma.get('sentiment', '—')}  **金银比**: {ma.get('gold_silver', '—')}")
        lines.append("")
        lines.append(f"💡 **一句话判断**: {ma.get('one_sentence', '—')}")
        lines.append("")
        lines.append(f"⚡ **核心矛盾**: {ma.get('key_contradiction', '—')}")
    else:
        lines.append("*宏观数据待更新…*")
    lines.append("")

    # === 2. 隔夜要闻 ===
    lines.append(_section_header("📰", "隔夜要闻摘要"))
    nd = context.get("news_digest", {})
    if nd:
        lines.append(f"📊 情感分布: 正面{nd.get('positive', 0)} / 负面{nd.get('negative', 0)} / 中性{nd.get('neutral', 0)}  (综合得分: {nd.get('score', '—')})")
        lines.append("")
        top_events = nd.get("top_events", [])
        for ev in top_events:
            impact = "🔴" * ev.get("impact", 0) + "⚪" * (5 - ev.get("impact", 0))
            lines.append(f"**#{ev.get('rank', '?')}** {ev.get('title', '')}")
            lines.append(f"> 影响{ev.get('impact', 0)}/5 {impact}  |  波及: {ev.get('affected', '—')}")
            lines.append("")
        lines.append(f"🔄 **板块轮动**: {nd.get('rotation', '—')}")
    else:
        lines.append("*暂无要闻数据…*")
    lines.append("")

    # === 3. 情景推演 ===
    lines.append(_section_header("🔮", "情景推演"))
    sf = context.get("scenario_forecast", {})
    if sf:
        lines.append(f"**短期(1-4周)**: {sf.get('short_term', '—')}")
        lines.append(f"**概率分布**: {sf.get('probability', '—')}")
    else:
        lines.append("*推演分析待更新…*")
    lines.append("")

    # === 4. 时机信号 ===
    lines.append(_section_header("⏰", "时机信号 · 盘前提醒"))
    ts_list = context.get("timing_signals", [])
    if ts_list:
        headers = ["标的", "信号", "信心", "备注"]
        rows = []
        for s in ts_list:
            rows.append([f"**{s.get('ticker', '')}**", s.get('signal', '—'), s.get('conf', '—'), s.get('note', '')])
        lines.append(_render_table(headers, rows))
    else:
        lines.append("*时机信号待更新…*")
    lines.append("")

    # === 5. 风险评估 ===
    lines.append(_section_header("⚠️", "风险评估"))
    rm = context.get("risk_matrix", {})
    if rm:
        lines.append(f"**整体风险**: {rm.get('overall', '—')}")
        lines.append("")
        lines.append(f"🥇 {rm.get('top_risks', ['', '', ''])[0] if rm.get('top_risks') else '—'}")
        lines.append(f"🥈 {rm.get('top_risks', ['', '', ''])[1] if len(rm.get('top_risks', [])) > 1 else '—'}")
        lines.append(f"🥉 {rm.get('top_risks', ['', '', ''])[2] if len(rm.get('top_risks', [])) > 2 else '—'}")
        lines.append("")
        lines.append(f"板块风险最高: {rm.get('sector_highest', '—')}  |  最低: {rm.get('sector_lowest', '—')}")
    else:
        lines.append("*风险评估待更新…*")
    lines.append("")

    # === 6. 反驳者 ===
    lines.append(_section_header("😈", "反驳者 · 逆向审查"))
    dr = context.get("devil_refutation", {})
    if dr:
        flaws = dr.get("fatal_flaws", [])
        if flaws:
            lines.append("**🚨 致命缺陷:**")
            for f in flaws:
                lines.append(f"- ⚡ **{f.get('target', '')}**: {f.get('flaw', '')}")
            lines.append("")
        lines.append(f"**概率校正**: {dr.get('probability_adjusted', '—')}")
        lines.append("")
        blinds = dr.get("blind_spots", [])
        if blinds:
            lines.append("**👁️ 盲点:**")
            for b in blinds:
                lines.append(f"- {b}")
    else:
        lines.append("*暂无反面推演数据*")
    lines.append("")

    # === 7. CIO 综合结论 ===
    lines.append(_section_header("🎯", "CIO 综合结论"))
    cio = context.get("cio_conclusion", {})
    if cio:
        lines.append(f"**概率分布**: 📈 看涨{cio.get('probability', '').split('/')[0].strip() if '看涨' in str(cio.get('probability', '')) else cio.get('probability', '—')}  "
                     f"📊 中性{cio.get('probability', '').split('/')[1].strip() if len(str(cio.get('probability', '')).split('/')) > 1 else ''}  "
                     f"📉 看跌{cio.get('probability', '').split('/')[2].strip() if len(str(cio.get('probability', '')).split('/')) > 2 else ''}")
        lines.append("")
        lines.append(f"**💰 仓位建议**: {cio.get('position', '—')}")
        lines.append("")
        lines.append(f"**🎯 核心逻辑**: {cio.get('core_logic', '—')}")
        lines.append("")
        lines.append(f"**⭐ 重点操作**: {cio.get('top_actions', '—')}")
        lines.append("")
        lines.append(f"**⚡ 最大风险**: {cio.get('max_risk', '—')}")
        lines.append("")
        focus = cio.get("weekly_focus", [])
        if focus:
            lines.append("**📅 下周关注:**")
            for i, f in enumerate(focus, 1):
                lines.append(f"{i}. {f}")
        lines.append("")
        lines.append(f"_CIO置信度: {cio.get('confidence', '—')}/1.0_")
    else:
        lines.append("*综合结论待生成…*")

    lines.append(_divider())
    lines.append("*本报告由 IWM (Investment Wisdom Matrix) 九Agent协作自动生成，仅供参考，不构成投资建议。*\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 晚报
# ---------------------------------------------------------------------------

def render_evening_report(context: dict) -> str:
    """渲染晚报（Evening Report）。

    Expected *context* keys::

        date               -- 日期
        macro_summary      -- 当日宏观总结
        market_summary     -- 市场整体回顾
        ah_close_digest    -- A/H 股收盘总结
        us_premarket       -- 美股盘前动态
        news_digest        -- 当日要闻
        scenario_forecast  -- 明日情景推演
        timing_signals     -- 时机信号更新
        devil_report       -- 反面推演
        cio_conclusion     -- CIO 晚间结论
        watchlist_signals  -- list[dict] 标的收盘数据
            每个 dict 包含: ticker, name, market, close_price, change_pct,
                           volume, signal, technicals, note

    Returns:
        完整 Markdown 晚报字符串。
    """
    lines: list[str] = []

    date = _safe(context.get("date"), "今日")
    lines.append(_header("🌆 IWM 晚报", f"{date} 收盘 | 投资智慧矩阵 Investment Wisdom Matrix"))
    lines.append(f"**生成时间**: {_safe(context.get('generated_at'), '—')}  |  **数据版本**: MVP v2\n")
    lines.append(_divider())

    # 1. 市场回顾
    lines.append(_section_header("📈", "市场整体回顾"))
    lines.append(_safe(context.get("market_summary"), "市场数据待更新…"))
    lines.append("\n")

    # 2. A/H 收盘总结
    lines.append(_section_header("🇨🇳", "A股 / 港股 收盘总结"))
    lines.append(_safe(context.get("ah_close_digest"), "A/H 股数据待更新…"))
    lines.append("\n")

    # 3. 美股盘前动态
    lines.append(_section_header("🇺🇸", "美股盘前动态"))
    lines.append(_safe(context.get("us_premarket"), "美股盘前数据待更新…"))
    lines.append("\n")

    # 4. 当日要闻
    lines.append(_section_header("📰", "当日要闻"))
    lines.append(_safe(context.get("news_digest"), "暂无要闻数据…"))
    lines.append("\n")

    # 5. 关注标的收盘数据
    lines.append(_section_header("👁️", "关注标的 · 收盘一览"))
    watchlist: list[dict] = context.get("watchlist_signals", [])
    if watchlist:
        headers = ["标的", "市场", "收盘价", "涨跌幅", "成交量", "信号", "技术指标", "备注"]
        rows: list[list[str]] = []
        for item in watchlist:
            signal_raw = _safe(item.get("signal"))
            tone = "neutral"
            if "买入" in signal_raw or "看多" in signal_raw:
                tone = "positive"
            elif "卖出" in signal_raw or "看空" in signal_raw:
                tone = "negative"
            elif "谨慎" in signal_raw or "观望" in signal_raw:
                tone = "warning"

            rows.append([
                f"**{_safe(item.get('name'), item.get('ticker', '?'))}**\n`{_safe(item.get('ticker'))}`",
                _safe(item.get("market")),
                _safe(item.get("close_price")),
                _safe(item.get("change_pct")),
                _safe(item.get("volume")),
                _tag(signal_raw, tone),
                _safe(item.get("technicals")),
                _safe(item.get("note")),
            ])
        lines.append(_render_table(headers, rows))
    else:
        lines.append("*关注列表数据待更新…*\n")

    # 6. 明日情景推演
    lines.append(_section_header("🔮", "明日情景推演"))
    lines.append(_safe(context.get("scenario_forecast"), "情景分析待更新…"))
    lines.append("\n")

    # 7. 时机信号
    lines.append(_section_header("⏰", "时机信号更新"))
    lines.append(_safe(context.get("timing_signals"), "技术指标待更新…"))
    lines.append("\n")

    # 8. 反面推演
    lines.append(_section_header("😈", "反面推演 · 逆向思维"))
    lines.append(_safe(context.get("devil_report"), "*暂无反面推演数据*"))
    lines.append("\n")

    # 9. CIO 结论
    lines.append(_section_header("🎯", "CIO 晚间结论"))
    cio = _safe(context.get("cio_conclusion"), "*综合结论待生成…*")
    lines.append(f"> **{cio}**\n")

    lines.append(_divider())
    lines.append("*本报告由 IWM (Investment Wisdom Matrix) 自动生成，仅供参考，不构成投资建议。*\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 行业深度报告
# ---------------------------------------------------------------------------

def render_industry_report(context: dict) -> str:
    """渲染行业深度报告（Industry Deep Dive）。

    Expected *context* keys::

        industry_name      -- 行业名称
        date               -- 报告日期
        executive_summary  -- 执行摘要
        industry_overview  -- 行业概况
        policy_landscape   -- 政策环境
        supply_chain       -- 产业链分析
        competitive_map    -- 竞争格局
        key_players        -- list[dict] 重点企业
            每个 dict 包含: name, ticker, market, position, strengths, risks
        financial_metrics  -- 行业财务指标汇总
        risk_factors       -- 风险因素
        outlook            -- 前景展望
        investment_thesis  -- 投资逻辑
        analyst_note       -- 分析师备注

    Returns:
        完整 Markdown 行业报告字符串。
    """
    lines: list[str] = []

    name = _safe(context.get("industry_name"), "行业")
    date = _safe(context.get("date"), "今日")
    lines.append(_header(f"🏭 {name} 行业深度报告", f"{date} | IWM 投资智慧矩阵"))
    lines.append("\n")

    # 执行摘要
    lines.append(_section_header("📋", "执行摘要"))
    lines.append(_safe(context.get("executive_summary"), "摘要待生成…"))
    lines.append("\n")

    # 行业概况
    lines.append(_section_header("📊", "行业概况"))
    lines.append(_safe(context.get("industry_overview"), "行业概况待更新…"))
    lines.append("\n")

    # 政策环境
    lines.append(_section_header("📜", "政策环境"))
    lines.append(_safe(context.get("policy_landscape"), "政策分析待更新…"))
    lines.append("\n")

    # 产业链分析
    lines.append(_section_header("🔗", "产业链分析"))
    lines.append(_safe(context.get("supply_chain"), "产业链分析待更新…"))
    lines.append("\n")

    # 竞争格局
    lines.append(_section_header("⚔️", "竞争格局"))
    lines.append(_safe(context.get("competitive_map"), "竞争格局分析待更新…"))
    lines.append("\n")

    # 重点企业
    lines.append(_section_header("🏢", "重点企业分析"))
    key_players: list[dict] = context.get("key_players", [])
    if key_players:
        headers = ["公司", "代码", "市场", "行业地位", "核心优势", "风险点"]
        rows = []
        for p in key_players:
            rows.append([
                f"**{_safe(p.get('name'))}**",
                f"`{_safe(p.get('ticker'))}`",
                _safe(p.get("market")),
                _safe(p.get("position")),
                _safe(p.get("strengths")),
                _safe(p.get("risks")),
            ])
        lines.append(_render_table(headers, rows))
    else:
        lines.append("*重点企业数据待补充…*\n")

    # 行业财务指标
    lines.append(_section_header("💰", "行业财务指标"))
    lines.append(_safe(context.get("financial_metrics"), "财务指标待更新…"))
    lines.append("\n")

    # 风险因素
    lines.append(_section_header("⚠️", "风险因素"))
    lines.append(_safe(context.get("risk_factors"), "风险分析待更新…"))
    lines.append("\n")

    # 前景展望
    lines.append(_section_header("🔭", "前景展望"))
    lines.append(_safe(context.get("outlook"), "展望待更新…"))
    lines.append("\n")

    # 投资逻辑
    lines.append(_section_header("💡", "投资逻辑"))
    lines.append(_safe(context.get("investment_thesis"), "投资逻辑待构建…"))
    lines.append("\n")

    # 分析师备注
    lines.append(_section_header("📝", "分析师备注"))
    lines.append(_safe(context.get("analyst_note"), "*无备注*"))
    lines.append("\n")

    lines.append(_divider())
    lines.append("*本报告由 IWM (Investment Wisdom Matrix) 自动生成，仅供参考，不构成投资建议。*\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 公司深度报告
# ---------------------------------------------------------------------------

def render_company_report(context: dict) -> str:
    """渲染公司深度报告（Company Deep Dive）。

    Expected *context* keys::

        company_name       -- 公司名称
        ticker             -- 股票代码
        market             -- 市场 (US/HK/CN)
        date               -- 报告日期
        executive_summary  -- 执行摘要
        business_model     -- 商业模式
        moat_analysis      -- 护城河分析
        financial_health   -- 财务健康度
        valuation          -- 估值分析
        risk_factors       -- 风险因素
        catalysts          -- 潜在催化剂
        technical_view     -- 技术面观点
        management_quality -- 管理层评估
        esg_note           -- ESG 备注
        investment_thesis  -- 投资逻辑
        price_target       -- 目标价
        analyst_note       -- 分析师备注

    Returns:
        完整 Markdown 公司报告字符串。
    """
    lines: list[str] = []

    company = _safe(context.get("company_name"), "公司")
    ticker = _safe(context.get("ticker"), "—")
    market = _safe(context.get("market"), "—")
    date = _safe(context.get("date"), "今日")

    lines.append(_header(
        f"🏢 {company} ({ticker}) 深度报告",
        f"{market}市场 | {date} | IWM 投资智慧矩阵",
    ))
    lines.append("\n")

    # 执行摘要
    lines.append(_section_header("📋", "执行摘要"))
    target = _safe(context.get("price_target"), "—")
    lines.append(f"**目标价**: {target}\n")
    lines.append(_safe(context.get("executive_summary"), "摘要待生成…"))
    lines.append("\n")

    # 商业模式
    lines.append(_section_header("🧩", "商业模式"))
    lines.append(_safe(context.get("business_model"), "商业模式分析待更新…"))
    lines.append("\n")

    # 护城河
    lines.append(_section_header("🛡️", "护城河分析"))
    lines.append(_safe(context.get("moat_analysis"), "护城河分析待更新…"))
    lines.append("\n")

    # 财务健康度
    lines.append(_section_header("💰", "财务健康度"))
    lines.append(_safe(context.get("financial_health"), "财务分析待更新…"))
    lines.append("\n")

    # 估值
    lines.append(_section_header("📏", "估值分析"))
    lines.append(_safe(context.get("valuation"), "估值分析待更新…"))
    lines.append("\n")

    # 风险因素
    lines.append(_section_header("⚠️", "风险因素"))
    lines.append(_safe(context.get("risk_factors"), "风险分析待更新…"))
    lines.append("\n")

    # 催化剂
    lines.append(_section_header("🚀", "潜在催化剂"))
    lines.append(_safe(context.get("catalysts"), "催化剂分析待更新…"))
    lines.append("\n")

    # 技术面
    lines.append(_section_header("📈", "技术面观点"))
    lines.append(_safe(context.get("technical_view"), "技术面分析待更新…"))
    lines.append("\n")

    # 管理层
    lines.append(_section_header("👔", "管理层评估"))
    lines.append(_safe(context.get("management_quality"), "管理层评估待更新…"))
    lines.append("\n")

    # ESG
    lines.append(_section_header("🌱", "ESG 备注"))
    lines.append(_safe(context.get("esg_note"), "*暂无 ESG 数据*"))
    lines.append("\n")

    # 投资逻辑
    lines.append(_section_header("💡", "投资逻辑"))
    lines.append(_safe(context.get("investment_thesis"), "投资逻辑待构建…"))
    lines.append("\n")

    # 分析师备注
    lines.append(_section_header("📝", "分析师备注"))
    lines.append(_safe(context.get("analyst_note"), "*无备注*"))
    lines.append("\n")

    lines.append(_divider())
    lines.append("*本报告由 IWM (Investment Wisdom Matrix) 自动生成，仅供参考，不构成投资建议。*\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 时机提醒（简短版）
# ---------------------------------------------------------------------------

def render_timing_alert(context: dict) -> str:
    """渲染时机提醒 —— 盘前 / 盘后简短版。

    Expected *context* keys::

        alert_type         -- "盘前" 或 "盘后"
        date               -- 日期
        ticker             -- 标的代码
        name               -- 标的名称
        market             -- 市场
        signal             -- 信号文本，如 "买入信号 / 卖出信号 / 观望"
        confidence         -- 置信度，如 "高 / 中 / 低"
        trigger_reason     -- 触发原因
        technicals         -- 关键技术指标摘要
        support_resistance -- 支撑/阻力位
        suggested_action   -- 建议操作
        risk_note          -- 风险提示

    Returns:
        紧凑 Markdown 提醒字符串。
    """
    lines: list[str] = []

    alert_type = _safe(context.get("alert_type"), "时机提醒")
    date = _safe(context.get("date"), "今日")
    ticker = _safe(context.get("ticker"), "—")
    name = _safe(context.get("name"), ticker)
    market = _safe(context.get("market"), "—")
    signal = _safe(context.get("signal"), "—")
    confidence = _safe(context.get("confidence"), "—")

    # 信号 → emoji 色彩
    tone = "neutral"
    if any(k in signal for k in ("买入", "看多", "强烈", "超买")):
        tone = "positive" if "买入" in signal else "warning"
    elif any(k in signal for k in ("卖出", "看空", "超卖", "危险")):
        tone = "negative" if "卖出" in signal else "warning"
    elif "谨慎" in signal or "观望" in signal:
        tone = "warning"

    # 标题行
    icon = "🌅" if alert_type == "盘前" else "🌆" if alert_type == "盘后" else "⏰"
    lines.append(f"## {icon} {alert_type}时机提醒 · **{name}** (`{ticker}` / {market})")
    lines.append(f"**日期**: {date}  |  **信号**: {_tag(signal, tone)}  |  **置信度**: {confidence}\n")

    # 触发原因
    lines.append(_subsection("⚡", "触发原因"))
    lines.append(_safe(context.get("trigger_reason"), "—"))
    lines.append("")

    # 技术指标
    lines.append(_subsection("📊", "关键技术指标"))
    lines.append(_safe(context.get("technicals"), "—"))
    lines.append("")

    # 支撑/阻力
    sr = _safe(context.get("support_resistance"), "—")
    lines.append(f"**支撑/阻力**: {sr}\n")

    # 建议操作
    action = _safe(context.get("suggested_action"), "—")
    lines.append(_subsection("🎯", "建议操作"))
    lines.append(f"> **{action}**\n")

    # 风险提示
    risk = _safe(context.get("risk_note"), "—")
    lines.append(_subsection("⚠️", "风险提示"))
    lines.append(f"{risk}\n")

    lines.append("---")
    lines.append("*IWM 自动生成，仅供参考，不构成投资建议。*")

    return "\n".join(lines)
