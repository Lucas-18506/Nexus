"""数据存储模块 —— 纯 JSON 文件操作，零依赖.

提供宏观数据、新闻、Agent 输出、行业/公司分析、报告的统一持久化接口。
所有路径基于项目根目录自动推导，目录不存在时自动创建。
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# 路径常量
# ---------------------------------------------------------------------------

ROOT: Path = Path(__file__).resolve().parent.parent
KB: Path = ROOT / "kb_data"
REPORTS: Path = ROOT / "reports"

_MACRO_DIR: Path = KB / "macro_history"
_NEWS_DIR: Path = KB / "news_history"
_AGENT_DIR: Path = KB / "agent_outputs"
_INDUSTRY_DIR: Path = KB / "industries"
_COMPANY_DIR: Path = KB / "companies"


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _today() -> str:
    """返回 ISO 格式日期字符串 ``YYYY-MM-DD``."""
    return datetime.now().strftime("%Y-%m-%d")


def _ensure_dir(path: Path) -> None:
    """确保父目录存在。"""
    path.parent.mkdir(parents=True, exist_ok=True)


def _json_save(path: Path, data: Any) -> str:
    """将数据序列化为 JSON 并写入文件。

    Args:
        path: 目标文件路径。
        data: 可 JSON 序列化的 Python 对象。

    Returns:
        写入文件的绝对路径字符串。
    """
    _ensure_dir(path)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    return str(path.resolve())


def _json_load(path: Path, default: Any) -> Any:
    """从 JSON 文件读取数据。

    Args:
        path: 目标文件路径。
        default: 文件不存在或解析失败时返回的默认值。

    Returns:
        反序列化后的 Python 对象，或 *default*。
    """
    if not path.exists():
        return default
    try:
        with path.open("r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return default


def _latest_file(directory: Path, pattern: str = "*.json") -> Path | None:
    """返回目录中按文件名排序最新的文件路径，无匹配时返回 ``None``."""
    if not directory.exists():
        return None
    files = sorted(directory.glob(pattern))
    return files[-1] if files else None


# ---------------------------------------------------------------------------
# Storage 类
# ---------------------------------------------------------------------------

class Storage:
    """统一存储接口 —— 所有方法均为静态方法，无需实例化。"""

    # --- 宏观数据 ---

    @staticmethod
    def save_macro(date: str, data: dict) -> str:
        """保存宏观数据到 ``kb_data/macro_history/{date}.json``.

        Args:
            date: 日期字符串，如 ``2025-01-15``。
            data: 宏观指标字典。

        Returns:
            保存文件的绝对路径。
        """
        path = _MACRO_DIR / f"{date}.json"
        return _json_save(path, data)

    @staticmethod
    def load_macro(date: str | None = None) -> dict:
        """加载宏观数据，默认加载今日。

        Args:
            date: 日期字符串；为 ``None`` 时取今日。

        Returns:
            宏观指标字典，不存在时返回空字典。
        """
        target = date or _today()
        path = _MACRO_DIR / f"{target}.json"
        return _json_load(path, {})

    # --- 新闻 ---

    @staticmethod
    def save_news(date: str, data: list) -> str:
        """保存新闻到 ``kb_data/news_history/{date}.json``.

        Args:
            date: 日期字符串。
            data: 新闻条目列表。

        Returns:
            保存文件的绝对路径。
        """
        path = _NEWS_DIR / f"{date}.json"
        return _json_save(path, data)

    @staticmethod
    def load_news(date: str | None = None) -> list:
        """加载新闻，默认加载今日。

        Args:
            date: 日期字符串；为 ``None`` 时取今日。

        Returns:
            新闻条目列表，不存在时返回空列表。
        """
        target = date or _today()
        path = _NEWS_DIR / f"{target}.json"
        return _json_load(path, [])

    # --- Agent 输出 ---

    @staticmethod
    def save_agent_output(agent_name: str, timestamp: str, data: dict) -> str:
        """保存 Agent 输出到 ``kb_data/agent_outputs/{agent_name}_{timestamp}.json``.

        Args:
            agent_name: Agent 名称，如 ``macro_analyst``。
            timestamp: 时间戳字符串，如 ``2025-01-15_0830``。
            data: Agent 输出字典。

        Returns:
            保存文件的绝对路径。
        """
        safe_name = agent_name.replace("/", "_").replace("\\", "_")
        path = _AGENT_DIR / f"{safe_name}_{timestamp}.json"
        return _json_save(path, data)

    @staticmethod
    def load_agent_output(agent_name: str, timestamp: str | None = None) -> dict:
        """加载 Agent 输出；不传 *timestamp* 时取该 Agent 最新一份。

        Args:
            agent_name: Agent 名称。
            timestamp: 精确时间戳字符串；为 ``None`` 时自动取最新。

        Returns:
            Agent 输出字典，不存在时返回空字典。
        """
        safe_name = agent_name.replace("/", "_").replace("\\", "_")
        if timestamp:
            path = _AGENT_DIR / f"{safe_name}_{timestamp}.json"
            return _json_load(path, {})

        latest = _latest_file(_AGENT_DIR, f"{safe_name}_*.json")
        return _json_load(latest, {}) if latest else {}

    # --- 行业分析 ---

    @staticmethod
    def save_industry(name: str, data: dict) -> str:
        """保存行业分析到 ``kb_data/industries/{name}.json``.

        Args:
            name: 行业名称，如 ``半导体``。
            data: 行业分析字典。

        Returns:
            保存文件的绝对路径。
        """
        safe_name = name.replace("/", "_").replace("\\", "_")
        path = _INDUSTRY_DIR / f"{safe_name}.json"
        return _json_save(path, data)

    @staticmethod
    def load_industry(name: str) -> dict:
        """加载行业分析。

        Args:
            name: 行业名称。

        Returns:
            行业分析字典，不存在时返回空字典。
        """
        safe_name = name.replace("/", "_").replace("\\", "_")
        path = _INDUSTRY_DIR / f"{safe_name}.json"
        return _json_load(path, {})

    # --- 公司分析 ---

    @staticmethod
    def save_company(ticker: str, market: str, data: dict) -> str:
        """保存公司分析到 ``kb_data/companies/{ticker}_{market}.json``.

        Args:
            ticker: 股票代码，如 ``NVDA``。
            market: 市场代码，如 ``US``。
            data: 公司分析字典。

        Returns:
            保存文件的绝对路径。
        """
        safe_ticker = ticker.replace("/", "_").replace("\\", "_")
        path = _COMPANY_DIR / f"{safe_ticker}_{market}.json"
        return _json_save(path, data)

    @staticmethod
    def load_company(ticker: str, market: str) -> dict:
        """加载公司分析。

        Args:
            ticker: 股票代码。
            market: 市场代码。

        Returns:
            公司分析字典，不存在时返回空字典。
        """
        safe_ticker = ticker.replace("/", "_").replace("\\", "_")
        path = _COMPANY_DIR / f"{safe_ticker}_{market}.json"
        return _json_load(path, {})

    # --- 报告 ---

    @staticmethod
    def save_report(content: str, report_type: str, timestamp: str | None = None) -> str:
        """保存 Markdown 报告到 ``reports/{type}_{timestamp}.md``.

        Args:
            content: Markdown 格式报告正文。
            report_type: 报告类型，如 ``morning`` / ``evening`` / ``industry``。
            timestamp: 时间戳字符串；为 ``None`` 时取当前时间 ``YYYYMMDD_HHMM``。

        Returns:
            保存文件的绝对路径。
        """
        ts = timestamp or datetime.now().strftime("%Y%m%d_%H%M")
        safe_type = report_type.replace("/", "_").replace("\\", "_")
        path = REPORTS / f"{safe_type}_{ts}.md"
        _ensure_dir(path)
        with path.open("w", encoding="utf-8") as fh:
            fh.write(content)
        return str(path.resolve())

    @staticmethod
    def list_reports(report_type: str | None = None, limit: int = 20) -> list[str]:
        """列出报告文件，支持按类型过滤。

        Args:
            report_type: 报告类型前缀，如 ``morning``；为 ``None`` 时返回全部。
            limit: 最大返回数量，按文件名降序（最新在前）。

        Returns:
            报告文件的绝对路径字符串列表。
        """
        if not REPORTS.exists():
            return []

        pattern = f"{report_type}_*.md" if report_type else "*.md"
        files = sorted(REPORTS.glob(pattern), reverse=True)
        return [str(f.resolve()) for f in files[:limit]]

    # --- Agent 输出列表 ---

    @staticmethod
    def list_agent_outputs(agent_name: str | None = None) -> list[str]:
        """列出 Agent 输出历史文件。

        Args:
            agent_name: Agent 名称前缀；为 ``None`` 时返回全部。

        Returns:
            文件绝对路径字符串列表，按文件名降序（最新在前）。
        """
        if not _AGENT_DIR.exists():
            return []

        pattern = f"{agent_name}_*.json" if agent_name else "*.json"
        files = sorted(_AGENT_DIR.glob(pattern), reverse=True)
        return [str(f.resolve()) for f in files]
