"""配置管理模块 —— 纯 JSON 文件存储.

提供项目级配置读写、默认配置模板、路径解析等基础设施。
所有 API 均为纯函数，无副作用（除显式 save 外）。
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# 路径常量
# ---------------------------------------------------------------------------

_CONFIG_FILENAME: str = "config.json"
_KB_SUBDIR: str = "kb_data"


def get_project_root() -> Path:
    """返回项目根目录 Path.

    规则：从本文件所在目录向上回溯 1 层（core/ → 项目根）。
    若通过环境变量 ``IWM_PROJECT_ROOT`` 覆盖，则优先使用该值。
    """
    if env_root := os.environ.get("IWM_PROJECT_ROOT"):
        return Path(env_root).resolve()
    return Path(__file__).resolve().parent.parent


def _config_path() -> Path:
    """返回 config.json 的绝对路径（位于 kb_data/ 下）。"""
    return get_project_root() / _KB_SUBDIR / _CONFIG_FILENAME


# ---------------------------------------------------------------------------
# 默认配置
# ---------------------------------------------------------------------------

DEFAULT_CONFIG: dict[str, Any] = {
    "user": {
        "name": "",
        "risk_level": "medium",
        "focus_markets": ["US", "HK", "CN"],
    },
    "watchlist": [
        {
            "ticker": "NVDA",
            "market": "US",
            "name": "英伟达",
            "reason": "AI芯片龙头",
        },
        {
            "ticker": "TSLA",
            "market": "US",
            "name": "特斯拉",
            "reason": "电动车+能源",
        },
        {
            "ticker": "AAPL",
            "market": "US",
            "name": "苹果",
            "reason": "消费电子生态",
        },
        {
            "ticker": "MSFT",
            "market": "US",
            "name": "微软",
            "reason": "云计算+AI",
        },
        {
            "ticker": "AMD",
            "market": "US",
            "name": "AMD",
            "reason": "CPU/GPU双驱动",
        },
        {
            "ticker": "COIN",
            "market": "US",
            "name": "Coinbase",
            "reason": "加密货币交易所",
        },
        {
            "ticker": "0700.HK",
            "market": "HK",
            "name": "腾讯",
            "reason": "游戏社交云",
        },
        {
            "ticker": "9988.HK",
            "market": "HK",
            "name": "阿里",
            "reason": "电商云",
        },
        {
            "ticker": "1211.HK",
            "market": "HK",
            "name": "比亚迪",
            "reason": "新能源车龙头",
        },
        {
            "ticker": "1810.HK",
            "market": "HK",
            "name": "小米",
            "reason": "手机IoT汽车",
        },
    ],
    "macro_indicators": [
        {"name": "VIX波动率指数", "ticker": "^VIX", "category": "波动率", "source": "Yahoo Finance"},
        {"name": "CNN贪婪恐惧指数", "ticker": "", "category": "情绪", "source": "CNN Business"},
        {"name": "金银比", "ticker": "", "category": "贵金属", "source": "Yahoo Finance"},
        {"name": "铜油比", "ticker": "", "category": "大宗商品", "source": "Yahoo Finance"},
        {"name": "美国10Y国债收益率", "ticker": "^TNX", "category": "利率", "source": "Yahoo Finance"},
        {"name": "美国2Y国债收益率", "ticker": "^IRX", "category": "利率", "source": "Yahoo Finance"},
        {"name": "美元指数", "ticker": "DX-Y.NYB", "category": "汇率", "source": "Yahoo Finance"},
        {"name": "USD/CNY", "ticker": "CNY=X", "category": "汇率", "source": "Yahoo Finance"},
        {"name": "标普500期货", "ticker": "ES=F", "category": "期货", "source": "Yahoo Finance"},
        {"name": "纳指100期货", "ticker": "NQ=F", "category": "期货", "source": "Yahoo Finance"},
        {"name": "中国PMI", "ticker": "", "category": "中国经济", "source": "国家统计局"},
        {"name": "中国M2", "ticker": "", "category": "中国经济", "source": "央行"},
        {"name": "中国社融", "ticker": "", "category": "中国经济", "source": "央行"},
        {"name": "北向资金", "ticker": "", "category": "中国经济", "source": "港交所"},
    ],
    "industries": [
        "AI",
        "半导体",
        "新能源汽车",
        "电力",
        "稳定币",
        "消费电子",
        "机器人",
        "医药",
        "军工",
        "化工",
        "煤炭",
        "有色",
    ],
    "news_sources": [
        "路透社",
        "财联社",
        "华尔街见闻",
        "彭博",
        "东方财富",
    ],
    "report_schedule": {
        "morning": "08:30",
        "evening": "16:30",
    },
    "timing_indicators": [
        "K线",
        "MACD",
        "布林带",
        "RSI",
        "KDJ",
        "成交量",
        "主力资金",
        "20日线",
        "60日线",
        "月线",
    ],
}


# ---------------------------------------------------------------------------
# 读写 API
# ---------------------------------------------------------------------------

def load_config() -> dict[str, Any]:
    """读取 ``kb_data/config.json``，若不存在则返回 ``DEFAULT_CONFIG`` 的深拷贝。

    Returns:
        配置字典，结构与 ``DEFAULT_CONFIG`` 一致。
    """
    cfg_path = _config_path()
    if not cfg_path.exists():
        return json.loads(json.dumps(DEFAULT_CONFIG))  # 深拷贝

    try:
        with cfg_path.open("r", encoding="utf-8") as fh:
            loaded: dict[str, Any] = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return json.loads(json.dumps(DEFAULT_CONFIG))

    # 与默认配置合并：保留新增字段，补充缺失字段
    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    _deep_merge(merged, loaded)
    return merged


def save_config(config: dict[str, Any]) -> None:
    """将配置字典持久化到 ``kb_data/config.json``.

    Args:
        config: 要保存的配置字典，建议为 ``load_config()`` 修改后的完整字典。

    Raises:
        OSError: 当目录不可写或文件写入失败时抛出。
    """
    cfg_path = _config_path()
    cfg_path.parent.mkdir(parents=True, exist_ok=True)

    with cfg_path.open("w", encoding="utf-8") as fh:
        json.dump(config, fh, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> None:
    """递归将 *override* 合并到 *base* 中（原地修改）。"""
    for key, val in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(val, dict):
            _deep_merge(base[key], val)
        else:
            base[key] = val
