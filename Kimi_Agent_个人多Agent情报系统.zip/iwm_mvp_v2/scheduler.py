"""IWM v2 调度器 - 定义早报/晚报工作流"""
import json
from datetime import datetime
from typing import Dict, Any


class WorkflowRunner:
    """工作流运行器 - 协调多个Agent的执行顺序"""

    def __init__(self):
        self.context = {}  # 共享上下文

    def run_morning_workflow(self) -> Dict[str, Any]:
        """
        早报工作流 (8:30)
        步骤:
        1. Agent-1 宏观通判: 采集宏观数据
        2. Agent-2 新闻扫描: 扫描隔夜新闻+美股收盘
        3. Agent-3 推演分析: 基于宏观+新闻做短期推演
        4. Agent-8 时机分析: 美股标的盘前提醒 + A/H标的盘前提醒
        5. Agent-6 反驳者: 审查1-3-8的输出
        6. Agent-9 CIO: 汇总生成早报

        返回: {"report_path": str, "cio_output": dict, "execution_log": list}
        """
        log = []
        ts = datetime.now().strftime("%Y%m%d_%H%M")

        # Step 1: 宏观
        log.append(f"[{ts}] Step1: MacroJudge采集宏观数据...")
        # 注：实际由主Agent调用工具完成，这里记录执行步骤

        # Step 2: 新闻
        log.append(f"[{ts}] Step2: NewsScanner扫描隔夜新闻...")

        # Step 3: 推演
        log.append(f"[{ts}] Step3: ScenarioForecast短期推演...")

        # Step 4: 时机
        log.append(f"[{ts}] Step4: Timing Analyst盘前提醒...")

        # Step 5: 反驳
        log.append(f"[{ts}] Step5: DevilAdvocate审查...")

        # Step 6: CIO汇总
        log.append(f"[{ts}] Step6: CIO汇总生成早报...")

        return {
            "workflow": "morning",
            "timestamp": ts,
            "steps": [
                {"step": 1, "agent": "macro_judge", "status": "pending", "description": "采集宏观数据(VIX/金银比/铜油比/美债/中国PMI等)"},
                {"step": 2, "agent": "news_scanner", "status": "pending", "description": "扫描隔夜新闻+美股收盘总结"},
                {"step": 3, "agent": "scenario_forecast", "status": "pending", "description": "短期(1-4周)推演"},
                {"step": 4, "agent": "timing_analyst", "status": "pending", "description": "美股标的+A/H标的盘前提醒"},
                {"step": 5, "agent": "devil_advocate", "status": "pending", "description": "审查前面分析"},
                {"step": 6, "agent": "cio_synthesizer", "status": "pending", "description": "生成早报"},
            ],
            "execution_log": log,
            "report_path": None,
        }

    def run_evening_workflow(self) -> Dict[str, Any]:
        """
        晚报工作流 (16:30)
        步骤:
        1. Agent-1 宏观通判: 更新宏观数据
        2. Agent-2 新闻扫描: 扫描当日新闻+A/H收盘
        3. Agent-4 行业分析: 重点行业深度（可配置）
        4. Agent-7 公司分析: 关注标的更新
        5. Agent-3 推演分析: 中短期推演
        6. Agent-5 风险评估: 全面风险评估
        7. Agent-8 时机分析: 各标的操作信号
        8. Agent-6 反驳者: 审查所有分析
        9. Agent-9 CIO: 汇总生成晚报
        """
        log = []
        ts = datetime.now().strftime("%Y%m%d_%H%M")

        steps = [
            {"step": 1, "agent": "macro_judge", "status": "pending", "description": "更新宏观数据"},
            {"step": 2, "agent": "news_scanner", "status": "pending", "description": "扫描当日新闻+A/H收盘总结"},
            {"step": 3, "agent": "industry_analyst", "status": "pending", "description": "重点行业深度分析"},
            {"step": 4, "agent": "company_analyst", "status": "pending", "description": "关注标的更新"},
            {"step": 5, "agent": "scenario_forecast", "status": "pending", "description": "中短期推演"},
            {"step": 6, "agent": "risk_assessor", "status": "pending", "description": "全面风险评估"},
            {"step": 7, "agent": "timing_analyst", "status": "pending", "description": "各标的操作信号"},
            {"step": 8, "agent": "devil_advocate", "status": "pending", "description": "审查所有分析"},
            {"step": 9, "agent": "cio_synthesizer", "status": "pending", "description": "生成晚报"},
        ]

        return {
            "workflow": "evening",
            "timestamp": ts,
            "steps": steps,
            "execution_log": log,
            "report_path": None,
        }

    def run_industry_deep_workflow(self, industry_name: str) -> Dict[str, Any]:
        """行业深度分析工作流（按需触发）"""
        ts = datetime.now().strftime("%Y%m%d_%H%M")
        return {
            "workflow": "industry_deep",
            "industry": industry_name,
            "timestamp": ts,
            "steps": [
                {"step": 1, "agent": "macro_judge", "status": "pending", "description": f"获取行业相关的宏观数据"},
                {"step": 2, "agent": "news_scanner", "status": "pending", "description": f"扫描{industry_name}行业新闻"},
                {"step": 3, "agent": "industry_analyst", "status": "pending", "description": f"{industry_name}行业深度分析"},
                {"step": 4, "agent": "risk_assessor", "status": "pending", "description": f"{industry_name}行业风险评估"},
                {"step": 5, "agent": "devil_advocate", "status": "pending", "description": "审查行业分析"},
            ],
        }

    def run_company_deep_workflow(self, ticker: str, market: str) -> Dict[str, Any]:
        """公司深度分析工作流（按需触发）"""
        ts = datetime.now().strftime("%Y%m%d_%H%M")
        return {
            "workflow": "company_deep",
            "ticker": ticker,
            "market": market,
            "timestamp": ts,
            "steps": [
                {"step": 1, "agent": "company_analyst", "status": "pending", "description": f"{ticker}公司基本面分析"},
                {"step": 2, "agent": "timing_analyst", "status": "pending", "description": f"{ticker}技术面分析"},
                {"step": 3, "agent": "devil_advocate", "status": "pending", "description": "审查公司分析"},
            ],
        }
