# 修复计划

## 问题1: 其他菜单点击黑屏
**原因**: MorningReport/EveningReport/Industry/Company/Devil/CIO 共6个页面没有使用 Layout 组件包裹，缺少 `ml-[260px]` 左边距和正确的容器样式。

**修复**: 为所有6个页面添加 Layout 包裹 + 错误边界。

## 问题2: 指标需要中文含义标注
**修复**: 在 Macro 页面每个指标卡片下方添加中文含义说明。

## 执行步骤
1. 用 Python 脚本批量为6个页面添加 Layout 包裹
2. 修改 Macro 页面添加指标含义
3. 构建部署
