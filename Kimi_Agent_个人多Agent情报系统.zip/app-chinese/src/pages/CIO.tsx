import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  ReferenceLine,
} from 'recharts'
import {
  Calculator,
  KeyRound,
  Target,
  BarChart3,
  PieChartIcon,
  LayoutTemplate,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─────────────────────────── types ─────────────────────────── */

interface ScenarioSegment {
  name: string
  label: string
  probability: number
  color: string
  keyDriver: string
}

interface Sector {
  sector: string
  allocation: number
  benchmark: number
  color: string
}

interface StockAction {
  ticker: string
  name: string
  market: string
  action: string
  confidence: number
  price: number
  target: number
  stop: number
  rationale: string
}

interface PositionSize {
  rank: number
  ticker: string
  name: string
  signal: string
  conviction: string
  edge: number
  winRate: number
  optimalSize: number
  currentSize: number
  action: string
  stopLoss: number
  takeProfit: number
}

interface KeyAssumption {
  text: string
  status: string
  validated: string
  ifWrong: string
  impact: string
}

interface WeeklyFocusItem {
  day: string
  event: string
  impact: number
  position: string
}

interface RiskPosition {
  ticker: string
  risk: number
  expectedReturn: number
  size: number
  signal: string
}

interface EfficientFrontierPoint {
  risk: number
  return: number
}

interface RiskReturnMatrix {
  positions: RiskPosition[]
  efficientFrontier: EfficientFrontierPoint[]
  portfolioAverage: { risk: number; return: number }
}

interface DirectionalBias {
  verdict: string
  statement: string
  netExposureTarget: number
  netExposurePrev: number
  cashLevel: number
  hedgeRatio: number
  rationale: string[]
  lastChanged: string
}

interface CIOData {
  directionalBias: DirectionalBias
  scenarioProbabilities: {
    segments: ScenarioSegment[]
    confidenceInterval: string
  }
  sectorAllocation: { active: Sector[] }
  stockActions: StockAction[]
  positionSizing: PositionSize[]
  keyAssumptions: KeyAssumption[]
  weeklyFocus: WeeklyFocusItem[]
  riskReturnMatrix: RiskReturnMatrix
  meta: { generatedAt: string; reportPeriod: string; version: string }
}

/* ─────────────────────────── easing ─────────────────────────── */

const easeOut = [0.4, 0, 0.2, 1] as [number, number, number, number]

/* ─────────────────────────── signal helpers ─────────────────── */

const actionColor = (action: string) => {
  switch (action) {
    case 'BUY':
      return { border: 'border-[#10B981]', bg: 'bg-[rgba(16,185,129,0.12)]', text: 'text-[#10B981]' }
    case 'ADD':
      return { border: 'border-[#14B8A6]', bg: 'bg-[rgba(20,184,166,0.12)]', text: 'text-[#14B8A6]' }
    case 'SELL':
      return { border: 'border-[#EF4444]', bg: 'bg-[rgba(239,68,68,0.12)]', text: 'text-[#EF4444]' }
    case 'HOLD':
      return { border: 'border-[#6B7280]', bg: 'bg-[rgba(107,114,128,0.12)]', text: 'text-[#6B7280]' }
    case 'REDUCE':
      return { border: 'border-[#F59E0B]', bg: 'bg-[rgba(245,158,11,0.12)]', text: 'text-[#F59E0B]' }
    case 'WATCH':
      return { border: 'border-[#3B82F6]', bg: 'bg-[rgba(59,130,246,0.12)]', text: 'text-[#3B82F6]' }
    default:
      return { border: 'border-[#6B7280]', bg: 'bg-[rgba(107,114,128,0.12)]', text: 'text-[#6B7280]' }
  }
}

const signalIcon = (action: string) => {
  switch (action) {
    case 'BUY':
    case 'ADD':
      return <ArrowUpRight className="h-3.5 w-3.5" />
    case 'SELL':
    case 'REDUCE':
      return <ArrowDownRight className="h-3.5 w-3.5" />
    default:
      return <Minus className="h-3.5 w-3.5" />
  }
}

const convictionColor = (conviction: string) => {
  switch (conviction) {
    case 'HIGH':
      return 'text-[#10B981]'
    case 'MEDIUM':
      return 'text-[#F59E0B]'
    case 'LOW':
      return 'text-[#8A93A8]'
    default:
      return 'text-[#8A93A8]'
  }
}

const assumptionStatusColor = (status: string) => {
  switch (status) {
    case 'Active':
      return '#10B981'
    case 'At Risk':
      return '#F59E0B'
    case 'Broken':
      return '#EF4444'
    default:
      return '#6B7280'
  }
}

/* ─────────────────────────── component ──────────────────────── */

export default function CIO() {
  const [data, setData] = useState<CIOData | null>(null)
  const [sectorView, setSectorView] = useState<'active' | 'benchmark'>('active')
  const [hoveredSegment, setHoveredSegment] = useState<number | null>(null)

  useEffect(() => {
    fetch('./data/cio.json')
      .then((r) => r.json())
      .then(setData)
      .catch(console.error)
  }, [])

  const getSectorData = useCallback(
    (sectors: Sector[]) =>
      sectors.map((s) => ({
        name: s.sector,
        value: sectorView === 'active' ? s.allocation : s.benchmark,
        color: s.color,
        delta: s.allocation - s.benchmark,
      })),
    [sectorView]
  )

  /* Custom tooltip for scatter chart */
  const ScatterTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ payload: RiskPosition }> }) => {
    if (active && payload && payload.length) {
      const p = payload[0].payload
      return (
        <div className="rounded-lg border border-[rgba(255,255,255,0.1)] bg-[#1C1F2B] p-3 shadow-lg">
          <p className="text-[13px] font-bold font-mono text-[#F0F2F8]">{p.ticker}</p>
          <p className="text-[12px] text-[#8A93A8]">风险: {p.risk}%</p>
          <p className="text-[12px] text-[#8A93A8]">预期收益: {p.expectedReturn}%</p>
          <p className="text-[12px] text-[#8A93A8]">仓位: {p.size}%</p>
        </div>
      )
    }
    return null
  }

  if (!data) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-[#8A93A8] font-mono text-sm">加载CIO汇总...</div>
      </div>
    )
  }

  const {
    directionalBias,
    scenarioProbabilities,
    sectorAllocation,
    stockActions,
    positionSizing,
    keyAssumptions,
    weeklyFocus,
    riskReturnMatrix,
    meta,
  } = data

  const sectorData = getSectorData(sectorAllocation.active)
  const activeDeviation = sectorAllocation.active.reduce((acc, s) => acc + Math.abs(s.allocation - s.benchmark), 0) / 2

  return (
    <div className="space-y-8 pb-12">
      {/* ═══════════════ HERO ═══════════════ */}
      <section
        className="relative rounded-xl p-8 md:p-10 overflow-hidden"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.1) 0%, transparent 60%)',
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: easeOut }}
        >
          <span
            className="text-[11px] font-medium tracking-[0.08em] text-[#D4AF37] uppercase block mb-2"
          >
            首席投资官
          </span>
          <h1
            className="text-[36px] font-bold tracking-[-0.02em] text-[#F0F2F8]"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}
          >
            CIO汇总
          </h1>
          <p className="mt-2 text-[14px] text-[#8A93A8]">
            战略定位与配置决策
          </p>
          <div className="mt-4 flex items-center gap-3">
            <span className="text-[11px] text-[#5C6375]">{meta.generatedAt.replace('T', ' ').replace('Z', '')}</span>
            <span className="text-[11px] font-medium px-3 py-1 rounded-full bg-[rgba(212,175,55,0.12)] text-[#D4AF37] border border-[rgba(212,175,55,0.25)]">
              {meta.reportPeriod}
            </span>
          </div>
        </motion.div>
        {/* Gold line */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.2, duration: 0.6, ease: easeOut }}
          className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D4AF37] origin-left"
        />
      </section>

      {/* ═══════════════ 方向性偏向 CARD ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.6, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(212,175,55,0.25)] p-6 relative overflow-hidden"
          style={{
            background: 'radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.03) 0%, #14171F 100%)',
            boxShadow: '0 0 20px rgba(212,175,55,0.15)',
            borderLeft: '4px solid #D4AF37',
          }}
        >
          <span className="text-[11px] font-medium tracking-[0.06em] text-[#D4AF37] uppercase">
            方向性偏向
          </span>
          <p className="mt-3 text-[24px] font-bold tracking-[-0.01em] text-[#F0F2F8]">
            {directionalBias.verdict} — {directionalBias.statement}
          </p>
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <p
                className="text-[28px] font-bold text-[#F0F2F8]"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {directionalBias.netExposureTarget}%
              </p>
              <p className="text-[12px] text-[#5C6375]">
                目标净敞口
                <span className="ml-2 text-[#8A93A8]">
                  (前值 {directionalBias.netExposurePrev}%)
                </span>
              </p>
            </div>
            <div>
              <p className="text-[20px] font-bold text-[#F59E0B]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {directionalBias.cashLevel}%
              </p>
              <p className="text-[12px] text-[#5C6375]">现金</p>
            </div>
            <div>
              <p className="text-[20px] font-bold text-[#3B82F6]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {directionalBias.hedgeRatio}%
              </p>
              <p className="text-[12px] text-[#5C6375]">对冲比例</p>
            </div>
          </div>
          <div className="mt-5 space-y-2">
            {directionalBias.rationale.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 + i * 0.08, duration: 0.4 }}
                className="flex gap-2"
              >
                <span className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-[#D4AF37]" />
                <span className="text-[13px] text-[#8A93A8]">{r}</span>
              </motion.div>
            ))}
          </div>
          <p className="mt-4 text-[11px] text-[#5C6375] tracking-[0.06em]">
            仓位最后调整: {directionalBias.lastChanged}
          </p>
        </div>
      </motion.section>

      {/* ═══════════════ PROBABILITY + SECTOR (2-col) ═══════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-6">
        {/* ── Probability Distribution ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5, ease: easeOut }}
        >
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{
              background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            }}
          >
            <div className="flex items-center gap-2 mb-5">
              <PieChartIcon className="h-5 w-5 text-[#8A93A8]" />
              <h2 className="text-[18px] font-semibold text-[#F0F2F8]">情景概率</h2>
            </div>

            {/* Stacked probability bar */}
            <div className="flex h-10 rounded-lg overflow-hidden mb-5">
              {scenarioProbabilities.segments.map((seg, idx) => (
                <motion.div
                  key={seg.name}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 0.3 + idx * 0.1, duration: 0.6, ease: easeOut }}
                  className="relative flex items-center justify-center cursor-pointer hover:brightness-110 transition-all"
                  style={{
                    backgroundColor: seg.color,
                    width: `${seg.probability}%`,
                    transformOrigin: 'left',
                  }}
                  onMouseEnter={() => setHoveredSegment(idx)}
                  onMouseLeave={() => setHoveredSegment(null)}
                >
                  {seg.probability >= 10 && (
                    <span className="text-[11px] font-bold text-white font-mono drop-shadow-md">
                      {seg.probability}%
                    </span>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Segment labels */}
            <div className="flex flex-wrap gap-3 mb-5">
              {scenarioProbabilities.segments.map((seg) => (
                <div key={seg.name} className="flex items-center gap-1.5">
                  <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: seg.color }} />
                  <span className="text-[11px] text-[#8A93A8]">
                    {seg.name} ({seg.probability}%)
                  </span>
                </div>
              ))}
            </div>

            {/* Hovered detail */}
            <AnimatePresence>
              {hoveredSegment !== null && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="rounded-lg bg-[#232837] p-3 mb-4 border border-[rgba(255,255,255,0.06)]"
                >
                  <p className="text-[13px] font-bold text-[#F0F2F8]">
                    {scenarioProbabilities.segments[hoveredSegment].label}
                  </p>
                  <p className="text-[12px] text-[#8A93A8]">
                    {scenarioProbabilities.segments[hoveredSegment].keyDriver}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Scenario detail mini-cards */}
            <div className="space-y-2">
              {scenarioProbabilities.segments.map((seg, idx) => (
                <motion.div
                  key={seg.name}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + idx * 0.06, duration: 0.4, ease: easeOut }}
                  className="flex items-center gap-3 rounded-md p-2.5 border-l-[3px] bg-[#1C1F2B]"
                  style={{ borderLeftColor: seg.color }}
                >
                  <span className="text-[13px] font-bold text-[#F0F2F8] flex-1">{seg.name}</span>
                  <span className="text-[13px] font-mono text-[#F0F2F8]">{seg.probability}%</span>
                  <span className="text-[11px] text-[#5C6375] max-w-[180px] truncate">{seg.keyDriver}</span>
                </motion.div>
              ))}
            </div>

            <p className="mt-4 text-[12px] text-[#5C6375]">
              {scenarioProbabilities.confidenceInterval}
            </p>
          </div>
        </motion.section>

        {/* ── Sector Allocation Donut ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5, ease: easeOut }}
        >
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{
              background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <LayoutTemplate className="h-5 w-5 text-[#8A93A8]" />
              <h2 className="text-[18px] font-semibold text-[#F0F2F8]">行业配置</h2>
            </div>

            {/* Toggle */}
            <div className="flex gap-1 rounded-lg bg-[#232837] p-1 mb-4 w-fit">
              <button
                onClick={() => setSectorView('active')}
                className={cn(
                  'px-3 py-1 rounded-md text-[11px] font-medium tracking-[0.06em] uppercase transition-all',
                  sectorView === 'active'
                    ? 'bg-[#D4AF37] text-[#14171F]'
                    : 'text-[#8A93A8] hover:text-[#F0F2F8]'
                )}
              >
                主动
              </button>
              <button
                onClick={() => setSectorView('benchmark')}
                className={cn(
                  'px-3 py-1 rounded-md text-[11px] font-medium tracking-[0.06em] uppercase transition-all',
                  sectorView === 'benchmark'
                    ? 'bg-[#D4AF37] text-[#14171F]'
                    : 'text-[#8A93A8] hover:text-[#F0F2F8]'
                )}
              >
                基准
              </button>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-6">
              {/* Donut */}
              <div className="relative" style={{ width: 220, height: 220 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={sectorData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={2}
                      dataKey="value"
                      animationBegin={400}
                      animationDuration={800}
                    >
                      {sectorData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="transparent" />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                {/* Center label */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase">
                    {sectorView === 'active' ? '主动' : '基准'}
                  </span>
                  <span className="text-[14px] font-bold font-mono text-[#D4AF37]">
                    {activeDeviation.toFixed(1)}%
                  </span>
                  <span className="text-[10px] text-[#5C6375]">偏离</span>
                </div>
              </div>

              {/* Legend */}
              <div className="flex-1 space-y-1.5 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
                {sectorAllocation.active.map((s, idx) => {
                  const delta = s.allocation - s.benchmark
                  return (
                    <motion.div
                      key={s.sector}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.5 + idx * 0.05, duration: 0.4 }}
                      className="flex items-center gap-2"
                    >
                      <div className="h-2 w-2 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
                      <span className="text-[12px] text-[#8A93A8] flex-1 truncate">{s.sector}</span>
                      <span className="text-[12px] font-mono text-[#F0F2F8]">
                        {sectorView === 'active' ? s.allocation : s.benchmark}%
                      </span>
                      {sectorView === 'active' && (
                        <span
                          className={cn(
                            'text-[11px] font-mono',
                            delta > 0 ? 'text-[#10B981]' : delta < 0 ? 'text-[#EF4444]' : 'text-[#5C6375]'
                          )}
                        >
                          {delta > 0 ? '+' : ''}
                          {delta}%
                        </span>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </div>
        </motion.section>
      </div>

      {/* ═══════════════ STOCK ACTION CARDS ═══════════════ */}
      <section>
        <div className="mb-4">
          <h2 className="text-[24px] font-bold tracking-[-0.01em] text-[#F0F2F8]">股票操作</h2>
          <p className="text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase">
            本周建议仓位调整
          </p>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-3 custom-scrollbar">
          {stockActions.map((stock, idx) => {
            const colors = actionColor(stock.action)
            return (
              <motion.div
                key={stock.ticker}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + idx * 0.1, duration: 0.4, ease: easeOut }}
                className={cn(
                  'flex-shrink-0 w-[280px] rounded-xl border border-[rgba(255,255,255,0.06)] p-5 bg-[#14171F]',
                  'hover:translate-y-[-2px] hover:shadow-[0_8px_40px_rgba(0,0,0,0.5)] hover:border-[rgba(255,255,255,0.1)] transition-all duration-250'
                )}
                style={{ borderTop: `3px solid ${colors.border.replace('border-', '')}` }}
              >
                {/* Action badge */}
                <div className="flex items-center justify-between mb-3">
                  <span
                    className={cn(
                      'flex items-center gap-1 text-[11px] font-bold tracking-[0.06em] px-2.5 py-1 rounded-full',
                      colors.bg,
                      colors.text
                    )}
                  >
                    {signalIcon(stock.action)}
                    {stock.action}
                  </span>
                  <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#232837] text-[#8A93A8]">
                    {stock.market}
                  </span>
                </div>

                {/* Ticker + name */}
                <p
                  className="text-[20px] font-bold text-[#F0F2F8]"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {stock.ticker}
                </p>
                <p className="text-[13px] text-[#8A93A8] mb-2 truncate">{stock.name}</p>

                {/* Price + target */}
                <p className="text-[14px] font-mono text-[#F0F2F8]">
                  ${stock.price.toFixed(2)}{' '}
                  <span className="text-[12px] text-[#10B981]">→ ${stock.target}</span>{' '}
                  <span className="text-[12px] text-[#EF4444]">✕ ${stock.stop}</span>
                </p>

                {/* Confidence progress */}
                <div className="mt-3">
                  <div className="flex justify-between mb-1">
                    <span className="text-[11px] text-[#5C6375]">确信度</span>
                    <span className="text-[11px] font-mono text-[#F0F2F8]">
                      {(stock.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[#232837] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${stock.confidence * 100}%` }}
                      transition={{ delay: 0.7 + idx * 0.1, duration: 0.6, ease: easeOut }}
                      className={cn(
                        'h-full rounded-full',
                        stock.confidence >= 0.8
                          ? 'bg-[#10B981]'
                          : stock.confidence >= 0.6
                            ? 'bg-[#F59E0B]'
                            : 'bg-[#8A93A8]'
                      )}
                    />
                  </div>
                </div>

                {/* Rationale */}
                <p className="mt-3 text-[12px] text-[#8A93A8] leading-[1.5] line-clamp-2">{stock.rationale}</p>
              </motion.div>
            )
          })}
        </div>
      </section>

      {/* ═══════════════ POSITION SIZING TABLE ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <Calculator className="h-5 w-5 text-[#8A93A8]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">仓位管理框架</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#1C1F2B]">
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3 rounded-tl-lg">排名</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">标的</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">信号</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">确信度</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">优势</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">胜率</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">最优</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">当前</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">操作</th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3 rounded-tr-lg">止损|止盈</th>
                </tr>
              </thead>
              <tbody>
                {positionSizing.map((pos, idx) => (
                  <motion.tr
                    key={pos.ticker}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + idx * 0.03, duration: 0.4, ease: easeOut }}
                    className="border-t border-[rgba(255,255,255,0.06)] hover:bg-[#232837] transition-colors"
                  >
                    <td className="px-3 py-3 text-[11px] text-[#5C6375]">{pos.rank}</td>
                    <td className="px-3 py-3">
                      <span className="text-[13px] font-bold font-mono text-[#F0F2F8]">{pos.ticker}</span>
                      <span className="text-[11px] text-[#5C6375] ml-2">{pos.name}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={cn(
                          'text-[11px] font-bold tracking-[0.06em] px-2 py-0.5 rounded-full',
                          actionColor(pos.signal).bg,
                          actionColor(pos.signal).text
                        )}
                      >
                        {pos.signal}
                      </span>
                    </td>
                    <td className={cn('px-3 py-3 text-[12px] font-bold', convictionColor(pos.conviction))}>
                      {pos.conviction}
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#10B981]">+{pos.edge}%</td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#8A93A8]">{pos.winRate}%</td>
                    <td className="px-3 py-3 text-[12px] font-mono font-bold text-[#D4AF37]">
                      <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.9 + idx * 0.03 }}
                      >
                        {pos.optimalSize}%
                      </motion.span>
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#8A93A8]">{pos.currentSize}%</td>
                    <td className="px-3 py-3">
                      <span
                        className={cn(
                          'text-[12px] font-mono font-bold',
                          pos.action.startsWith('↑')
                            ? 'text-[#10B981]'
                            : pos.action.startsWith('↓')
                              ? 'text-[#EF4444]'
                              : 'text-[#6B7280]'
                        )}
                      >
                        {pos.action}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-[11px] font-mono text-[#8A93A8]">
                      <span className="text-[#EF4444]">{pos.stopLoss}</span>
                      <span className="mx-1 text-[#5C6375]">|</span>
                      <span className="text-[#10B981]">{pos.takeProfit}</span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Footer */}
          <div className="mt-4 flex flex-wrap gap-6 px-3 py-3 rounded-lg bg-[#1C1F2B]">
            <span className="text-[12px] text-[#8A93A8]">
              总配置: <span className="font-mono font-bold text-[#F0F2F8]">85%</span>
            </span>
            <span className="text-[12px] text-[#8A93A8]">
              现金: <span className="font-mono font-bold text-[#F59E0B]">15%</span>
            </span>
            <span className="text-[12px] text-[#8A93A8]">
              对冲: <span className="font-mono font-bold text-[#3B82F6]">10%</span>
            </span>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ 核心假设 + 本周焦点 (2-col) ═══════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ── Key Assumptions ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.5, ease: easeOut }}
        >
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{
              background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <KeyRound className="h-5 w-5 text-[#8A93A8]" />
              <h2 className="text-[18px] font-semibold text-[#F0F2F8]">核心假设</h2>
            </div>
            <p className="text-[13px] text-[#5C6375] mb-5">如果这些变化，我们的观点也会变化</p>

            <div className="space-y-4">
              {keyAssumptions.map((assumption, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + idx * 0.06, duration: 0.4, ease: easeOut }}
                  className="flex gap-3 p-3 rounded-lg bg-[#1C1F2B] border border-[rgba(255,255,255,0.06)]"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1 + idx * 0.06, type: 'spring', stiffness: 500, damping: 15 }}
                    className="mt-0.5 h-3 w-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: assumptionStatusColor(assumption.status) }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] text-[#F0F2F8] leading-[1.5]">{assumption.text}</p>
                    <div className="mt-1.5 flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-[#5C6375]">
                        验证状态: {assumption.validated}
                      </span>
                      <span
                        className={cn(
                          'text-[11px] font-bold',
                          assumption.impact === 'BEARISH'
                            ? 'text-[#EF4444]'
                            : assumption.impact === 'BULLISH'
                              ? 'text-[#10B981]'
                              : 'text-[#F59E0B]'
                        )}
                      >
                        影响: {assumption.ifWrong}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* ── Weekly Focus ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.5, ease: easeOut }}
        >
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{
              background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-5 w-5 text-[#8A93A8]" />
              <h2 className="text-[18px] font-semibold text-[#F0F2F8]">本周焦点</h2>
            </div>
            <p className="text-[13px] text-[#5C6375] mb-5">本周关键事件与决策</p>

            <div className="space-y-0">
              {weeklyFocus.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 + idx * 0.07, duration: 0.4, ease: easeOut }}
                >
                  <div className="py-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[11px] font-medium tracking-[0.06em] text-[#D4AF37] uppercase">
                        {item.day}
                      </span>
                      <div className="flex gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className={cn(
                              'h-1.5 w-1.5 rounded-full',
                              i < item.impact ? 'bg-[#D4AF37]' : 'bg-[#232837]'
                            )}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-[13px] font-bold text-[#F0F2F8]">{item.event}</p>
                    <p className="text-[12px] text-[#8A93A8] mt-0.5">{item.position}</p>
                  </div>
                  {idx < weeklyFocus.length - 1 && (
                    <div className="h-px bg-[rgba(255,255,255,0.06)]" />
                  )}
                </motion.div>
              ))}
            </div>

            {/* Progress */}
            <div className="mt-4 pt-3 border-t border-[rgba(255,255,255,0.06)]">
              <div className="flex justify-between text-[11px] text-[#5C6375] mb-1">
                <span>{weeklyFocus.length}项</span>
                <span>0已完成</span>
              </div>
              <div className="h-1 rounded-full bg-[#232837]">
                <div className="h-full w-0 rounded-full bg-[#D4AF37]" />
              </div>
            </div>
          </div>
        </motion.section>
      </div>

      {/* ═══════════════ 风险调整收益矩阵 ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <BarChart3 className="h-5 w-5 text-[#8A93A8]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">风险调整收益矩阵</h2>
          </div>

          <div className="w-full" style={{ height: 400 }}>
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis
                  type="number"
                  dataKey="risk"
                  name="Risk"
                  unit="%"
                  domain={[0, 50]}
                  tick={{ fill: '#5C6375', fontSize: 11 }}
                  stroke="#5C6375"
                  label={{ value: '风险 (波动率%)', position: 'insideBottom', offset: -10, fill: '#8A93A8', fontSize: 12 }}
                />
                <YAxis
                  type="number"
                  dataKey="expectedReturn"
                  name="预期收益"
                  unit="%"
                  domain={[-15, 35]}
                  tick={{ fill: '#5C6375', fontSize: 11 }}
                  stroke="#5C6375"
                  label={{ value: '预期收益%', angle: -90, position: 'insideLeft', offset: 10, fill: '#8A93A8', fontSize: 12 }}
                />
                <ReferenceLine
                  x={riskReturnMatrix.portfolioAverage.risk}
                  stroke="#D4AF37"
                  strokeDasharray="4 4"
                  strokeWidth={1}
                />
                <ReferenceLine
                  y={riskReturnMatrix.portfolioAverage.return}
                  stroke="#D4AF37"
                  strokeDasharray="4 4"
                  strokeWidth={1}
                />
                <Tooltip content={<ScatterTooltip />} cursor={{ strokeDasharray: '3 3' }} />
                {/* Efficient frontier line */}
                <Line
                  type="monotone"
                  data={riskReturnMatrix.efficientFrontier.map((p) => ({ risk: p.risk, expectedReturn: p.return }))}
                  dataKey="expectedReturn"
                  stroke="#D4AF37"
                  strokeWidth={1}
                  strokeDasharray="6 3"
                  dot={false}
                  activeDot={false}
                />
                <Scatter
                  data={riskReturnMatrix.positions}
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  shape={(props: any) => {
                    const { cx, cy, payload } = props as { cx: number; cy: number; payload: RiskPosition }
                    const r = Math.max(4, Math.min(14, payload.size * 1.2))
                    const color =
                      payload.signal === 'BUY' || payload.signal === 'ADD'
                        ? '#10B981'
                        : payload.signal === 'SELL'
                          ? '#EF4444'
                          : payload.signal === 'HOLD'
                            ? '#F59E0B'
                            : '#3B82F6'
                    return (
                      <g>
                        <circle cx={cx} cy={cy} r={r} fill={color} fillOpacity={0.7} stroke={color} strokeWidth={1.5} />
                        <text x={cx} y={cy + r + 12} textAnchor="middle" fill="#8A93A8" fontSize={10} fontFamily="JetBrains Mono">
                          {payload.ticker}
                        </text>
                      </g>
                    )
                  }}
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          {/* Legend */}
          <div className="mt-4 flex flex-wrap gap-4 justify-center">
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-[#10B981]" />
              <span className="text-[11px] text-[#8A93A8]">看涨</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-[#EF4444]" />
              <span className="text-[11px] text-[#8A93A8]">看跌</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-[#F59E0B]" />
              <span className="text-[11px] text-[#8A93A8]">持有</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-[#3B82F6]" />
              <span className="text-[11px] text-[#8A93A8]">观察</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-0.5 w-4 bg-[#D4AF37]" style={{ borderTop: '1px dashed #D4AF37' }} />
              <span className="text-[11px] text-[#8A93A8]">有效前沿</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-[#D4AF37]" />
              <span className="text-[11px] text-[#8A93A8]">大小 = 仓位权重</span>
            </div>
          </div>
        </div>
      </motion.section>
    </div>
  )
}
