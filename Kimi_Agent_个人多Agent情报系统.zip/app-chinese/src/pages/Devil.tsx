import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  AlertTriangle,
  ChevronDown,
  EyeOff,
  GitBranch,
  ArrowLeftRight,
  ShieldAlert,
  Circle,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible'

/* ─────────────────────────── types ─────────────────────────── */

interface ThesisBullet {
  lead: string
  explanation: string
}

interface ContrarianThesis {
  statement: string
  confidence: number
  bullets: ThesisBullet[]
}

interface RefutationArg {
  title: string
  bullets: string[]
}

interface Refutation {
  id: string
  topic: string
  systemView: string
  contrarianView: string
  severity: 'Fatal' | 'High' | 'Medium'
  systemArgument: RefutationArg
  contrarianRebuttal: RefutationArg
  blindSpot: string
  probabilityAdjustment: string
}

interface BlindSpot {
  category: string
  name: string
  description: string
  severity: 'High' | 'Medium' | 'Low'
  mitigation: string
}

interface AltScenario {
  title: string
  probability: number
  trigger: string
  marketImpact: { sp500: string; vix: string; yield10y: string }
  hedge: string
  historicalParallel: string
}

interface ProbCorrection {
  scenario: string
  baseline: number
  adjustment: number
  final: number
  rationale: string
}

interface ContrarianPosition {
  type: string
  asset: string
  direction: string
  rationale: string
  sizing: string
  conviction: string
}

interface DevilData {
  contrarianThesis: ContrarianThesis
  refutations: Refutation[]
  blindSpots: BlindSpot[]
  alternativeScenarios: AltScenario[]
  probabilityCorrections: ProbCorrection[]
  contrarianPositions: ContrarianPosition[]
  meta: { generatedAt: string; version: string }
}

/* ─────────────────────────── easing ─────────────────────────── */

const easeOut = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeInOut = [0.4, 0, 0.2, 1] as [number, number, number, number]

/* ─────────────────────────── severity colors ────────────────── */

const severityColor = (s: string) => {
  switch (s) {
    case 'Fatal':
      return { text: 'text-[#EF4444]', bg: 'bg-[rgba(239,68,68,0.12)]', border: 'border-[#EF4444]', dot: '#EF4444' }
    case 'High':
      return { text: 'text-[#F59E0B]', bg: 'bg-[rgba(245,158,11,0.12)]', border: 'border-[#F59E0B]', dot: '#F59E0B' }
    case 'Medium':
      return { text: 'text-[#F59E0B]', bg: 'bg-[rgba(245,158,11,0.12)]', border: 'border-[#F59E0B]', dot: '#F59E0B' }
    case 'Low':
      return { text: 'text-[#10B981]', bg: 'bg-[rgba(16,185,129,0.12)]', border: 'border-[#10B981]', dot: '#10B981' }
    default:
      return { text: 'text-[#8A93A8]', bg: 'bg-[rgba(255,255,255,0.06)]', border: 'border-[#8A93A8]', dot: '#8A93A8' }
  }
}

/* ─────────────────────────── component ──────────────────────── */

export default function Devil() {
  const [data, setData] = useState<DevilData | null>(null)
  const [openRefutations, setOpenRefutations] = useState<Set<string>>(new Set())

  useEffect(() => {
    fetch('./data/devil.json')
      .then((r) => r.json())
      .then(setData)
      .catch(console.error)
  }, [])

  const toggleRefutation = (id: string) => {
    setOpenRefutations((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  if (!data) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-[#8A93A8] font-mono text-sm">加载反驳者分析...</div>
      </div>
    )
  }

  const { contrarianThesis, refutations, blindSpots, alternativeScenarios, probabilityCorrections, contrarianPositions, meta } = data

  return (
    <div className="space-y-8 pb-12">
      {/* ═══════════════ HERO ═══════════════ */}
      <section
        className="relative rounded-xl p-8 md:p-10"
        style={{ background: 'radial-gradient(ellipse at 50% 50%, rgba(239,68,68,0.04) 0%, transparent 70%)' }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: easeOut }}
        >
          <div className="flex items-center gap-3 mb-3">
            <AlertTriangle className="h-6 w-6 text-[#EF4444]" />
            <h1
              className="text-[36px] font-bold tracking-[-0.02em] text-[#EF4444]"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              反驳者
            </h1>
          </div>
          <h2 className="text-[24px] font-bold tracking-[-0.01em] text-[#8A93A8] mb-4">
            对 conviction 进行压力测试
          </h2>
          <p className="text-[14px] leading-[1.7] text-[#8A93A8] max-w-[650px]">
            系统中的每一项分析都会在这里受到挑战。反驳者Agent故意寻找反对我们仓位的证据，以识别盲点并防止确认偏误。
            这些都是蓄意的反论——不是基准情景。
          </p>
          <p className="mt-4 text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase">
            生成时间: {meta.generatedAt.replace('T', ' ').replace('Z', '')}
          </p>
        </motion.div>
      </section>

      {/* ═══════════════ 反向论点 ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 relative overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 0 20px rgba(239,68,68,0.15)',
            borderLeft: '3px solid #EF4444',
          }}
        >
          <span className="text-[11px] font-medium tracking-[0.06em] text-[#EF4444] uppercase">
            反向论点
          </span>
          <p className="mt-3 text-[20px] font-bold tracking-[-0.01em] text-[#F0F2F8] leading-[1.4]">
            {contrarianThesis.statement}
          </p>
          <div className="mt-5 space-y-3">
            {contrarianThesis.bullets.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.1, duration: 0.4, ease: easeOut }}
                className="flex gap-3"
              >
                <span className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-[#EF4444]" />
                <div>
                  <span className="text-[14px] font-bold text-[#F0F2F8]">{b.lead}</span>
                  <span className="text-[13px] text-[#8A93A8] ml-2">{b.explanation}</span>
                </div>
              </motion.div>
            ))}
          </div>
          <p className="mt-5 text-[13px] text-[#5C6375]">
            反驳者信心: {contrarianThesis.confidence}%
          </p>
        </div>
      </motion.section>

      {/* ═══════════════ REFUTATION CARDS ═══════════════ */}
      <section>
        <h2 className="text-[24px] font-bold tracking-[-0.01em] text-[#F0F2F8] mb-5">
          逐条反驳
        </h2>
        <div className="space-y-4">
          {refutations.map((ref, idx) => {
            const sev = severityColor(ref.severity)
            const isOpen = openRefutations.has(ref.id)
            return (
              <motion.div
                key={ref.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + idx * 0.08, duration: 0.4, ease: easeOut }}
              >
                <Collapsible open={isOpen} onOpenChange={() => toggleRefutation(ref.id)}>
                  <div
                    className="rounded-lg border border-[rgba(255,255,255,0.06)] overflow-hidden"
                    style={{
                      background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
                      borderLeft: `3px solid ${sev.dot}`,
                    }}
                  >
                    <CollapsibleTrigger asChild>
                      <button className="w-full flex items-center justify-between p-5 text-left hover:bg-[#232837] transition-colors duration-200">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                          <span className="text-[18px] font-semibold text-[#F0F2F8]">{ref.topic}</span>
                          <div className="flex gap-2">
                            <span className="text-[11px] font-medium tracking-[0.06em] px-2.5 py-1 rounded-full bg-[rgba(16,185,129,0.12)] text-[#10B981] border border-[rgba(16,185,129,0.25)]">
                              我方观点: {ref.systemView}
                            </span>
                            <span className="text-[11px] font-medium tracking-[0.06em] px-2.5 py-1 rounded-full bg-[rgba(239,68,68,0.12)] text-[#EF4444] border border-[rgba(239,68,68,0.25)]">
                              反驳: {ref.contrarianView}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span
                            className={cn(
                              'text-[11px] font-bold tracking-[0.06em] px-2.5 py-1 rounded-full',
                              sev.bg,
                              sev.text
                            )}
                          >
                            {ref.severity}
                          </span>
                          <motion.div
                            animate={{ rotate: isOpen ? 180 : 0 }}
                            transition={{ duration: 0.35, ease: easeInOut }}
                          >
                            <ChevronDown className="h-5 w-5 text-[#8A93A8]" />
                          </motion.div>
                        </div>
                      </button>
                    </CollapsibleTrigger>

                    <CollapsibleContent>
                      <AnimatePresence>
                        {isOpen && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.1, duration: 0.3 }}
                            className="px-5 pb-5 space-y-4"
                          >
                            {/* System Argument */}
                            <div
                              className="rounded-lg p-4 border-l-[3px]"
                              style={{
                                background: 'rgba(16,185,129,0.08)',
                                borderLeftColor: '#10B981',
                              }}
                            >
                              <p className="text-[14px] font-bold text-[#F0F2F8] mb-2">
                                {ref.systemArgument.title}
                              </p>
                              <ul className="space-y-1.5">
                                {ref.systemArgument.bullets.map((b, i) => (
                                  <li key={i} className="text-[13px] text-[#8A93A8] flex gap-2">
                                    <span className="text-[#10B981]">+</span>
                                    {b}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Contrarian Rebuttal */}
                            <div
                              className="rounded-lg p-4 border-l-[3px]"
                              style={{
                                background: 'rgba(239,68,68,0.08)',
                                borderLeftColor: '#EF4444',
                              }}
                            >
                              <p className="text-[14px] font-bold text-[#F0F2F8] mb-2">
                                {ref.contrarianRebuttal.title}
                              </p>
                              <ul className="space-y-1.5">
                                {ref.contrarianRebuttal.bullets.map((b, i) => (
                                  <li key={i} className="text-[13px] text-[#8A93A8] flex gap-2">
                                    <span className="text-[#EF4444]">−</span>
                                    {b}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Blind Spot */}
                            <div
                              className="rounded-lg p-4 border-l-[3px]"
                              style={{
                                background: 'rgba(245,158,11,0.08)',
                                borderLeftColor: '#F59E0B',
                              }}
                            >
                              <p className="text-[13px] text-[#F0F2F8]">
                                <span className="font-bold">盲点: </span>
                                {ref.blindSpot}
                              </p>
                            </div>

                            {/* Probability Adjustment */}
                            <p className="text-[13px] text-[#5C6375] font-mono">
                              调整: {ref.probabilityAdjustment}
                            </p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              </motion.div>
            )
          })}
        </div>
      </section>

      {/* ═══════════════ 盲点矩阵 ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <EyeOff className="h-5 w-5 text-[#8A93A8]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">盲点矩阵</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {blindSpots.map((spot, idx) => {
              const sev = severityColor(spot.severity)
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + idx * 0.08, duration: 0.4, ease: easeOut }}
                  className="rounded-lg border border-[rgba(255,255,255,0.06)] p-4 bg-[#1C1F2B] hover:bg-[#232837] transition-colors duration-200"
                >
                  <span className="text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase">
                    {spot.category}
                  </span>
                  <p className="mt-2 text-[14px] font-bold text-[#F0F2F8]">{spot.name}</p>
                  <p className="mt-2 text-[13px] text-[#8A93A8] leading-[1.6]">{spot.description}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.7 + idx * 0.08, type: 'spring', stiffness: 500, damping: 15 }}
                    >
                      <Circle className="h-3 w-3 fill-current" style={{ color: sev.dot }} />
                    </motion.div>
                    <span className={cn('text-[11px] font-bold tracking-[0.06em] uppercase', sev.text)}>
                      {spot.severity}
                    </span>
                  </div>
                  <p className="mt-2 text-[12px] text-[#5C6375]">
                    <span className="text-[#D4AF37]">应对措施: </span>
                    {spot.mitigation}
                  </p>
                </motion.div>
              )
            })}
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ 替代情景 ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <GitBranch className="h-5 w-5 text-[#8A93A8]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">替代情景</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {alternativeScenarios.map((scenario, idx) => {
              const topBorder =
                idx === 0 ? '#EF4444' : idx === 1 ? '#F59E0B' : '#3B82F6'
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + idx * 0.15, duration: 0.5, ease: easeOut }}
                  className="rounded-lg border border-[rgba(255,255,255,0.06)] p-5 bg-[#1C1F2B] relative overflow-hidden"
                  style={{ borderTop: `3px solid ${topBorder}` }}
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-[18px] font-semibold text-[#F0F2F8] pr-16">{scenario.title}</h3>
                    <motion.span
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.9 + idx * 0.15, duration: 0.4 }}
                      className="absolute top-4 right-4 text-[14px] font-bold font-mono text-[#F0F2F8] bg-[#232837] px-2.5 py-1 rounded-full"
                    >
                      {scenario.probability}%
                    </motion.span>
                  </div>
                  <p className="text-[13px] text-[#8A93A8] mb-3">
                    <span className="text-[#5C6375]">触发条件: </span>
                    {scenario.trigger}
                  </p>
                  <div className="space-y-1.5 mb-3">
                    <div className="flex justify-between text-[13px]">
                      <span className="text-[#5C6375]">S&P 500</span>
                      <span className="font-mono text-[#EF4444]">{scenario.marketImpact.sp500}</span>
                    </div>
                    <div className="flex justify-between text-[13px]">
                      <span className="text-[#5C6375]">VIX</span>
                      <span className="font-mono text-[#F59E0B]">{scenario.marketImpact.vix}</span>
                    </div>
                    <div className="flex justify-between text-[13px]">
                      <span className="text-[#5C6375]">10Y Yield</span>
                      <span className="font-mono text-[#10B981]">{scenario.marketImpact.yield10y}</span>
                    </div>
                  </div>
                  <p className="text-[13px] text-[#D4AF37] mb-2">
                    <span className="text-[#5C6375]">对冲: </span>
                    {scenario.hedge}
                  </p>
                  <p className="text-[11px] text-[#5C6375] tracking-[0.06em] uppercase">
                    {scenario.historicalParallel}
                  </p>
                </motion.div>
              )
            })}
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ 概率修正 ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <ArrowLeftRight className="h-5 w-5 text-[#8A93A8]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">概率修正</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#1C1F2B]">
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3 rounded-tl-lg">
                    情景
                  </th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3">
                    基准
                  </th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3">
                    调整
                  </th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3">
                    最终
                  </th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3 w-[200px]">
                    变动
                  </th>
                  <th className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-4 py-3 rounded-tr-lg">
                    理由
                  </th>
                </tr>
              </thead>
              <tbody>
                {probabilityCorrections.map((row, idx) => {
                  const isUp = row.adjustment > 0
                  return (
                    <motion.tr
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.9 + idx * 0.06, duration: 0.4, ease: easeOut }}
                      className="border-t border-[rgba(255,255,255,0.06)] hover:bg-[#232837] transition-colors"
                    >
                      <td className="px-4 py-3 text-[14px] text-[#F0F2F8] font-medium">{row.scenario}</td>
                      <td className="px-4 py-3 text-[13px] font-mono text-[#5C6375]">{row.baseline}%</td>
                      <td
                        className={cn(
                          'px-4 py-3 text-[13px] font-mono font-bold',
                          isUp ? 'text-[#EF4444]' : 'text-[#10B981]'
                        )}
                      >
                        {isUp ? '+' : ''}
                        {row.adjustment}%
                      </td>
                      <td className="px-4 py-3 text-[13px] font-mono font-bold text-[#F0F2F8]">{row.final}%</td>
                      <td className="px-4 py-3">
                        <div className="relative h-3 bg-[#232837] rounded-full overflow-hidden">
                          {/* baseline marker */}
                          <div
                            className="absolute top-0 h-full w-1 bg-[#5C6375] rounded-full"
                            style={{ left: `${(row.baseline / 60) * 100}%` }}
                          />
                          {/* animated final marker */}
                          <motion.div
                            initial={{ left: `${(row.baseline / 60) * 100}%` }}
                            animate={{ left: `${(row.final / 60) * 100}%` }}
                            transition={{ delay: 1.2 + idx * 0.06, duration: 0.8, ease: easeOut }}
                            className={cn(
                              'absolute top-0 h-full w-1.5 rounded-full',
                              isUp ? 'bg-[#EF4444]' : 'bg-[#10B981]'
                            )}
                          />
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[13px] text-[#8A93A8]">{row.rationale}</td>
                    </motion.tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ CONTRARIAN POSITIONING ═══════════════ */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1, duration: 0.5, ease: easeOut }}
      >
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 relative overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            borderLeft: '3px solid #EF4444',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <ShieldAlert className="h-5 w-5 text-[#EF4444]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">反向对冲建议</h2>
          </div>
          <div className="space-y-4">
            {contrarianPositions.map((pos, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.1 + idx * 0.1, duration: 0.4, ease: easeOut }}
                className="flex flex-col sm:flex-row sm:items-center gap-3 p-4 rounded-lg bg-[#1C1F2B] border border-[rgba(255,255,255,0.06)]"
              >
                <span
                  className={cn(
                    'text-[11px] font-bold tracking-[0.06em] px-2.5 py-1 rounded-full shrink-0',
                    pos.type === 'HEDGE'
                      ? 'bg-[rgba(245,158,11,0.12)] text-[#F59E0B]'
                      : 'bg-[rgba(239,68,68,0.12)] text-[#EF4444]'
                  )}
                >
                  {pos.type === 'HEDGE' ? '对冲' : pos.type === 'DIRECTIONAL' ? '方向性' : pos.type}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] font-bold text-[#F0F2F8]">{pos.asset}</p>
                  <p className="text-[13px] text-[#8A93A8]">{pos.rationale}</p>
                </div>
                <div className="flex flex-wrap gap-3 shrink-0">
                  <span
                    className={cn(
                      'text-[11px] font-mono',
                      pos.direction.includes('SHORT') ? 'text-[#EF4444]' : 'text-[#10B981]'
                    )}
                  >
                    {pos.direction}
                  </span>
                  <span className="text-[11px] text-[#5C6375]">{pos.sizing}</span>
                  <span
                    className={cn(
                      'text-[11px] font-bold',
                      pos.conviction === 'High'
                        ? 'text-[#EF4444]'
                        : pos.conviction === 'Medium'
                          ? 'text-[#F59E0B]'
                          : 'text-[#8A93A8]'
                    )}
                  >
                    {pos.conviction}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
          <p className="mt-5 text-[13px] text-[#5C6375] italic">
            这些是蓄意的反向头寸，旨在对冲核心组合风险。如果基准情景实现，它们可能跑输大盘。
          </p>
        </div>
      </motion.section>
    </div>
  )
}
