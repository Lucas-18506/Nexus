# TradingAgents-cn-PLUS 深度架构分析报告

## 项目概况

| 维度 | 详情 |
|------|------|
| **Stars** | 158 |
| **Forks** | 60 |
| **技术栈** | Python 96.1%, Streamlit前端, LangChain/LangGraph, MongoDB |
| **核心架构** | 多智能体(Multi-Agent)交易系统 |
| **原作者** | Tauric Research (TradingAgents) |
| **二次开发** | oficcejo (PLUS运营版) |

---

## 一、大模型可切换设计（最核心价值）

### 1.1 架构模式：适配器模式 + 工厂模式

```
┌─────────────────────────────────────────────────────────────┐
│                     LLM Provider Layer                       │
├─────────────┬─────────────┬─────────────┬─────────────────┤
│  阿里百炼   │   DeepSeek   │   OpenAI    │   Google Gemini │
│ DashScope   │              │             │                 │
├─────────────┼─────────────┼─────────────┼─────────────────┤
│  硅基流动   │  OpenRouter  │   Claude    │   千帆大模型    │
│ SiliconFlow │  (50+模型)   │  Anthropic  │  (百度)         │
├─────────────┴─────────────┴─────────────┴─────────────────┤
│              OpenAICompatibleBase (基类)                    │
│         继承 ChatOpenAI (LangChain)                         │
│         统一接口: chat, stream, async                       │
├─────────────────────────────────────────────────────────────┤
│              config_manager.py (配置管理器)                  │
│         根据环境变量自动切换provider                         │
│         Token用量跟踪                                        │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 关键实现文件

| 文件 | 功能 |
|------|------|
| `llm_adapters/openai_compatible_base.py` | 基类，435行，提供统一接口 |
| `llm_adapters/dashscope_adapter.py` | 阿里百炼适配器 |
| `llm_adapters/deepseek_adapter.py` | DeepSeek适配器 |
| `llm_adapters/deepseek_direct_adapter.py` | DeepSeek直连适配器 |
| `llm_adapters/google_openai_adapter.py` | Google Gemini适配器 |
| `config/config_manager.py` | 配置管理器，自动切换provider |

### 1.3 环境变量配置（.env）

```bash
# 核心LLM提供商（至少配置一个）
DASHSCOPE_API_KEY=xxx          # 阿里百炼
DEEPSEEK_API_KEY=xxx           # DeepSeek（推荐，性价比最高）
DEEPSEEK_ENABLED=true
OPENAI_API_KEY=xxx             # OpenAI
OPENROUTER_API_KEY=xxx         # OpenRouter（50+模型聚合）
ANTHROPIC_API_KEY=xxx          # Claude
GOOGLE_API_KEY=xxx             # Gemini
SILICONFLOW_API_KEY=xxx        # 硅基流动

# 默认配置
DEFAULT_CHINA_DATA_SOURCE=akshare   # 中国数据源切换
```

### 1.4 配置切换逻辑

```python
# main.py 中切换模型的方式
config = DEFAULT_CONFIG.copy()
config["llm_provider"] = "google"
config["backend_url"] = "https://generativelanguage.googleapis.com/v1"
config["deep_think_llm"] = "gemini-2.0-flash"      # 深度思考模型
config["quick_think_llm"] = "gemini-2.0-flash"      # 快速思考模型
```

**双模型策略**：
- `deep_think_llm`：复杂分析任务（如风险分析、辩论）
- `quick_think_llm`：简单任务（如数据查询、格式化）

---

## 二、数据源接入架构

### 2.1 数据源管理器模式

```
┌──────────────────────────────────────────────────────┐
│               Data Source Manager                     │
│          (dataflows/data_source_manager.py)           │
├──────────────┬──────────────┬───────────────────────┤
│   美股数据    │   A股数据     │      港股数据         │
│              │              │                       │
│  FinnHub     │  AKShare     │   HK Stock Utils      │
│  (API Key)   │  (免费)      │   (实时行情)          │
│              │              │                       │
│  Yahoo       │  Tushare     │   Improved HK Utils   │
│  Finance     │  (Token)     │   (增强版)            │
│              │              │                       │
│              │  Baostock    │                       │
│              │  (免费)      │                       │
├──────────────┴──────────────┴───────────────────────┤
│               Cache Layer                             │
│  (adaptive_cache.py / db_cache_manager.py)           │
│  - MongoDB持久化缓存                                 │
│  - 智能过期策略                                       │
│  - 离线数据保护                                       │
└──────────────────────────────────────────────────────┘
```

### 2.2 数据源工具清单

| 文件 | 数据源 | 覆盖市场 | 成本 |
|------|--------|---------|------|
| `finnhub_utils.py` | FinnHub API | 美股/全球 | 免费60次/分 |
| `akshare_utils.py` | AKShare | A股/期货/宏观 | 免费 |
| `chinese_finance_utils.py` | 中国金融数据聚合 | A股/债券 | 免费 |
| `tushare_config.py` | Tushare Pro | A股/港股/美股 | 积分制 |
| `hk_stock_utils.py` | 港股数据 | 港股 | 免费 |
| `optimized_china_data.py` | 优化中国数据 | A股 | 免费 |
| `googlenews_utils.py` | Google News | 全球新闻 | 免费 |

### 2.3 缓存架构

```
三层缓存体系:
1. 内存缓存 (interface.py)      → 热数据，毫秒级
2. 文件缓存 (cache_manager.py)  → 温数据，分钟级
3. MongoDB (db_cache_manager.py) → 冷数据，持久化
```

---

## 三、多智能体架构（Multi-Agent）

### 3.1 智能体角色

```
┌─────────────────────────────────────────────────────┐
│                 TradingAgentsGraph                   │
│              (LangGraph 编排引擎)                     │
├────────────┬────────────┬────────────┬──────────────┤
│  研究智能体 │  分析师     │  管理智能体 │  风险管理     │
│ Researchers│  Analysts  │  Managers  │  Risk Mgmt   │
├────────────┼────────────┼────────────┼──────────────┤
│ • 宏观研究  │ • 技术分析师│ • 辩论管理  │ • 风险评估    │
│ • 行业研究  │ • 基本面   │ • 信号管理  │ • 压力测试    │
│ • 公司研究  │ • 量化分析师│ • 决策管理  │ • 尾部风险    │
│ • 新闻研究  │            │            │              │
├────────────┴────────────┴────────────┴──────────────┤
│                   交易智能体                          │
│                   Trader                              │
│              (最终决策/执行)                          │
└─────────────────────────────────────────────────────┘
```

### 3.2 工作流

1. **输入**：股票代码 + 日期
2. **研究阶段**：多个研究智能体并行收集数据
3. **分析阶段**：分析师智能体进行技术面/基本面/量化分析
4. **辩论阶段**：多空观点辩论（可配置轮数）
5. **风险管理**：风险评估和压力测试
6. **决策阶段**：综合所有信息生成交易决策

---

## 四、可融合到IWM系统的功能清单

### 🔴 P0 — 立即实施（架构级改进）

| 功能 | 来源 | IWM实现位置 | 工作量 | 说明 |
|------|------|------------|--------|------|
| **大模型切换面板** | `.env` + `config_manager.py` | 设置页面/全局 | 4h | 支持DeepSeek/OpenAI/Claude/Gemini切换，存储API Key |
| **双模型策略配置** | `default_config.py` | 设置页面 | 2h | 分析模型+快速模型分别配置 |
| **数据源配置面板** | `data_source_manager.py` | 设置页面 | 3h | FinnHub/AKShare/Tushare API Key管理 |
| **数据源切换器** | `DEFAULT_CHINA_DATA_SOURCE` | 宏观/公司页面 | 2h | A股数据源切换(akshare/tushare/baostock) |

### 🟡 P1 — 高优先级（分析能力增强）

| 功能 | 来源 | IWM实现位置 | 工作量 | 说明 |
|------|------|------------|--------|------|
| **LLM分析代理** | `agents/analysts/` | 公司/行业页面 | 6h | 接入LLM进行AI分析摘要生成 |
| **多空辩论系统** | `max_debate_rounds` | 反驳者页面增强 | 4h | AI生成多空观点辩论 |
| **智能缓存系统** | `cache_manager.py` | 全局数据层 | 4h | localStorage+IndexedDB缓存 |
| **批量分析** | `demo_batch_analysis.py` | 行业页面增强 | 3h | 一次性分析多个标的 |
| **Token用量追踪** | `token_tracker` | 设置页面 | 2h | 显示各模型Token消耗 |

### 🟢 P2 — 中优先级（运营级功能）

| 功能 | 来源 | IWM实现位置 | 工作量 | 说明 |
|------|------|------------|--------|------|
| **离线模式** | `adaptive_cache.py` | 全局 | 3h | 网络断开时显示缓存数据 |
| **数据导出** | `reports/` | 各页面 | 2h | PDF/Excel报告导出 |
| **分析历史** | `mongodb_storage.py` | 新增页面 | 4h | 保存每次分析结果到本地 |
| **智能提醒** | `trading_graph.py` | 仪表盘 | 3h | 关键信号/风险提醒 |

---

## 五、具体融合方案

### 5.1 大模型切换面板设计

参考 `.env` 配置，设计React组件：

```tsx
// settings/LLMConfig.tsx
interface LLMProvider {
  id: string;           // 'deepseek' | 'openai' | 'anthropic' | 'google' | 'dashscope'
  name: string;         // 显示名称
  apiKeyEnvVar: string; // API Key环境变量名
  baseUrl: string;      // API基础URL
  models: string[];     // 可用模型列表
  enabled: boolean;     // 是否启用
}

const PROVIDERS: LLMProvider[] = [
  { id: 'deepseek', name: 'DeepSeek', apiKeyEnvVar: 'DEEPSEEK_API_KEY', 
    baseUrl: 'https://api.deepseek.com', models: ['deepseek-chat', 'deepseek-coder'], enabled: false },
  { id: 'openai', name: 'OpenAI', apiKeyEnvVar: 'OPENAI_API_KEY',
    baseUrl: 'https://api.openai.com/v1', models: ['gpt-4o', 'gpt-4o-mini', 'o3-mini'], enabled: false },
  { id: 'anthropic', name: 'Claude', apiKeyEnvVar: 'ANTHROPIC_API_KEY',
    baseUrl: 'https://api.anthropic.com', models: ['claude-3-5-sonnet', 'claude-3-haiku'], enabled: false },
  { id: 'google', name: 'Gemini', apiKeyEnvVar: 'GOOGLE_API_KEY',
    baseUrl: 'https://generativelanguage.googleapis.com', models: ['gemini-2.0-flash', 'gemini-1.5-pro'], enabled: false },
  { id: 'dashscope', name: '阿里百炼', apiKeyEnvVar: 'DASHSCOPE_API_KEY',
    baseUrl: 'https://dashscope.aliyuncs.com', models: ['qwen-max', 'qwen-plus'], enabled: false },
];
```

### 5.2 数据源配置面板设计

```tsx
// settings/DataSourceConfig.tsx
interface DataSource {
  id: string;       // 'finnhub' | 'akshare' | 'tushare' | 'baostock'
  name: string;     // 显示名称
  market: string;   // 覆盖市场
  apiKeyRequired: boolean;
  freeTier: string; // 免费额度说明
}

const DATA_SOURCES: DataSource[] = [
  { id: 'finnhub', name: 'FinnHub', market: '美股/全球', apiKeyRequired: true, freeTier: '60次/分' },
  { id: 'akshare', name: 'AKShare', market: 'A股/期货/宏观', apiKeyRequired: false, freeTier: '完全免费' },
  { id: 'tushare', name: 'Tushare Pro', market: 'A股/港股/美股', apiKeyRequired: true, freeTier: '积分制' },
  { id: 'baostock', name: 'Baostock', market: 'A股/港股', apiKeyRequired: false, freeTier: '完全免费' },
];
```

### 5.3 智能体工作流在IWM中的映射

```
TradingAgents工作流 → IWM页面映射:

宏观研究 → 宏观情绪页面 (Macro.tsx)
行业研究 → 行业深度页面 (Industry.tsx)  
公司研究 → 公司分析页面 (Company.tsx)
新闻研究 → 早报/晚报页面 (MorningReport.tsx / EveningReport.tsx)
技术分析 → 公司分析-K线图 (Company.tsx PriceChart)
多空辩论 → 反驳者页面 (Devil.tsx)
风险管理 → 风险评估矩阵 (MorningReport.tsx)
综合决策 → CIO汇总页面 (CIO.tsx)
```

---

## 六、与IWM系统的技术栈对比

| 维度 | TradingAgents-cn-PLUS | IWM系统 | 融合策略 |
|------|----------------------|---------|---------|
| **语言** | Python 96% | TypeScript/React | IWM保持TS，增加Python后端 |
| **前端** | Streamlit | React 19 + Tailwind | IWM前端更优，保持 |
| **LLM框架** | LangChain/LangGraph | 无 | IWM引入LangChain.js |
| **图表** | 无（文本输出） | Recharts + Lightweight Charts | IWM更优，保持 |
| **数据源** | FinnHub/AKShare/Tushare | 静态JSON | IWM接入实时数据源 |
| **缓存** | MongoDB + 文件 | 无 | IWM增加IndexedDB缓存 |
| **智能体** | 6类20+智能体 | 无 | IWM增加AI分析代理 |

---

## 七、实施路线图

```
第1阶段（1-2天）: P0架构级改进
  ├── 大模型切换面板（Settings页面）
  ├── API Key加密存储（localStorage）
  ├── 数据源配置面板
  └── 数据源切换器（A股）

第2阶段（2-3天）: P1分析能力增强
  ├── LLM分析代理（公司/行业页面）
  ├── 多空辩论AI生成（反驳者页面增强）
  ├── 智能缓存系统（IndexedDB）
  └── Token用量追踪

第3阶段（3-5天）: P2运营级功能
  ├── 离线模式
  ├── 数据导出（PDF/Excel）
  ├── 分析历史
  └── 智能提醒
```
