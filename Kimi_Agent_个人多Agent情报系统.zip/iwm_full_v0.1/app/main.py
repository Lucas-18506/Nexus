"""FastAPI应用主入口"""
from fastapi import FastAPI
from contextlib import asynccontextmanager

from app.api import data, news, kb, thesis, report, agent


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时初始化
    print("IWM starting up...")
    yield
    # 关闭时清理
    print("IWM shutting down...")


app = FastAPI(
    title="IWM Investment Advisor",
    description="个人AI投资参谋系统",
    version="0.1.0",
    lifespan=lifespan
)

# 注册路由
app.include_router(data.router)
app.include_router(news.router)
app.include_router(kb.router)
app.include_router(thesis.router)
app.include_router(report.router)
app.include_router(agent.router)


@app.get("/health")
async def health_check() -> dict:
    """健康检查接口"""
    return {"status": "ok", "version": "0.1.0", "service": "iwm"}
