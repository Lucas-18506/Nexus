# IWM前端汉化计划

## 目标
将所有用户可见的英文文本翻译为中文，包括组件标签、页面标题、描述、按钮文本、Mock数据内容等。

## 策略
保持代码结构不变，仅翻译用户可见的字符串字面量。专业术语（如VIX、RSI、MACD、P/E等）保留英文。

## 分组（5组并行）

### 组1: 共享组件汉化
- Navbar.tsx: 8个导航项 (Dashboard→仪表盘, Macro & Sentiment→宏观情绪...)
- TopBar.tsx: 默认标题
- SentimentGauge.tsx: EXTREME FEAR→极度恐慌 等
- SignalTable.tsx: 列标题
- VerdictBadge.tsx: 判决标签（如BULLISH→看涨等）

### 组2: 仪表盘+宏观+早报+晚报页面
- Home.tsx: Dashboard所有文本
- Macro.tsx: 宏观指标标签、图表标题等
- MorningReport.tsx: 早报所有文本
- EveningReport.tsx: 晚报所有文本

### 组3: 行业+公司页面
- Industry.tsx: 行业分析所有文本
- Company.tsx: 公司分析所有文本

### 组4: 反驳者+CIO页面
- Devil.tsx: 反驳者所有文本
- CIO.tsx: CIO汇总所有文本

### 组5: Mock数据汉化
- 15个JSON文件中的英文内容

## 执行流程
1. 创建chinese分支
2. 5组agent并行汉化
3. 合并所有更改
4. 构建+部署
