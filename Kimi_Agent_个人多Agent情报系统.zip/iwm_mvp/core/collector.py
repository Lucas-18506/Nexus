"""IWM MVP - 数据采集（通过外部工具调用，本地存储结果）"""
import json
from pathlib import Path
from datetime import datetime, timedelta

ROOT = Path(__file__).parent.parent


def load_config() -> dict:
    """加载配置"""
    config_path = ROOT / "config.json"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


class MacroCollector:
    """宏观数据采集 - 输出结果供主Agent调用yahoo_finance工具"""

    TARGETS = [
        {"name": "US_10Y_Yield", "ticker": "^TNX", "indicator_type": "rate", "country": "US", "unit": "%"},
        {"name": "US_2Y_Yield", "ticker": "^IRX", "indicator_type": "rate", "country": "US", "unit": "%"},
        {"name": "US_30Y_Yield", "ticker": "^TYX", "indicator_type": "rate", "country": "US", "unit": "%"},
        {"name": "DXY", "ticker": "DX-Y.NYB", "indicator_type": "fx", "country": "US", "unit": "index"},
        {"name": "USD_CNY", "ticker": "CNY=X", "indicator_type": "fx", "country": "CN", "unit": "CNY/USD"},
        {"name": "VIX", "ticker": "^VIX", "indicator_type": "volatility", "country": "US", "unit": "index"},
    ]

    def get_targets(self) -> list:
        """返回需要采集的指标列表（供主Agent调用yahoo_finance）"""
        return self.TARGETS

    def format_result(self, name: str, ticker: str, raw_data: dict) -> dict:
        """将yahoo_finance原始数据格式化为标准化宏观指标"""
        prices = raw_data.get("prices", [])
        if not prices:
            return None
        latest = prices[-1]
        prev = prices[-2] if len(prices) > 1 else latest
        return {
            "indicator_name": name,
            "ticker": ticker,
            "indicator_type": next((t["indicator_type"] for t in self.TARGETS if t["name"] == name), "other"),
            "country": next((t["country"] for t in self.TARGETS if t["name"] == name), ""),
            "current_value": round(latest.get("close", latest.get("adjclose", 0)), 4),
            "previous_value": round(prev.get("close", prev.get("adjclose", 0)), 4),
            "change_pct": round((latest.get("close", 0) - prev.get("close", 0)) / prev.get("close", 1) * 100, 4) if prev.get("close") else 0,
            "unit": next((t["unit"] for t in self.TARGETS if t["name"] == name), ""),
            "date": latest.get("date", ""),
            "collected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }


class StockCollector:
    """个股数据采集"""

    def get_watchlist(self) -> list:
        """返回关注列表（供主Agent调用yahoo_finance）"""
        config = load_config()
        return config.get("watchlist", [])

    def format_quote(self, ticker: str, market: str, raw_data: dict) -> dict:
        """格式化实时报价"""
        info = raw_data.get("info", {})
        return {
            "ticker": ticker,
            "market": market,
            "name": info.get("longName", ticker),
            "price": info.get("currentPrice", info.get("regularMarketPrice", 0)),
            "change": info.get("regularMarketChange", 0),
            "change_pct": info.get("regularMarketChangePercent", 0),
            "pe_ratio": info.get("trailingPE", info.get("forwardPE", None)),
            "pb_ratio": info.get("priceToBook", None),
            "ps_ratio": info.get("priceToSalesTrailing12Months", None),
            "market_cap": info.get("marketCap", None),
            "52w_high": info.get("fiftyTwoWeekHigh", None),
            "52w_low": info.get("fiftyTwoWeekLow", None),
            "collected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }


class NewsCollector:
    """新闻数据采集 - 输出搜索查询供主Agent调用web_search"""

    def get_search_queries(self) -> list:
        """返回需要搜索的新闻查询"""
        config = load_config()
        return config.get("news_keywords", [])

    def format_results(self, search_results: list) -> list:
        """将web_search结果格式化为标准化新闻"""
        news_items = []
        for result in search_results:
            if isinstance(result, str):
                # 简单解析
                news_items.append({
                    "title": result[:100],
                    "content": result,
                    "source": "",
                    "url": "",
                    "published_at": "",
                    "category": "",
                    "related_tickers": [],
                    "related_industries": [],
                    "collected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })
            elif isinstance(result, dict):
                news_items.append({
                    "title": result.get("title", "")[:200],
                    "content": result.get("content", result.get("snippet", "")),
                    "source": result.get("source", ""),
                    "url": result.get("url", ""),
                    "published_at": result.get("published", ""),
                    "category": self._classify_category(result.get("title", "") + " " + result.get("content", "")),
                    "related_tickers": self._extract_tickers(result.get("title", "") + " " + result.get("content", "")),
                    "related_industries": [],
                    "collected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })
        return news_items

    def _classify_category(self, text: str) -> str:
        text_lower = text.lower()
        if any(k in text_lower for k in ["fed", "rate", "cpi", "pmi", "gdp", "inflation", "recession"]):
            return "macro"
        elif any(k in text_lower for k in ["ai", "chip", "semiconductor", "gpu", "nvidia"]):
            return "industry"
        elif any(k in text_lower for k in ["earnings", "revenue", "profit", "guidance", "beat", "miss"]):
            return "earnings"
        elif any(k in text_lower for k in ["bitcoin", "crypto", "etf", "blockchain"]):
            return "crypto"
        elif any(k in text_lower for k in ["tariff", "trade", "sanction", "export"]):
            return "policy"
        return "market"

    def _extract_tickers(self, text: str) -> list:
        import re
        # 简单提取大写股票代码
        patterns = [
            r'\b(NVDA|TSLA|AAPL|MSFT|AMD|COIN|INTC|QCOM|AVGO|MU|TSM|ASML|ARM)\b',
            r'\b(BYD|CATL|NIO|XPEV|LI)\b',
            r'\b0700\.HK\b', r'\b9988\.HK\b', r'\b1211\.HK\b', r'\b1810\.HK\b',
        ]
        tickers = set()
        for p in patterns:
            for match in re.finditer(p, text, re.IGNORECASE):
                tickers.add(match.group().upper())
        return sorted(tickers)
