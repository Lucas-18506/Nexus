"""IWM MVP - 配置管理（纯JSON文件，零依赖）"""
import json
from pathlib import Path

CONFIG_PATH = Path(__file__).parent.parent / "config.json"

DEFAULT_CONFIG = {
    "user": {
        "name": " investor",
        "risk_level": "medium",
        "focus_markets": ["US", "HK", "CN"]
    },
    "watchlist": [
        {"ticker": "NVDA", "market": "US", "name": "英伟达", "reason": "AI芯片龙头"},
        {"ticker": "TSLA", "market": "US", "name": "特斯拉", "reason": "电动车+能源"},
        {"ticker": "AAPL", "market": "US", "name": "苹果", "reason": "消费电子生态"},
        {"ticker": "MSFT", "market": "US", "name": "微软", "reason": "云计算+AI"},
        {"ticker": "AMD", "market": "US", "name": "AMD", "reason": "CPU/GPU双轮驱动"},
        {"ticker": "COIN", "market": "US", "name": "Coinbase", "reason": "加密货币交易所"},
        {"ticker": "0700.HK", "market": "HK", "name": "腾讯", "reason": "游戏+社交+投资"},
        {"ticker": "9988.HK", "market": "HK", "name": "阿里巴巴", "reason": "电商+云计算"},
        {"ticker": "1211.HK", "market": "HK", "name": "比亚迪", "reason": "新能源汽车龙头"},
        {"ticker": "1810.HK", "market": "HK", "name": "小米", "reason": "手机+IoT+汽车"},
    ],
    "focus_industries": ["AI", "半导体", "新能源汽车", "电力", "稳定币", "消费电子", "机器人"],
    "macro_indicators": [
        {"name": "US_10Y_Yield", "ticker": "^TNX", "desc": "美国10年期国债收益率"},
        {"name": "US_2Y_Yield", "ticker": "^IRX", "desc": "美国2年期国债收益率"},
        {"name": "DXY", "ticker": "DX-Y.NYB", "desc": "美元指数"},
        {"name": "USD_CNY", "ticker": "CNY=X", "desc": "美元兑人民币"},
        {"name": "VIX", "ticker": "^VIX", "desc": "恐慌指数"},
    ],
    "news_keywords": [
        "AI artificial intelligence NVIDIA investment",
        "semiconductor chip earnings TSMC",
        "Federal Reserve interest rate inflation",
        "China economy PMI stimulus",
        "Bitcoin cryptocurrency ETF",
        "EV electric vehicle BYD Tesla battery",
        "tariff trade war export control"
    ],
    "agent_weights": {
        "macro_analyst": 0.15,
        "industry_analyst": 0.20,
        "supply_chain_analyst": 0.12,
        "scarcity_analyst": 0.15,
        "company_analyst": 0.10,
        "sentiment_analyst": 0.05,
        "risk_analyst": 0.08,
        "devil_advocate": 0.10,
        "cio_synthesizer": 0.00
    },
    "report": {
        "daily_max_events": 10,
        "daily_max_opportunities": 5,
        "min_opportunity_score": 60,
        "output_dir": "reports"
    }
}


def load_config() -> dict:
    """加载配置，不存在则创建默认配置"""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    save_config(DEFAULT_CONFIG)
    return DEFAULT_CONFIG


def save_config(config: dict):
    """保存配置到JSON"""
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def get_project_root() -> Path:
    """获取项目根目录"""
    return Path(__file__).parent.parent
