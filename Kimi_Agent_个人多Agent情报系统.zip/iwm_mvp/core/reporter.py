"""IWM MVP - 报告渲染器（纯字符串模板，零依赖）"""
from datetime import datetime
from typing import List, Dict


def render_daily_report(
    date: str,
    macro_summary: str,
    market_overview: str,
    top_events: List[Dict],
    committee_report: Dict,
    watchlist_updates: List[Dict],
    risk_warnings: List[str],
    new_opportunities: List[Dict],
) -> str:
    """渲染日报Markdown"""

    # 事件列表
    events_md = ""
    for i, ev in enumerate(top_events[:10], 1):
        events_md += f"""### {i}. {ev.get('title', 'N/A')}
- **摘要**: {ev.get('summary', ev.get('content', '无摘要')[:200])}
- **影响级别**: {"★" * ev.get('impact_level', 0)}{"☆" * (5 - ev.get('impact_level', 0))}
- **情感**: {ev.get('sentiment', '中性')}
- **相关**: {', '.join(ev.get('related_tickers', [])[:5]) or '无'}

"""

    # 支持观点
    supporting_md = "\n".join(f"- {v}" for v in committee_report.get('supporting_views', [])) or "- 暂无明确支持观点"

    # 反对观点
    opposing_md = "\n".join(f"- ⚡ {v}" for v in committee_report.get('opposing_views', [])) or "- 暂无明确反对观点"

    # 风险提示
    risks_md = "\n".join(f"- ⚠️ {r}" for r in risk_warnings) or "- 暂无重大风险"

    # 持仓/关注更新
    watch_md = "\n".join(
        f"- **{w.get('ticker', '')}** ({w.get('name', '')}): {w.get('update', '无更新')}"
        for w in watchlist_updates
    ) or "- 关注列表无重大变化"

    # 新机会
    opp_md = ""
    for opp in new_opportunities[:5]:
        opp_md += f"""### {opp.get('title', '机会')}
- **行业**: {opp.get('industry', 'N/A')} | **评分**: {opp.get('score', 'N/A')}/100
- **核心逻辑**: {opp.get('logic', 'N/A')}
- **催化剂**: {opp.get('catalyst', 'N/A')}
- **置信度**: {opp.get('confidence', 'N/A')}/1.0

"""
    if not opp_md:
        opp_md = "- 今日未发现明显新机会\n"

    # Agent贡献
    agent_contributions_md = ""
    for agent_name, contribution in committee_report.get('agent_contributions', {}).items():
        agent_contributions_md += f"- **{agent_name}**: {contribution.get('conclusion', 'N/A')[:80]}... (置信度: {contribution.get('confidence', 'N/A')})\n"

    # CIO结论
    cio = committee_report.get('cio', {})

    report = f"""# IWM 投资参谋日报 - {date}

> **系统状态**: Agent委员会分析完成 | **CIO置信度**: {cio.get('confidence', 'N/A')}/1.0
> **整体判断**: {cio.get('probability_assessment', 'N/A')}

---

## 1. 宏观环境速览
{macro_summary}

## 2. 市场概况
{market_overview}

---

## 3. 今日重点事件
{events_md}
---

## 4. Agent委员会分析

### 4.1 各Agent独立分析摘要
{agent_contributions_md}

### 4.2 CIO最终判断
**{cio.get('conclusion', '分析进行中...')}**

- **概率分布**: 看涨 {cio.get('bullish_prob', 'N/A')}% / 中性 {cio.get('neutral_prob', 'N/A')}% / 看跌 {cio.get('bearish_prob', 'N/A')}%
- **最大风险**: {cio.get('max_risk', 'N/A')}
- **风险收益**: {cio.get('risk_reward', 'N/A')}
- **操作建议**: {cio.get('action_suggestion', 'N/A')}

---

## 5. 支持观点
{supporting_md}

## 6. 反对观点（Devil's Advocate）
{opposing_md}

---

## 7. 关注标动态
{watch_md}

---

## 8. 风险提示
{risks_md}

---

## 9. 新发现机会
{opp_md}---

*生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M")}*
*本报告由 IWM Agent委员会自动生成 | 仅供个人研究参考*
*下次更新: {date} 09:00*
"""
    return report


def render_opportunity_report(opp: Dict, committee_analysis: Dict) -> str:
    """渲染单个机会的深度分析报告"""
    return f"""# 机会深度分析: {opp.get('title', 'N/A')}

## 基本信息
- **行业**: {opp.get('industry', 'N/A')}
- **主题**: {opp.get('theme', 'N/A')}
- **催化剂**: {opp.get('catalyst', 'N/A')}
- **机会评分**: {opp.get('score', 'N/A')}/100
- **风险评分**: {opp.get('risk_score', 'N/A')}/100
- **置信度**: {opp.get('confidence', 'N/A')}/1.0
- **阶段**: {opp.get('stage', 'N/A')}

## Agent委员会分析
{committee_analysis.get('conclusion', 'N/A')}

## 产业链分析
{committee_analysis.get('supply_chain', 'N/A')}

## 稀缺性评估
{committee_analysis.get('scarcity', 'N/A')}

## 估值分析
{committee_analysis.get('valuation', 'N/A')}

## 风险评估
{committee_analysis.get('risk', 'N/A')}

## 反驳意见（Devil's Advocate）
{committee_analysis.get('devil_refutation', 'N/A')}

## 操作建议
{committee_analysis.get('action', 'N/A')}

---
*分析时间: {datetime.now().strftime("%Y-%m-%d %H:%M")}*
"""


def render_industry_report(industry: Dict, committee_analysis: Dict) -> str:
    """渲染行业深度报告"""
    companies = "\n".join(f"- {c}" for c in industry.get('key_companies', []))
    drivers = "\n".join(f"- {d}" for d in industry.get('key_drivers', []))
    risks = "\n".join(f"- {r}" for r in industry.get('risk_factors', []))

    return f"""# 行业深度: {industry.get('name', 'N/A')}

## 行业概况
- **生命周期**: {industry.get('lifecycle_stage', 'N/A')}
- **景气度**: {industry.get('prosperity', 'N/A')}
- **核心驱动**: {industry.get('core_driver', 'N/A')}

## 关键驱动因素
{drivers or '- 暂无'}

## 产业链结构
{industry.get('supply_chain', 'N/A')}

## 瓶颈环节
{industry.get('bottleneck', 'N/A')}

## 主要公司
{companies or '- 暂无'}

## Agent委员会分析
{committee_analysis.get('conclusion', 'N/A')}

## 稀缺性分析
{committee_analysis.get('scarcity', 'N/A')}

## 风险因素
{risks or '- 暂无'}

## 机会判断
{committee_analysis.get('opportunities', 'N/A')}

---
*分析时间: {datetime.now().strftime("%Y-%m-%d %H:%M")}*
"""
