"""IWM MVP - 知识库管理（纯JSON文件存储，零依赖）"""
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

ROOT = Path(__file__).parent.parent
KB_DIR = ROOT / "kb_data"
DATA_DIR = ROOT / "data"
REPORT_DIR = ROOT / "reports"

# 确保目录存在
for d in [KB_DIR, DATA_DIR / "macro", DATA_DIR / "news", REPORT_DIR]:
    d.mkdir(parents=True, exist_ok=True)


class KnowledgeBase:
    """知识库管理 - 行业/公司/Thesis的CRUD"""

    def __init__(self):
        self.industries_file = KB_DIR / "industries.json"
        self.companies_file = KB_DIR / "companies.json"
        self.theses_file = KB_DIR / "theses.json"

    # ---- 行业 ----
    def list_industries(self) -> list:
        return self._load(self.industries_file)

    def get_industry(self, name: str) -> Optional[dict]:
        for ind in self.list_industries():
            if ind["name"] == name:
                return ind
        return None

    def upsert_industry(self, data: dict):
        items = self._load(self.industries_file)
        for i, item in enumerate(items):
            if item["name"] == data["name"]:
                items[i] = {**item, **data, "updated_at": now()}
                self._save(self.industries_file, items)
                return
        data["created_at"] = now()
        data["updated_at"] = now()
        items.append(data)
        self._save(self.industries_file, items)

    # ---- 公司 ----
    def list_companies(self, industry: str = None) -> list:
        items = self._load(self.companies_file)
        if industry:
            items = [c for c in items if c.get("industry") == industry]
        return items

    def get_company(self, ticker: str, market: str) -> Optional[dict]:
        for c in self.list_companies():
            if c["ticker"] == ticker and c["market"] == market:
                return c
        return None

    def upsert_company(self, data: dict):
        items = self._load(self.companies_file)
        for i, item in enumerate(items):
            if item["ticker"] == data["ticker"] and item["market"] == data["market"]:
                items[i] = {**item, **data, "updated_at": now()}
                self._save(self.companies_file, items)
                return
        data["created_at"] = now()
        data["updated_at"] = now()
        items.append(data)
        self._save(self.companies_file, items)

    # ---- Thesis ----
    def list_theses(self, status: str = None, industry: str = None) -> list:
        items = self._load(self.theses_file)
        if status:
            items = [t for t in items if t.get("status") == status]
        if industry:
            items = [t for t in items if t.get("related_industry") == industry]
        return items

    def get_thesis(self, thesis_id: int) -> Optional[dict]:
        for t in self.list_theses():
            if t.get("id") == thesis_id:
                return t
        return None

    def create_thesis(self, data: dict) -> int:
        items = self._load(self.theses_file)
        new_id = max([t.get("id", 0) for t in items], default=0) + 1
        data["id"] = new_id
        data["status"] = data.get("status", "active")
        data["created_at"] = now()
        data["updated_at"] = now()
        data["evidence"] = data.get("evidence", [])
        data["counter_evidence"] = data.get("counter_evidence", [])
        items.append(data)
        self._save(self.theses_file, items)
        return new_id

    def add_evidence(self, thesis_id: int, evidence_type: str, content: str, source: str = ""):
        """evidence_type: supporting / opposing"""
        items = self._load(self.theses_file)
        for t in items:
            if t["id"] == thesis_id:
                entry = {"content": content, "source": source, "added_at": now()}
                if evidence_type == "supporting":
                    t.setdefault("evidence", []).append(entry)
                else:
                    t.setdefault("counter_evidence", []).append(entry)
                t["updated_at"] = now()
                break
        self._save(self.theses_file, items)

    def update_thesis_status(self, thesis_id: int, status: str):
        items = self._load(self.theses_file)
        for t in items:
            if t["id"] == thesis_id:
                t["status"] = status
                t["updated_at"] = now()
                break
        self._save(self.theses_file, items)

    # ---- 通用 ----
    @staticmethod
    def _load(path: Path) -> list:
        if not path.exists():
            return []
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _save(path: Path, data: list):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def save_macro_data(data: list):
    """保存宏观数据"""
    file_path = DATA_DIR / "macro" / f"{today()}.json"
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return str(file_path)


def load_macro_data(date: str = None) -> list:
    """加载宏观数据，默认今天"""
    date = date or today()
    file_path = DATA_DIR / "macro" / f"{date}.json"
    if not file_path.exists():
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_news_data(data: list):
    """保存新闻数据"""
    file_path = DATA_DIR / "news" / f"{today()}.json"
    existing = []
    if file_path.exists():
        with open(file_path, "r", encoding="utf-8") as f:
            existing = json.load(f)
    # 去重合并
    seen = {n.get("url", n.get("title", "")) for n in existing}
    for n in data:
        key = n.get("url", n.get("title", ""))
        if key not in seen:
            existing.append(n)
            seen.add(key)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
    return str(file_path)


def load_news_data(date: str = None) -> list:
    """加载新闻数据"""
    date = date or today()
    file_path = DATA_DIR / "news" / f"{date}.json"
    if not file_path.exists():
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_report(content: str, report_type: str = "daily") -> str:
    """保存报告到reports目录"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    filename = f"{report_type}_{timestamp}.md"
    file_path = REPORT_DIR / filename
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)
    return str(file_path)


def list_reports(limit: int = 10) -> list:
    """列出最近的报告"""
    reports = sorted(REPORT_DIR.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"file": r.name, "path": str(r), "size": r.stat().st_size} for r in reports[:limit]]


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today() -> str:
    return datetime.now().strftime("%Y%m%d")
