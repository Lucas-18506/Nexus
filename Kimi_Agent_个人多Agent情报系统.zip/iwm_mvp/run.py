#!/usr/bin/env python3
"""IWM MVP - 个人投资参谋系统入口

使用方式:
    python run.py init              # 初始化知识库
    python run.py daily             # 生成日报（需主Agent调度）
    python run.py analyze --topic "AI行业"    # 分析指定主题
    python run.py analyze --topic "NVDA"      # 分析指定公司
    python run.py analyze --topic "宏观"       # 宏观分析
    python run.py report --type opportunity   # 机会扫描
    python run.py report --type industry --name AI   # 行业深度
    python run.py kb --list industries        # 查看行业知识库
    python run.py kb --list companies         # 查看公司知识库
    python run.py kb --list thesis            # 查看投资逻辑
    python run.py config                      # 查看当前配置

说明:
    真正的数据采集和Agent分析由主Agent通过工具调用完成，
    本文件提供本地数据管理和报告渲染能力。
"""
import sys
import json
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from core.config import load_config, save_config, DEFAULT_CONFIG
from core.kb import KnowledgeBase, save_macro_data, load_macro_data, save_news_data, load_news_data, save_report, list_reports, today
from core.collector import MacroCollector, StockCollector, NewsCollector
from core.reporter import render_daily_report, render_opportunity_report, render_industry_report


def cmd_init():
    """初始化知识库和配置"""
    print("=" * 60)
    print("IWM MVP 初始化")
    print("=" * 60)

    # 保存默认配置
    save_config(DEFAULT_CONFIG)
    print(f"[OK] 配置已保存: config.json")

    # 初始化知识库
    kb = KnowledgeBase()

    # 导入行业数据
    industries = _get_preset_industries()
    for ind in industries:
        kb.upsert_industry(ind)
    print(f"[OK] 行业知识库已初始化: {len(industries)} 个行业")

    # 导入公司数据
    companies = _get_preset_companies()
    for comp in companies:
        kb.upsert_company(comp)
    print(f"[OK] 公司知识库已初始化: {len(companies)} 家公司")

    # 导入Thesis
    theses = _get_preset_theses()
    kb_data = json.loads((Path(__file__).parent / "kb_data" / "theses.json").read_text("utf-8")) if (Path(__file__).parent / "kb_data" / "theses.json").exists() else []
    if not kb_data:
        with open(Path(__file__).parent / "kb_data" / "theses.json", "w", encoding="utf-8") as f:
            json.dump(theses, f, ensure_ascii=False, indent=2)
    print(f"[OK] 投资逻辑库已初始化: {len(theses)} 条Thesis")

    print("\n初始化完成！")
    print("下一步: 运行 'python run.py daily' 生成日报")
    print("=" * 60)


def cmd_kb_list(what: str):
    """查看知识库"""
    kb = KnowledgeBase()
    if what == "industries":
        items = kb.list_industries()
        print(f"\n行业知识库 ({len(items)}个):")
        print("-" * 60)
        for item in items:
            print(f"  {item['name']:12s} | 生命周期: {item.get('lifecycle_stage', 'N/A'):10s} | {item.get('description', '')[:40]}...")
    elif what == "companies":
        items = kb.list_companies()
        print(f"\n公司知识库 ({len(items)}家):")
        print("-" * 60)
        for item in items:
            print(f"  {item['ticker']:10s} | {item['market']:3s} | {item['name']:12s} | {item.get('industry', 'N/A')}")
    elif what == "thesis":
        items = kb.list_theses()
        print(f"\n投资逻辑库 ({len(items)}条):")
        print("-" * 60)
        for item in items:
            status_icon = {"active": "●", "validated": "✓", "invalidated": "✗", "draft": "○"}.get(item.get('status', ''), "?")
            print(f"  {status_icon} [{item.get('id', '?')}] {item['title'][:50]} (置信度: {item.get('confidence', 'N/A')})")
    else:
        print(f"未知类型: {what}，可用: industries, companies, thesis")


def cmd_config():
    """查看配置"""
    config = load_config()
    print(json.dumps(config, ensure_ascii=False, indent=2))


def cmd_help():
    """帮助信息"""
    print(__doc__)


# ---- 预置数据 ----

def _get_preset_industries() -> list:
    return [
        {
            "name": "AI",
            "description": "人工智能行业，涵盖大模型、算力基础设施、AI应用等。当前处于高速增长期，资本开支持续加大。",
            "lifecycle_stage": "growth",
            "growth_rate": "high",
            "key_drivers": ["大模型技术迭代", "算力需求爆发", "企业AI化转型", "政策支持"],
            "supply_chain": "GPU/HBM → 光模块/DSP → 数据中心 → 电力 → 云服务 → AI应用",
            "bottleneck": "高端GPU供应（受出口管制影响），HBM产能，电力供应",
            "prosperity_indicators": ["GPU出货量", "数据中心资本开支", "AI应用DAU", "大模型API调用量"],
            "risk_factors": ["估值过高", "技术迭代不及预期", "监管收紧", "出口管制升级"],
            "opportunities": ["国产GPU替代", "AI应用商业化", "电力基础设施", "光模块升级"],
            "core_driver": "大模型能力持续提升，推动全产业资本开支"
        },
        {
            "name": "半导体",
            "description": "半导体行业涵盖芯片设计、制造、封测、设备、材料等全产业链。周期性与成长性并存。",
            "lifecycle_stage": "mature",
            "growth_rate": "moderate",
            "key_drivers": ["AI算力需求", "国产替代", "下游库存周期", "先进制程竞争"],
            "supply_chain": "EDA/IP → 设备/材料 → 晶圆制造 → 封测 → 模组/终端",
            "bottleneck": "先进制程（3nm以下），EUV光刻机，高端材料",
            "prosperity_indicators": ["晶圆厂产能利用率", "存储价格", "全球半导体销售额", "设备订单"],
            "risk_factors": ["周期下行", "地缘政治", "产能过剩", "技术封锁"],
            "opportunities": ["AI芯片", "先进封装", "国产设备", "汽车半导体"],
            "core_driver": "AI算力需求拉动+国产替代双轮驱动"
        },
        {
            "name": "新能源汽车",
            "description": "新能源汽车行业包括整车、电池、电机电控、充电设施等。中国市场领先，全球化加速。",
            "lifecycle_stage": "growth",
            "growth_rate": "high",
            "key_drivers": ["渗透率提升", "电池成本下降", "智能化升级", "政策补贴"],
            "supply_chain": "锂/镍/钴 → 正极/负极/电解液/隔膜 → 电芯/Pack → 整车 → 充电",
            "bottleneck": "锂资源供应，高端隔膜，充电桩布局",
            "prosperity_indicators": ["新能源车渗透率", "电池装机量", "碳酸锂价格", "充电桩数量"],
            "risk_factors": ["竞争加剧", "补贴退坡", "原材料价格波动", "贸易摩擦"],
            "opportunities": ["固态电池", "智能驾驶", "出海", "充电基础设施"],
            "core_driver": "电动化+智能化双轮驱动，渗透率持续提升"
        },
        {
            "name": "电力",
            "description": "电力行业在AI时代被重新定价。数据中心电力需求爆发，电网升级需求迫切。",
            "lifecycle_stage": "growth",
            "growth_rate": "high",
            "key_drivers": ["AI数据中心电力需求", "新能源装机", "电网升级", "电气化"],
            "supply_chain": "发电（火/风/光/核）→ 输电 → 变电 → 配电 → 用电",
            "bottleneck": "变压器（尤其是大型变压器），输电线路容量",
            "prosperity_indicators": ["全社会用电量", "数据中心PUE", "新能源装机量", "变压器订单"],
            "risk_factors": ["政策变化", "投资周期长", "电价管制", "燃料成本波动"],
            "opportunities": ["数据中心电力", "特高压", "储能", "虚拟电厂"],
            "core_driver": "AI算力爆发→数据中心→电力需求井喷"
        },
        {
            "name": "稳定币",
            "description": "稳定币作为加密货币与法币的桥梁，正在重塑跨境支付和数字金融基础设施。",
            "lifecycle_stage": "expansion",
            "growth_rate": "high",
            "key_drivers": ["跨境支付需求", "美元数字化", "DeFi发展", "监管框架明确"],
            "supply_chain": "法币储备 → 发行方 → 交易所/钱包 → 应用场景（支付/DeFi）",
            "bottleneck": "监管合规，储备透明度，银行渠道",
            "prosperity_indicators": ["稳定币总市值", "交易量", "监管进展", "机构采用率"],
            "risk_factors": ["监管打击", "储备风险", "竞争加剧", "技术漏洞"],
            "opportunities": ["跨境支付", "数字美元", "银行合作", "合规基础设施"],
            "core_driver": "数字美元化趋势+跨境支付需求"
        },
        {
            "name": "消费电子",
            "description": "消费电子行业包括智能手机、PC、可穿戴设备等。AI终端化是新一轮增长动力。",
            "lifecycle_stage": "mature",
            "growth_rate": "low",
            "key_drivers": ["AI手机/PC换机潮", "折叠屏", "AR/VR", "新兴市场"],
            "supply_chain": "芯片/传感器 → 模组/屏幕 → 组装 → 品牌 → 渠道",
            "bottleneck": "创新不足，换机周期延长",
            "prosperity_indicators": ["出货量", "ASP", "库存天数", "创新产品发布"],
            "risk_factors": ["需求疲软", "同质化竞争", "地缘政治", "成本上升"],
            "opportunities": ["AI终端", "折叠屏", "新兴市场", "汽车电子"],
            "core_driver": "AI功能驱动换机潮"
        },
        {
            "name": "机器人",
            "description": "机器人行业包括工业机器人、服务机器人、人形机器人等。AI赋能是核心变量。",
            "lifecycle_stage": "emerging",
            "growth_rate": "high",
            "key_drivers": ["AI大模型赋能", "劳动力短缺", "成本下降", "场景拓展"],
            "supply_chain": "减速器/电机/传感器 → 控制器/算法 → 整机 → 应用场景",
            "bottleneck": "精密减速器，灵巧手，AI推理能力",
            "prosperity_indicators": ["出货量", "单价", "渗透率", "技术突破"],
            "risk_factors": ["技术不成熟", "成本过高", "安全事故", "接受度低"],
            "opportunities": ["人形机器人", "工业自动化", "服务机器人", "核心零部件"],
            "core_driver": "AI赋能+劳动力成本上升"
        },
    ]


def _get_preset_companies() -> list:
    return [
        {"ticker": "NVDA", "market": "US", "name": "英伟达", "industry": "AI",
         "description": "全球AI芯片龙头，GPU+CUDA生态垄断",
         "business_model": "GPU销售+数据中心解决方案+软件授权",
         "moat": "CUDA生态+制程领先+全栈方案", "risk_points": ["估值高", "出口管制", "竞争加剧"]},
        {"ticker": "TSLA", "market": "US", "name": "特斯拉", "industry": "新能源汽车",
         "description": "电动车龙头+能源+机器人",
         "business_model": "汽车销售+软件(FSD)+能源+机器人",
         "moat": "品牌+成本领先+数据", "risk_points": ["竞争加剧", "马斯克风险", "交付不及预期"]},
        {"ticker": "AAPL", "market": "US", "name": "苹果", "industry": "消费电子",
         "description": "全球消费电子龙头，生态闭环",
         "business_model": "硬件(iPhone/Mac)+服务(AppStore/云服务)",
         "moat": "iOS生态+品牌+供应链", "risk_points": ["创新放缓", "中国市场", "监管"]},
        {"ticker": "MSFT", "market": "US", "name": "微软", "industry": "AI",
         "description": "云计算+AI双龙头",
         "business_model": "Azure+Office+AI Copilot+游戏",
         "moat": "企业客户粘性+OpenAI合作+云规模", "risk_points": ["AI投资回报", "云竞争", "反垄断"]},
        {"ticker": "AMD", "market": "US", "name": "AMD", "industry": "半导体",
         "description": "CPU/GPU双轮驱动",
         "business_model": "处理器(CPU/GPU)+数据中心芯片",
         "moat": "性价比+制程", "risk_points": ["竞争", "毛利率", "AI芯片进展"]},
        {"ticker": "COIN", "market": "US", "name": "Coinbase", "industry": "稳定币",
         "description": "美国最大加密货币交易所",
         "business_model": "交易手续费+托管+稳定币(USDC)",
         "moat": "合规+品牌+USDC", "risk_points": ["监管", "交易量波动", "竞争"]},
        {"ticker": "0700.HK", "market": "HK", "name": "腾讯", "industry": "AI",
         "description": "中国最大互联网公司",
         "business_model": "游戏+社交(微信)+广告+云+投资",
         "moat": "微信生态+游戏IP", "risk_points": ["监管", "游戏增长", "广告竞争"]},
        {"ticker": "9988.HK", "market": "HK", "name": "阿里巴巴", "industry": "AI",
         "description": "中国电商+云计算龙头",
         "business_model": "电商+阿里云+菜鸟+本地生活",
         "moat": "规模效应+阿里云", "risk_points": ["竞争", "增长放缓", "分拆"]},
        {"ticker": "1211.HK", "market": "HK", "name": "比亚迪", "industry": "新能源汽车",
         "description": "中国新能源汽车龙头",
         "business_model": "整车+电池+零部件",
         "moat": "垂直整合+成本领先", "risk_points": ["价格战", "出海", "品牌高端化"]},
        {"ticker": "1810.HK", "market": "HK", "name": "小米", "industry": "消费电子",
         "description": "手机+IoT+汽车",
         "business_model": "硬件(手机/IoT/汽车)+互联网服务",
         "moat": "性价比+生态", "risk_points": ["汽车投入", "利润率", "竞争"]},
    ]


def _get_preset_theses() -> list:
    return [
        {
            "id": 1, "title": "AI最大瓶颈是电力", "confidence": 0.75,
            "description": "AI算力需求爆发式增长，数据中心电力消耗呈指数级增长，电力供应将成为制约AI发展的核心瓶颈。",
            "status": "active", "related_industry": "AI", "related_tickers": ["NVDA", "TSLA"],
            "evidence": [
                {"content": "GPT-4训练耗电量相当于120个美国家庭一年用电", "source": "OpenAI报告", "added_at": "2024-01-15"},
                {"content": "全球数据中心电力消耗预计2030年翻倍", "source": "IEA", "added_at": "2024-03-01"}
            ],
            "counter_evidence": [
                {"content": "芯片能效比每年提升30%", "source": "行业分析", "added_at": "2024-02-01"},
                {"content": "核电复兴可能解决电力问题", "source": "Reuters", "added_at": "2024-04-01"}
            ]
        },
        {
            "id": 2, "title": "国产GPU替代加速", "confidence": 0.65,
            "description": "在美国出口管制背景下，中国AI芯片国产化进程加速，华为昇腾等国产GPU受益。",
            "status": "active", "related_industry": "半导体", "related_tickers": ["AMD"],
            "evidence": [
                {"content": "华为昇腾910B已批量出货", "source": "国内媒体报道", "added_at": "2024-05-01"}
            ],
            "counter_evidence": [
                {"content": "国产GPU性能仍落后NVIDIA 2-3代", "source": "行业分析", "added_at": "2024-04-15"}
            ]
        },
        {
            "id": 3, "title": "稳定币重塑跨境支付", "confidence": 0.60,
            "description": "稳定币正在重塑跨境支付格局，传统银行体系面临颠覆。USDC等合规稳定币将率先受益。",
            "status": "active", "related_industry": "稳定币", "related_tickers": ["COIN"],
            "evidence": [
                {"content": "Circle(USDC发行方)2024年处理$10T+交易量", "source": "Circle年报", "added_at": "2024-06-01"}
            ],
            "counter_evidence": [
                {"content": "各国央行数字货币(CBDC)可能挤压稳定币空间", "source": "BIS报告", "added_at": "2024-05-15"}
            ]
        },
    ]


if __name__ == "__main__":
    if len(sys.argv) < 2:
        cmd_help()
        sys.exit(0)

    command = sys.argv[1]

    if command == "init":
        cmd_init()
    elif command == "kb":
        if len(sys.argv) >= 4 and sys.argv[2] == "--list":
            cmd_kb_list(sys.argv[3])
        else:
            print("用法: python run.py kb --list [industries|companies|thesis]")
    elif command == "config":
        cmd_config()
    elif command == "daily":
        print("日报生成需要主Agent调度数据采集和Agent分析。")
        print("请通知主Agent执行: '生成今日日报'")
    elif command == "analyze":
        if len(sys.argv) >= 4 and sys.argv[2] == "--topic":
            topic = sys.argv[3]
            print(f"分析主题: {topic}")
            print("请通知主Agent执行Agent委员会分析...")
        else:
            print("用法: python run.py analyze --topic '主题'")
    elif command == "report":
        print("报告生成需要主Agent调度。")
    else:
        cmd_help()
