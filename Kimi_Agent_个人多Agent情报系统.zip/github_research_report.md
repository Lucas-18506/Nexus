# GitHub高星金融仪表盘项目深度分析报告

## 调研范围

共分析 **12个** GitHub上的金融/交易仪表盘项目，筛选出 **5个最具参考价值** 的项目进行深入代码级分析。

---

## 一、最值得借鉴的项目

### 1. galafis/trading-dashboard ⭐ 最高参考价值

| 维度 | 详情 |
|------|------|
| **技术栈** | React 19 + Recharts + Tailwind CSS + Framer Motion + Vite + Zustand |
| **与我们匹配度** | ★★★★★ 完全一致（同技术栈） |
| **关键文件** | `services/technicalIndicators.js`, `services/marketData.js`, `stores/*.js` |

#### 可直接复用的核心代码

**A. 技术指标引擎 (`technicalIndicators.js`)**

已实现完整的技术指标计算库，全部纯函数，可直接复制使用：

| 指标 | 函数名 | 说明 |
|------|--------|------|
| SMA | `sma(data, period)` | 简单移动平均线 |
| EMA | `ema(data, period)` | 指数移动平均线（含seed逻辑） |
| RSI | `rsi(closes, period=14)` | 相对强弱指数（Wilder平滑法） |
| MACD | `macd(closes, fast=12, slow=26, signal=9)` | 完整MACD三线（DIF/DEA/柱状图） |
| 布林带 | `bollingerBands(closes, period=20, stdDev=2)` | 上/中/下轨 |
| VWAP | `vwap(candles)` | 成交量加权均价 |
| **一键计算** | `calculateAllIndicators(candles)` | **同时计算所有指标并合并到K线数据** |

`calculateAllIndicators()` 的输出格式完美匹配Recharts：
```js
{
  timestamp, open, high, low, close, volume,  // 原始OHLCV
  sma20, sma50, ema12, ema26,                 // 均线
  rsi,                                         // RSI
  macd, macdSignal, macdHistogram,             // MACD三线
  bbUpper, bbMiddle, bbLower,                  // 布林带
  vwap                                         // VWAP
}
```

**B. 数据模拟引擎 (`marketData.js`)**

使用 **几何布朗运动 + Ornstein-Uhlenbeck 均值回归** 生成真实感OHLCV数据：

```js
// 每个标的有独立的参数配置
const SYMBOLS = {
  NVDA: { basePrice: 880.50, volatility: 0.030, meanReversion: 0.012 },
  TSLA: { basePrice: 245.60, volatility: 0.035, meanReversion: 0.010 },
  // ...
}
```

支持多时间周期：`1m`, `5m`, `15m`, `1h`, `4h`, `1d`

**C. 状态管理设计 (`stores/*.js`)**

使用 Zustand 分层管理：
- `marketStore.js` — 市场行情数据、实时报价、观察列表
- `portfolioStore.js` — 持仓、P&L、收益计算
- `orderStore.js` — 订单状态管理

#### 可借鉴到IWM的功能

1. **技术指标引擎** — 直接复用 `technicalIndicators.js` 替换当前手写指标
2. **数据模拟层** — 借鉴 `marketData.js` 为演示数据增加真实感
3. **Zustand状态管理** — 替代当前各页面独立的useState管理
4. **calculateAllIndicators** — 一键生成所有技术指标数据，简化图表组件

---

### 2. mphinance/tradier-desktop ⭐⭐⭐⭐⭐ K线图标杆

| 维度 | 详情 |
|------|------|
| **技术栈** | Tauri v2 + React 19 + TypeScript + Lightweight Charts v5 + Zustand |
| **与我们匹配度** | ★★★★☆ 技术栈相近，图表库不同 |
| **核心价值** | **TradingView官方图表库的专业实现** |

#### 关键实现：`PriceChart.tsx` — Lightweight Charts v5

```tsx
import { createChart, CandlestickSeries, HistogramSeries } from 'lightweight-charts';

// 专业K线图配置
const chart = createChart(container, {
  layout: {
    background: { color: '#0c1120' },
    textColor: '#9ca3af',
    fontSize: 12,
  },
  grid: {
    vertLines: { color: 'rgba(30, 41, 59, 0.5)' },
    horzLines: { color: 'rgba(30, 41, 59, 0.5)' },
  },
  crosshair: {
    vertLine: { color: 'rgba(0, 212, 255, 0.3)' },
    horzLine: { color: 'rgba(0, 212, 255, 0.3)' },
  },
  // ...
});

const candle = chart.addSeries(CandlestickSeries, {
  upColor: '#00ff88',
  downColor: '#ff3366',
  borderUpColor: '#00ff88',
  borderDownColor: '#ff3366',
  wickUpColor: '#00cc6a',
  wickDownColor: '#cc2952',
});
```

#### 组件架构（可完整借鉴）

| 组件 | 功能 | IWM对应位置 |
|------|------|-------------|
| `PriceChart.tsx` | 专业K线图（Lightweight Charts） | Company页面的K线图 |
| `QuoteTicker.tsx` | 实时报价观察列表+Live状态指示 | Dashboard的宏观KPI区 |
| `OptionsChain.tsx` | 期权链（到期日+行权价+Greeks） | 可新增到Company页面 |
| `OrdersTable.tsx` | 订单管理（开仓/平仓/状态） | 可新增交易功能 |
| `PositionsTable.tsx` | 持仓表（P&L/成本/市值） | Portfolio页面参考 |
| `SymbolSearch.tsx` | 标的搜索（自动补全） | Company页面搜索框 |
| `StatusBar.tsx` | 底部状态栏（市场时钟/连接状态） | 全局底部状态栏 |
| `AppShell.tsx` | 应用外壳（侧边栏+顶部栏+主内容区） | Layout组件参考 |

#### 可借鉴到IWM的功能

1. **Lightweight Charts替换Recharts K线图** — 实现真正的专业K线图
2. ** neon暗色主题** — `#0c1120`背景+`#00ff88`/`#ff3366`涨跌色的高对比设计
3. **实时Live指示器** — QuoteTicker的流状态显示（● Live / ◌ Connecting / ✕ Error / ○ Offline）
4. **市场时钟** — 显示市场状态（开盘/收盘/盘前/盘后）
5. **底部状态栏** — 全局显示连接状态、数据延迟、版本信息

---

### 3. manish434k/stock-portfolio-dashboard ⭐⭐⭐⭐

| 维度 | 详情 |
|------|------|
| **技术栈** | React 19 + TypeScript + Vite + MUI v7 + Chart.js |
| **Stars** | 较新 |
| **核心价值** | 投资组合仪表盘的专业UI设计 |

#### 可借鉴功能

1. **主题切换器** — 明暗模式一键切换（MUI ThemeProvider实现）
2. **MetricsCards组件** — 投资组合指标卡片的布局设计
3. **PerformanceChart** — Chart.js的多线性能对比图
4. **AllocationPieChart** — 资产配置环形图

---

### 4. nmfretz/investment-dashboard ⭐⭐⭐

| 维度 | 详情 |
|------|------|
| **技术栈** | React + Chart.js + Bulma CSS |
| **核心价值** | 公司财务图表（HyperCharts API集成） |

#### 可借鉴功能

1. **财务数据图表** — 营收分段、现金流等详细财务图表
2. **资产搜索功能** — 股票/加密货币搜索
3. **货币转换** — money.js多币种支持

---

### 5. Tremor (3.2k stars) ⭐⭐⭐⭐ 组件库

| 维度 | 详情 |
|------|------|
| **技术栈** | Radix UI + Tailwind CSS |
| **核心价值** | 专为仪表盘设计的数据可视化组件库 |

#### 可直接使用的组件

- `AreaChart`, `BarChart`, `LineChart`, `DonutChart` — 预 styled 图表
- `Card`, `Tracker`, `ProgressBar` — 仪表盘专用UI
- `Metric` — 指标展示组件
- `Flex`, `Grid` — 响应式布局

---

## 二、K线图表方案对比

### 当前方案 vs 可选方案

| 方案 | 库 | 优点 | 缺点 | 推荐度 |
|------|-----|------|------|--------|
| **当前** | Recharts ComposedChart | 已在项目中，无需新增依赖 | K线效果粗糙，无十字线，交互弱 | ★★☆☆☆ |
| **方案A** | Lightweight Charts v5 | TradingView出品，专业K线图，性能极好，免费 | 需新增依赖，学习成本 | ★★★★★ |
| **方案B** | Recharts + 自定义 | 无需新依赖，用现有技术栈 | 实现复杂度高，效果上限低 | ★★★☆☆ |
| **方案C** | tradingview-react | 完整的TradingView图表嵌入 | 非免费，有品牌水印 | ★★☆☆☆ |

### 推荐：Lightweight Charts v5

来自 `tradier-desktop` 的完整实现方案：

```bash
npm install lightweight-charts
```

```tsx
// Company页面的K线图组件
import { createChart, CandlestickSeries, HistogramSeries, LineSeries } from 'lightweight-charts';

// 1. 创建图表
const chart = createChart(container, {
  layout: { background: { color: '#0c1120' }, textColor: '#9ca3af' },
  grid: { vertLines: { color: 'rgba(30,41,59,0.5)' }, horzLines: { color: 'rgba(30,41,59,0.5)' } },
  crosshair: { mode: 1 }, // Magnet模式
  timeScale: { timeVisible: true },
});

// 2. 添加K线系列
const candleSeries = chart.addSeries(CandlestickSeries, {
  upColor: '#00ff88', downColor: '#ff3366',
  borderUpColor: '#00ff88', borderDownColor: '#ff3366',
});
candleSeries.setData(ohlcvData);

// 3. 添加成交量
const volumeSeries = chart.addSeries(HistogramSeries, {
  priceFormat: { type: 'volume' }, priceScaleId: '',
});
volumeSeries.setData(volumeData);
volumeSeries.priceScale().applyOptions({ scaleMargins: { top: 0.85, bottom: 0 } });

// 4. 添加MA线
const ma20Series = chart.addSeries(LineSeries, { color: '#2962FF', lineWidth: 2 });
ma20Series.setData(ma20Data);
```

#### Lightweight Charts v5 核心优势

1. **真实K线** — 每根K线有开盘/最高/最低/收盘四个价格+实体+影线
2. **十字线（Crosshair）** — 鼠标悬停显示精确价格和时间的十字光标
3. **时间缩放** — 鼠标滚轮缩放，拖拽平移
4. **自适应缩放** — 自动调整Y轴范围
5. **性能极好** — Canvas渲染，10万+K线流畅
6. **体积小巧** — ~70KB gzipped

---

## 三、具体功能借鉴清单

### 🔴 P0 — 立即实施

| 功能 | 来源项目 | 实施位置 | 工作量 |
|------|---------|---------|--------|
| **技术指标引擎** | galafis/technicalIndicators.js | utils/technicalIndicators.ts | 2h |
| **calculateAllIndicators** | galafis | Company页面数据预处理 | 1h |
| **Lightweight Charts K线图** | tradier-desktop/PriceChart.tsx | Company页面K线图替换 | 4h |

### 🟡 P1 — 高优先级

| 功能 | 来源项目 | 实施位置 | 工作量 |
|------|---------|---------|--------|
| **Lightweight Charts主题配色** | tradier-desktop | 全局图表配色统一 | 2h |
| **QuoteTicker实时报价** | tradier-desktop/QuoteTicker.tsx | Dashboard顶部报价条 | 3h |
| **市场时钟** | tradier-desktop/StatusBar.tsx | 全局底部状态栏 | 2h |
| **Zustand状态管理重构** | galafis/stores | 全局状态层 | 4h |
| **数据模拟引擎** | galafis/marketData.js | 演示数据生成 | 2h |

### 🟢 P2 — 中优先级

| 功能 | 来源项目 | 实施位置 | 工作量 |
|------|---------|---------|--------|
| **主题切换（明暗模式）** | manish434k | 全局设置 | 3h |
| **SymbolSearch标的搜索** | tradier-desktop/SymbolSearch.tsx | Company页面 | 2h |
| **底部状态栏** | tradier-desktop/StatusBar.tsx | Layout底部 | 2h |
| **Tremor组件库集成** | tremor.so | 全局UI组件 | 3h |
| **VWAP指标** | galafis/technicalIndicators.js | 技术指标面板 | 1h |
| **期权链展示** | tradier-desktop/OptionsChain.tsx | Company页面新增 | 4h |

---

## 四、设计细节借鉴

### 1. 颜色方案（来自 tradier-desktop）

```css
/* Neon 暗色主题 */
--bg-primary: #0c1120;
--bg-card: #111827;
--border-subtle: rgba(30, 41, 59, 0.5);
--text-primary: #f1f5f9;
--text-muted: #9ca3af;

/* 涨跌色 */
--up: #00ff88;       /* 霓虹绿 */
--up-wick: #00cc6a;
--down: #ff3366;     /* 霓虹红 */
--down-wick: #cc2952;

/* 指标线色 */
--ma5: #2962FF;
--ma10: #FF6D00;
--ma20: #00C853;
--ma60: #D500F9;

/* 十字线 */
--crosshair: rgba(0, 212, 255, 0.3);
```

### 2. 组件布局（来自 galafis + tradier-desktop）

```
┌──────────────────────────────────────────────────────┐
│  Sidebar  │  TopBar (报价/搜索/状态)                  │
│  (导航)   ├───────────────────────────────────────────┤
│           │  Metric Cards Row (4-6个KPI卡片)          │
│           ├───────────────────────────────────────────┤
│           │  Main Chart Area                          │
│           │  ┌─────────────────────────────────────┐  │
│           │  │  K线图 (Lightweight Charts)          │  │
│           │  │  + MA线 + 成交量 + 十字线            │  │
│           │  └─────────────────────────────────────┘  │
│           ├───────────────────────────────────────────┤
│           │  Indicator Panel (MACD/RSI/布林带)       │
│           ├───────────────────────────────────────────┤
│           │  Data Table (信号/持仓/订单)              │
│           ├───────────────────────────────────────────┤
│           │  [StatusBar: 市场时钟 | 连接状态 | 版本]  │
└───────────┴───────────────────────────────────────────┘
```

### 3. 交互细节

- **十字线 Magnet 模式** — 十字线自动吸附到最近的K线
- **实时Live指示器** — 绿色脉冲点表示数据实时更新中
- **市场状态徽章** — 开盘(绿)/收盘(灰)/盘前(黄)/盘后(橙)
- **数据加载骨架屏** — Framer Motion的shimmer效果
- **K线Hover Tooltip** — 显示OHLCV完整数据

---

## 五、实施路线图

```
第1阶段（1-2天）
  ├── 安装 lightweight-charts
  ├── 创建 utils/technicalIndicators.ts（从galafis复用）
  ├── 重写 Company页面K线图为Lightweight Charts
  └── 统一图表配色为neon暗色主题

第2阶段（2-3天）
  ├── 添加QuoteTicker实时报价条到Dashboard
  ├── 添加市场时钟到StatusBar
  ├── Zustand状态管理重构
  └── 数据模拟引擎增强

第3阶段（3-5天）
  ├── SymbolSearch标的搜索
  ├── 主题切换（明暗模式）
  ├── 期权链展示（Company页面）
  └── Tremor组件库集成
```
