import { useState, useEffect, useRef, useCallback } from 'react';

export interface NetworkStatus {
  /** 是否在线 */
  online: boolean;
  /** 状态变更时间 */
  since: Date;
  /** 往返延迟(ms) */
  rtt: number | null;
  /** 网络类型 (4g/3g/2g/slow-2g) */
  effectiveType: string;
}

const PING_URL = '/favicon.ico';
const PING_INTERVAL = 30000; // 30s
const PING_TIMEOUT = 5000;   // 5s

/**
 * 网络状态检测 Hook
 *
 * 监听 navigator.onLine + online/offline 事件，并定期 ping 测试延迟。
 * 返回完整网络状态对象。
 */
export function useNetworkStatus(): NetworkStatus {
  const [online, setOnline] = useState<boolean>(navigator.onLine);
  const [since, setSince] = useState<Date>(new Date());
  const [rtt, setRtt] = useState<number | null>(null);
  const [effectiveType, setEffectiveType] = useState<string>('');

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 从 Network Information API 获取网络类型
  const updateConnectionInfo = useCallback(() => {
    const conn = (navigator as unknown as Record<string, unknown>).connection as
      | { effectiveType?: string; downlink?: number; rtt?: number }
      | undefined;
    if (conn?.effectiveType) {
      setEffectiveType(conn.effectiveType);
    }
  }, []);

  // Ping 测试：fetch 一个极小资源来测量 RTT
  const ping = useCallback(async () => {
    const start = performance.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), PING_TIMEOUT);
      await fetch(PING_URL, {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-store',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      const latency = Math.round(performance.now() - start);
      setRtt(latency);
      // 如果 ping 成功但当前标记为离线，恢复在线状态
      if (!online) {
        setOnline(true);
        setSince(new Date());
      }
    } catch {
      // ping 失败 — 可能是离线，也可能是服务器问题
      setRtt(null);
      // 如果 navigator.onLine 也报告离线，则同步状态
      if (!navigator.onLine) {
        setOnline(false);
        setSince(new Date());
      }
    }
  }, [online]);

  useEffect(() => {
    // 初始网络类型
    updateConnectionInfo();

    // 在线/离线事件监听
    const handleOnline = () => {
      setOnline(true);
      setSince(new Date());
      setRtt(null);
      // 立即执行一次 ping 测量延迟
      void ping();
    };

    const handleOffline = () => {
      setOnline(false);
      setSince(new Date());
      setRtt(null);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Network Information API 变更监听（Chrome 等浏览器支持）
    const conn = (navigator as unknown as Record<string, unknown>).connection as
      | { addEventListener?: (type: string, listener: () => void) => void; removeEventListener?: (type: string, listener: () => void) => void }
      | undefined;
    const handleConnectionChange = () => updateConnectionInfo();
    if (conn?.addEventListener) {
      conn.addEventListener('change', handleConnectionChange);
    }

    // 启动定期 ping
    // 首次延迟 2s 避免页面加载初期干扰
    const initialPingTimeout = setTimeout(() => {
      void ping();
    }, 2000);

    intervalRef.current = setInterval(() => {
      void ping();
    }, PING_INTERVAL);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (conn?.removeEventListener) {
        conn.removeEventListener('change', handleConnectionChange);
      }
      clearTimeout(initialPingTimeout);
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [ping, updateConnectionInfo]);

  return {
    online,
    since,
    rtt,
    effectiveType: effectiveType || 'unknown',
  };
}

export default useNetworkStatus;
