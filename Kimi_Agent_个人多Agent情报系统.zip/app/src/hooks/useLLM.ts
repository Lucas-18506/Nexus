import { useState, useCallback, useRef } from 'react';
import { useLLMConfig } from '@/contexts/LLMContext';
import type { LLMProvider } from '@/contexts/LLMContext';

// ─── 类型定义 ───────────────────────────────────────────

interface TokenUsage {
  prompt: number;
  completion: number;
  total: number;
}

export interface UseLLMOptions {
  prompt: string;
  model?: 'deep-think' | 'quick-think';
  onSuccess?: (result: string) => void;
  onError?: (error: string) => void;
}

export interface UseLLMResult {
  result: string | null;
  loading: boolean;
  error: string | null;
  tokenUsage: TokenUsage;
  execute: () => void;
}

// ─── OpenAI API 响应类型 ───────────────────────────────

interface OpenAIChoice {
  index: number;
  message: {
    role: string;
    content: string;
  };
  finish_reason: string;
}

interface OpenAIUsage {
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
}

interface OpenAIResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: OpenAIChoice[];
  usage: OpenAIUsage;
}

// ─── 模拟数据分析 ──────────────────────────────────────

interface SimulatedAnalysis {
  content: string;
  tokenUsage: TokenUsage;
}

const TOKEN_STORAGE_KEY = 'iwm-llm-total-tokens';

function getTotalTokensFromStorage(): number {
  try {
    const stored = localStorage.getItem(TOKEN_STORAGE_KEY);
    return stored ? parseInt(stored, 10) : 0;
  } catch {
    return 0;
  }
}

function addTokensToStorage(count: number): void {
  try {
    const current = getTotalTokensFromStorage();
    localStorage.setItem(TOKEN_STORAGE_KEY, String(current + count));
  } catch {
    // 忽略存储错误
  }
}

/**
 * 根据 prompt 内容生成模拟分析数据
 */
function generateMockAnalysis(prompt: string): SimulatedAnalysis {
  const lowerPrompt = prompt.toLowerCase();

  // NVIDIA / 英伟达分析
  if (lowerPrompt.includes('nvidia') || lowerPrompt.includes('英伟达') || lowerPrompt.includes('nvda')) {
    return {
      content: `## 投资摘要
英伟达(NVDA)在AI算力需求持续爆发的背景下，数据中心业务保持强劲增长。Blackwell架构升级周期即将到来，预计将为2025年下半年带来新增量。维持**强力买入**评级。

## 关键要点
• 数据中心收入同比增长400%+，Blackwell芯片订单超预期
• 毛利率维持78%高位，定价权稳固
• 竞争对手AMD MI300虽具威胁，但软件生态差距短期难以弥补
• 中国市场受限影响约15%营收，但可通过中东/东南亚渠道部分弥补

## 风险评估
• **高风险**：估值偏高(fwd PE 42x)，任何增长放缓信号都可能引发大幅回调
• **中风险**：AI投资周期性，超大规模计算厂商 capex/收入比已达31%的历史高位

## 操作建议
**买入**。建议在$130-135区间分批建仓，止损设在$115（-15%），目标价位$165（+22%）。`,
      tokenUsage: { prompt: 342, completion: 1286, total: 1628 },
    };
  }

  // 科技 / AI 行业分析
  if (lowerPrompt.includes('科技') || lowerPrompt.includes('ai') || lowerPrompt.includes('人工智能') || lowerPrompt.includes('半导体')) {
    return {
      content: `## 投资摘要
科技行业处于AI驱动的超级周期中，云厂商资本开支持续攀升。建议重点关注算力基础设施（GPU/ASIC/光模块）和应用层（SaaS/广告）的投资机会，整体行业评级**增持**。

## 关键要点
• 全球云厂商2025年资本开支预计同比增长35%，达到2500亿美元
• AI服务器出货量预计同比增长80%，GPU仍是主流算力选择
• 推理需求正在崛起，边缘AI和端侧算力成为新增长点
• 软件SaaS公司加速AI功能集成，ARPU值有望提升15-20%

## 风险评估
• **高风险**：AI投资存在周期性，若AI应用落地不及预期，可能导致资本开支快速收缩
• **中风险**：地缘政治因素持续，芯片出口管制可能影响全球供应链
• **低风险**：利率环境改善，科技股估值压力有所缓解

## 操作建议
**增持**。重点关注英伟达(NVDA)、微软(MSFT)、谷歌(GOOGL)等AI产业链核心标的，建议通过ETF(QQQ/XLK)分散单一公司风险。`,
      tokenUsage: { prompt: 315, completion: 1184, total: 1499 },
    };
  }

  // 金融 / 银行分析
  if (lowerPrompt.includes('银行') || lowerPrompt.includes('金融') || lowerPrompt.includes('finance') || lowerPrompt.includes('bank')) {
    return {
      content: `## 投资摘要
银行业受益于净息差改善和信贷需求回暖，大型银行资产质量保持稳定。但需关注中小银行的商业地产风险暴露。行业整体评级**持有**。

## 关键要点
• 大型银行净息差(NIM)环比改善3-5bp，利息收入增速回升
• 投行业务随IPO市场回暖，Fee收入有望同比增长15%
• 商业地产贷款不良率上升至2.1%，需持续跟踪
• 数字化转型加速，AI风控降低运营成本约8%

## 风险评估
• **高风险**：商业地产价格下跌可能引发中小银行信用风险
• **中风险**：利率快速下行可能压缩净息差空间
• **低风险**：大型银行资本充足率充足，抗风险能力强

## 操作建议
**持有**。优选大型银行(JPM/BAC)和区域性优质银行，规避商业地产敞口较大的中小银行。`,
      tokenUsage: { prompt: 328, completion: 1152, total: 1480 },
    };
  }

  // 新能源 / 电动车分析
  if (lowerPrompt.includes('新能源') || lowerPrompt.includes('电动车') || lowerPrompt.includes('tesla') || lowerPrompt.includes('tsla') || lowerPrompt.includes('ev')) {
    return {
      content: `## 投资摘要
新能源汽车行业增速放缓但渗透率仍有提升空间，头部企业竞争优势稳固。电池成本持续下降推动盈利改善，关注自动驾驶技术突破带来的估值重构机会。评级**持有**。

## 关键要点
• 全球电动车渗透率2025年预计达到25%，增速从50%降至30%
• 锂电池成本同比下降15%，车企毛利率普遍改善2-3个百分点
• 自动驾驶L3级政策落地，头部车企软件收入开始放量
• 充电基础设施建设加速，缓解里程焦虑

## 风险评估
• **中风险**：行业竞争加剧，价格战可能侵蚀利润空间
• **中风险**：补贴政策退坡影响部分市场需求
• **低风险**：长期碳中和趋势不变，行业前景确定性高

## 操作建议
**持有**。特斯拉(TSLA)在自动驾驶领域保持领先，建议在$200以下分批布局；同时关注比亚迪(1211.HK)和宁德时代(300750.SZ)的投资机会。`,
      tokenUsage: { prompt: 336, completion: 1198, total: 1534 },
    };
  }

  // 默认通用分析
  return {
    content: `## 投资摘要
当前标的基本面稳健，行业地位稳固，但需关注宏观经济环境和估值水平。建议结合个人风险偏好，采取分批建仓策略。整体评级**持有**。

## 关键要点
• 公司基本面整体健康，营收和利润保持稳定增长
• 行业竞争格局未发生根本性变化
• 估值处于历史中位数水平，不具备明显安全边际
• 管理层执行力较强，战略方向清晰

## 风险评估
• **中风险**：宏观经济下行可能影响需求端
• **中风险**：行业政策变化带来不确定性
• **低风险**：公司财务状况健康，现金流充裕

## 操作建议
**持有**。建议关注$XX-$XX区间的支撑力度，可逢低分批建仓。中长期投资者可保持耐心，等待业绩催化剂。`,
    tokenUsage: { prompt: 298, completion: 856, total: 1154 },
  };
}

// ─── Hook ──────────────────────────────────────────────

export function useLLM(options: UseLLMOptions): UseLLMResult {
  const { prompt, model = 'quick-think', onSuccess, onError } = options;
  const { getActiveProvider } = useLLMConfig();

  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [tokenUsage, setTokenUsage] = useState<TokenUsage>({
    prompt: 0,
    completion: 0,
    total: 0,
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  const execute = useCallback(async () => {
    // 取消之前的请求
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const provider: LLMProvider | undefined = getActiveProvider();

      // ── 模拟模式：没有 API Key 时使用 fallback ──
      if (!provider || !provider.apiKey || provider.apiKey.trim() === '') {
        // 模拟网络延迟
        await new Promise(resolve => setTimeout(resolve, 1200));

        if (controller.signal.aborted) {
          setLoading(false);
          return;
        }

        const mock = generateMockAnalysis(prompt);
        setResult(mock.content);
        setTokenUsage(mock.tokenUsage);
        addTokensToStorage(mock.tokenUsage.total);
        onSuccess?.(mock.content);
        setLoading(false);
        return;
      }

      // ── 真实 API 调用 ──
      const apiModel = model === 'deep-think'
        ? (provider.models[0] || 'deepseek-reasoner')
        : (provider.models[1] || 'deepseek-chat');

      const response = await fetch(`${provider.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: apiModel,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
          max_tokens: 2000,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const status = response.status;
        if (status === 401) {
          throw new Error('API Key 认证失败，请检查密钥配置');
        } else if (status === 429) {
          throw new Error('请求过于频繁，请稍后重试（Rate Limit）');
        } else if (status >= 500) {
          throw new Error('LLM 服务暂时不可用，请稍后重试');
        } else {
          throw new Error(`请求失败: ${response.status} ${response.statusText}`);
        }
      }

      const data: OpenAIResponse = await response.json();

      const content = data.choices?.[0]?.message?.content || '';
      const usage: TokenUsage = {
        prompt: data.usage?.prompt_tokens || 0,
        completion: data.usage?.completion_tokens || 0,
        total: data.usage?.total_tokens || 0,
      };

      setResult(content);
      setTokenUsage(usage);
      addTokensToStorage(usage.total);
      onSuccess?.(content);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        // 用户主动取消，不设置错误
        return;
      }

      const errorMessage = err instanceof Error ? err.message : '未知错误';
      setError(errorMessage);
      onError?.(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [prompt, model, getActiveProvider, onSuccess, onError]);

  // 组件卸载时取消请求
  const executeRef = useRef(execute);
  executeRef.current = execute;

  useState(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  });

  return {
    result,
    loading,
    error,
    tokenUsage,
    execute,
  };
}

export default useLLM;
