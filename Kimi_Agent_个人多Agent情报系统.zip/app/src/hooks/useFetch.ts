import { useState, useEffect, useRef, useCallback } from 'react';

interface UseFetchResult<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

const DEFAULT_TIMEOUT = 10000; // 10 seconds
const MAX_RETRIES = 1;

export function useFetch<T>(url: string): UseFetchResult<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const retryCountRef = useRef<number>(0);
  const abortControllerRef = useRef<AbortController | null>(null);

  const fetchData = useCallback(
    async (isRetry = false) => {
      // Cancel previous request
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      const controller = new AbortController();
      abortControllerRef.current = controller;

      if (!isRetry) {
        setLoading(true);
        setError(null);
        retryCountRef.current = 0;
      }

      const timeoutId = setTimeout(() => {
        controller.abort();
      }, DEFAULT_TIMEOUT);

      try {
        const response = await fetch(url, {
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
          },
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`请求失败: ${response.status} ${response.statusText}`);
        }

        const result = await response.json();
        setData(result);
        setError(null);
        retryCountRef.current = 0;
      } catch (err) {
        clearTimeout(timeoutId);

        const isAborted = err instanceof DOMException && err.name === 'AbortError';

        if (isAborted) {
          // Timeout or manual abort
          if (retryCountRef.current < MAX_RETRIES) {
            retryCountRef.current += 1;
            await fetchData(true);
            return;
          }
          setError('请求超时，请稍后重试');
        } else if (err instanceof Error) {
          if (retryCountRef.current < MAX_RETRIES) {
            retryCountRef.current += 1;
            await fetchData(true);
            return;
          }
          setError(err.message || '加载数据时出错');
        } else {
          if (retryCountRef.current < MAX_RETRIES) {
            retryCountRef.current += 1;
            await fetchData(true);
            return;
          }
          setError('未知错误');
        }
      } finally {
        setLoading(false);
      }
    },
    [url]
  );

  useEffect(() => {
    fetchData();

    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [fetchData]);

  const refetch = useCallback(() => {
    retryCountRef.current = 0;
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch };
}

export default useFetch;
