import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  AreaChart,
  Area,
  Cell,
} from 'recharts'
import {
  Sunset,
  FileText,
  ArrowUp,
  ArrowDown,
  Minus,
  Bell,
  RefreshCw,
  ClipboardCheck,
  User,
  Globe,
  Wallet,
  Activity,
  Target,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  CalendarDays,
  ListChecks,
  BarChart3,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─────────────────────────── types ─────────────────────────── */

interface IndexClose {
  name: string
  value: number
  change: number
  changePercent: number
  dayLow: number
  dayHigh: number
  volume: string
}

interface TimingSignal {
  rank: number
  asset: string
  signal: string
  entry: string
  target: string
  stop: string
  rr: string
  change: string
  changeNote: string
  trend: number[]
}

interface NewsEvent {
  time: string
  headline: string
  description: string
  impact: string
  source: string
}

interface ScorecardWinner {
  asset: string
  return: number
}

interface FlowsPositioning {
  etfFlows: { name: string; flow: number; direction: string }[]
  institutionalPositioning: { netLong: number; label: string }
  retailSentiment: { score: number; label: string }
  futuresPositioning: string
}

interface EveningReportData {
  reportDate: string
  reportType: string
  generatedAt: string
  marketRecap: {
    text: string
    keyStats: { name: string; value: number; change: number; changePercent: number }[]
  }
  aShareClose: {
    shanghai: IndexClose
    shenzhen: IndexClose
    beijing: IndexClose
  }
  hShareClose: {
    hangSeng: IndexClose
    ahPremium: {
      name: string
      value: number
      change: number
      changePercent: number
      history: number[]
      note: string
    }
    crossBorderFlows: {
      northbound: { amount: number; direction: string }
      southbound: { amount: number; direction: string }
      netTrend: string
    }
  }
  usMarketWrap: {
    indices: {
      name: string
      close: number
      change: number
      changePercent: number
      futures: number
      dayLow: number
      dayHigh: number
    }[]
    sectorPerformance: { name: string; change: number }[]
    notableMovers: string[]
  }
  flowsPositioning: FlowsPositioning
  newsEvents: NewsEvent[]
  updatedTimingSignals: {
    changes: { new: number; upgraded: number; downgraded: number; unchanged: number }
    signals: TimingSignal[]
  }
  dayScorecard: {
    directionalAccuracy: { correct: boolean; label: string }
    keyLevelsHit: { hit: number; total: number }
    signalPerformance: { avgReturn: number; label: string }
    volatilityForecast: { correct: boolean; label: string }
    newsImpact: { predicted: number; total: number }
    overallGrade: string
    gradeColor: string
    winners: ScorecardWinner[]
    losers: ScorecardWinner[]
  }
  cioClosingNote: {
    text: string
    watchList: string[]
    tomorrowPreview: string
  }
}

/* ─────────────────────────── easing ─────────────────────────── */

const easeOut = [0.4, 0, 0.2, 1] as [number, number, number, number]

/* ─────────────────────────── colors ─────────────────────────── */

const C = {
  bgCard: '#14171F',
  bgElevated: '#1C1F2B',
  borderSubtle: 'rgba(255,255,255,0.06)',
  bullish: '#10B981',
  bearish: '#EF4444',
  neutral: '#F59E0B',
  info: '#3B82F6',
  gold: '#D4AF37',
  textPrimary: '#F0F2F8',
  textSecondary: '#8A93A8',
  textTertiary: '#5C6375',
}

/* ─────────────────────────── helpers ─────────────────────────── */

const signalColor = (s: string) =>
  s === 'bullish' ? C.bullish : s === 'bearish' ? C.bearish : s === 'neutral' ? C.neutral : C.info

const signalBg = (s: string) =>
  s === 'bullish'
    ? 'rgba(16,185,129,0.12)'
    : s === 'bearish'
      ? 'rgba(239,68,68,0.12)'
      : s === 'neutral'
        ? 'rgba(245,158,11,0.12)'
        : 'rgba(59,130,246,0.12)'

const changeColor = (c: string) =>
  c === 'up' ? C.bullish : c === 'down' ? C.bearish : c === 'new' ? C.info : C.textTertiary

const changeLabel = (c: string) =>
  c === 'up' ? 'UP ↑' : c === 'down' ? 'DOWN ↓' : c === 'new' ? 'NEW' : '—'

const gradeColor = (g: string) =>
  g.startsWith('A') ? C.bullish : g.startsWith('B') ? C.info : g.startsWith('C') ? C.neutral : C.bearish

/* ──────── multi-dimensional scorecard data (augmented) ──────── */

const scorecardDimensions = [
  { dimension: '方向判断', score: 9, fullMark: 10 },
  { dimension: '时机把握', score: 8, fullMark: 10 },
  { dimension: '风险控制', score: 7, fullMark: 10 },
  { dimension: '信息覆盖', score: 8, fullMark: 10 },
  { dimension: '执行纪律', score: 7, fullMark: 10 },
]

/* ──────── mock position review data (new section) ──────── */

interface PositionReview {
  name: string
  ticker: string
  position: number
  entryPrice: number
  currentPrice: number
  pnlPercent: number
  stopLoss: number
  stopTriggered: boolean
  maxDrawdown: number
}

const mockPositions: PositionReview[] = [
  { name: 'NVIDIA', ticker: 'NVDA', position: 7.0, entryPrice: 120.5, currentPrice: 131.0, pnlPercent: 8.71, stopLoss: 110, stopTriggered: false, maxDrawdown: -2.1 },
  { name: 'Microsoft', ticker: 'MSFT', position: 8.5, entryPrice: 445.0, currentPrice: 452.5, pnlPercent: 1.69, stopLoss: 410, stopTriggered: false, maxDrawdown: -0.8 },
  { name: 'Tencent', ticker: '0700.HK', position: 6.5, entryPrice: 405.0, currentPrice: 412.2, pnlPercent: 1.78, stopLoss: 370, stopTriggered: false, maxDrawdown: -1.2 },
  { name: 'Alibaba', ticker: '9988.HK', position: 5.0, entryPrice: 80.5, currentPrice: 82.4, pnlPercent: 2.36, stopLoss: 70, stopTriggered: false, maxDrawdown: -1.5 },
  { name: 'Xiaomi', ticker: '1810.HK', position: 5.0, entryPrice: 18.5, currentPrice: 19.84, pnlPercent: 7.24, stopLoss: 16, stopTriggered: false, maxDrawdown: -3.2 },
  { name: 'Tesla', ticker: 'TSLA', position: 4.0, entryPrice: 248.0, currentPrice: 242.8, pnlPercent: -2.10, stopLoss: 195, stopTriggered: false, maxDrawdown: -4.5 },
  { name: 'Apple', ticker: 'AAPL', position: 0, entryPrice: 225.0, currentPrice: 218.5, pnlPercent: -2.89, stopLoss: 240, stopTriggered: true, maxDrawdown: -3.8 },
]

/* ─────────────────────────── component ─────────────────────────── */

export default function EveningReport() {
  const [data, setData] = useState<EveningReportData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/data/evening_report.json')
      .then((r) => r.json())
      .then((d: EveningReportData) => {
        setData(d)
        setLoading(false)
      })
      .catch((err) => {
        console.error(err)
        setLoading(false)
      })
  }, [])

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-[#8A93A8] font-mono text-sm flex items-center gap-2">
          <Sunset className="h-4 w-4 animate-pulse" />
          加载晚报数据...
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-[#EF4444] font-mono text-sm">数据加载失败</div>
      </div>
    )
  }

  const etfFlowData = data.flowsPositioning.etfFlows.map((etf) => ({
    name: etf.name,
    flow: etf.direction === 'inflow' ? etf.flow : -etf.flow,
  }))

  const southboundFlowData = [
    { day: 'T-4', amount: 62.3 },
    { day: 'T-3', amount: 58.1 },
    { day: 'T-2', amount: 71.5 },
    { day: '昨日', amount: 65.2 },
    { day: '今日', amount: 84.5 },
  ]

  const ahHistoryData = data.hShareClose.ahPremium.history.map((v, i) => ({
    day: `D-${data.hShareClose.ahPremium.history.length - 1 - i}`,
    value: v,
  }))

  // Calculate scorecard stats
  const avg5d = data.hShareClose.ahPremium.history.slice(-5).reduce((a, b) => a + b, 0) / Math.min(5, data.hShareClose.ahPremium.history.length)
  const avg20d = 139.8 // mock 20d average

  const totalPnl = mockPositions.reduce((acc, p) => acc + p.pnlPercent * p.position, 0) / 100
  const maxPortfolioDrawdown = Math.min(...mockPositions.map((p) => p.maxDrawdown))
  const stopsHit = mockPositions.filter((p) => p.stopTriggered).length

  return (
    <div className="space-y-8 pb-12">
      {/* ═══════════════ HERO ═══════════════ */}
      <section
        className="relative rounded-xl p-8 md:p-10 overflow-hidden"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(59,130,246,0.06) 0%, transparent 60%)',
        }}
      >
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: easeOut }}>
          <div className="flex items-center gap-3 mb-3">
            <span className="px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest" style={{ background: 'rgba(59,130,246,0.12)', color: C.info }}>
              盘后简报
            </span>
            <span className="px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest" style={{ background: signalBg('neutral'), color: C.neutral }}>
              市场收盘
            </span>
          </div>
          <h1 className="text-[36px] font-bold tracking-[-0.02em] text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            {data.generatedAt} 盘后 Recap
          </h1>
          <p className="mt-2 text-[14px] text-[#8A93A8]">
            {new Date(data.reportDate).toLocaleDateString('zh-CN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <p className="mt-1 text-[14px] text-[#5C6375]">盘后 recap 与信号更新</p>
        </motion.div>
      </section>

      {/* ═══════════════ MARKET RECAP ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            borderLeft: `3px solid ${C.gold}`,
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <FileText className="h-5 w-5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium tracking-[0.06em] text-[#D4AF37] uppercase">市场 Recap</span>
          </div>
          <p className="text-[14px] leading-[1.8] text-[#8A93A8] mb-5">{data.marketRecap.text}</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {data.marketRecap.keyStats.map((stat) => (
              <div key={stat.name} className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">{stat.name}</span>
                <span className="text-[16px] font-bold block text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {stat.name === '美元指数' ? stat.value.toFixed(2) : stat.name === '10年期收益率' ? `${stat.value}%` : stat.value.toLocaleString()}
                </span>
                <span className={cn('text-[10px]', stat.change >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                  {stat.change >= 0 ? '+' : ''}
                  {stat.change} ({stat.changePercent}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ A-SHARE + H-SHARE CLOSE ═══════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ── A-Share Close ── */}
        <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.5, ease: easeOut }}>
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
          >
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4 flex items-center gap-2">
              <Activity className="h-5 w-5 text-[#8A93A8]" />
              A股收盘
            </h2>
            <div className="space-y-4">
              {[data.aShareClose.shanghai, data.aShareClose.shenzhen, data.aShareClose.beijing].map((idx) => (
                <div key={idx.name} className="rounded-lg p-4" style={{ background: C.bgElevated }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[13px] font-semibold text-[#F0F2F8]">{idx.name}</span>
                    <span className="text-[10px] text-[#5C6375]">成交量: {idx.volume}</span>
                  </div>
                  <div className="flex items-baseline gap-3 mb-2">
                    <span className="text-[24px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {idx.value.toLocaleString()}
                    </span>
                    <span className={cn('text-[13px] font-medium', idx.change >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                      {idx.change >= 0 ? '+' : ''}
                      {idx.change} ({idx.changePercent}%)
                    </span>
                  </div>
                  {/* Day range bar */}
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] text-[#5C6375]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {idx.dayLow.toFixed(0)}
                    </span>
                    <div className="flex-1 h-1.5 rounded-full relative" style={{ background: '#232837' }}>
                      <div
                        className="absolute top-0 left-0 h-full rounded-full"
                        style={{ width: `${((idx.value - idx.dayLow) / (idx.dayHigh - idx.dayLow)) * 100}%`, background: C.gold }}
                      />
                    </div>
                    <span className="text-[9px] text-[#5C6375]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {idx.dayHigh.toFixed(0)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* ── H-Share Close ── */}
        <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.5, ease: easeOut }}>
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
          >
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4 flex items-center gap-2">
              <Globe className="h-5 w-5 text-[#8A93A8]" />
              H股收盘
            </h2>
            <div className="space-y-4">
              {/* Hang Seng */}
              <div className="rounded-lg p-4" style={{ background: C.bgElevated }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[13px] font-semibold text-[#F0F2F8]">{data.hShareClose.hangSeng.name}</span>
                  <span className="text-[10px] text-[#5C6375]">成交量: {data.hShareClose.hangSeng.volume}</span>
                </div>
                <div className="flex items-baseline gap-3 mb-2">
                  <span className="text-[24px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.hShareClose.hangSeng.value.toLocaleString()}
                  </span>
                  <span
                    className={cn(
                      'text-[13px] font-medium',
                      data.hShareClose.hangSeng.change >= 0 ? 'text-emerald-400' : 'text-red-400'
                    )}
                  >
                    {data.hShareClose.hangSeng.change >= 0 ? '+' : ''}
                    {data.hShareClose.hangSeng.change} ({data.hShareClose.hangSeng.changePercent}%)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-[#5C6375]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.hShareClose.hangSeng.dayLow.toFixed(0)}
                  </span>
                  <div className="flex-1 h-1.5 rounded-full relative" style={{ background: '#232837' }}>
                    <div
                      className="absolute top-0 left-0 h-full rounded-full"
                      style={{
                        width: `${((data.hShareClose.hangSeng.value - data.hShareClose.hangSeng.dayLow) / (data.hShareClose.hangSeng.dayHigh - data.hShareClose.hangSeng.dayLow)) * 100}%`,
                        background: C.gold,
                      }}
                    />
                  </div>
                  <span className="text-[9px] text-[#5C6375]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.hShareClose.hangSeng.dayHigh.toFixed(0)}
                  </span>
                </div>
              </div>

              {/* AH Premium with history comparison */}
              <div className="rounded-lg p-4" style={{ background: C.bgElevated }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[13px] font-semibold text-[#F0F2F8]">{data.hShareClose.ahPremium.name}</span>
                  <span className="text-[13px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.hShareClose.ahPremium.value}
                  </span>
                </div>
                {/* History mini chart */}
                <div className="h-[60px] mb-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={ahHistoryData}>
                      <defs>
                        <linearGradient id="ahGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.gold} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={C.gold} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="value" stroke={C.gold} strokeWidth={2} fill="url(#ahGrad)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-[#5C6375]">5日均: <span className="text-[#F0F2F8] font-mono">{avg5d.toFixed(1)}</span></span>
                  <span className="text-[#5C6375]">20日均: <span className="text-[#F0F2F8] font-mono">{avg20d.toFixed(1)}</span></span>
                  <span className={cn('font-medium', data.hShareClose.ahPremium.value > avg20d ? 'text-red-400' : 'text-emerald-400')}>
                    vs 20日: {((data.hShareClose.ahPremium.value - avg20d) / avg20d * 100).toFixed(1)}%
                  </span>
                </div>
                <p className="mt-1 text-[10px] text-[#5C6375]">{data.hShareClose.ahPremium.note}</p>
              </div>

              {/* Southbound Flows Bar Chart */}
              <div className="rounded-lg p-4" style={{ background: C.bgElevated }}>
                <span className="text-[13px] font-semibold text-[#F0F2F8] block mb-2">南向资金流向 (亿港元)</span>
                <div className="h-[120px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={southboundFlowData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                      <XAxis dataKey="day" tick={{ fill: '#5C6375', fontSize: 10 }} stroke="#5C6375" />
                      <YAxis tick={{ fill: '#5C6375', fontSize: 10 }} stroke="#5C6375" />
                      <Tooltip
                        contentStyle={{
                          background: '#1C1F2B',
                          border: '1px solid rgba(255,255,255,0.1)',
                          borderRadius: 8,
                        }}
                        labelStyle={{ color: '#F0F2F8', fontSize: 12 }}
                        itemStyle={{ color: '#10B981', fontSize: 12 }}
                      />
                      <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                        {southboundFlowData.map((_, i) => (
                          <Cell key={`cell-${i}`} fill={i === southboundFlowData.length - 1 ? C.bullish : '#3B82F6'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-[#5C6375]">今日: <span className="text-emerald-400 font-semibold">+{data.hShareClose.crossBorderFlows.southbound.amount}亿</span></span>
                  <span className="text-[10px] text-[#5C6375]">{data.hShareClose.crossBorderFlows.netTrend}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      </div>

      {/* ═══════════════ US MARKET + FLOWS (2-col) ═══════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ── US Market Wrap ── */}
        <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.5, ease: easeOut }}>
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
          >
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4 flex items-center gap-2">
              <Globe className="h-5 w-5 text-[#8A93A8]" />
              美股市场回顾
            </h2>
            <div className="space-y-3 mb-5">
              {data.usMarketWrap.indices.map((idx) => (
                <div key={idx.name} className="flex items-center justify-between rounded-lg p-3" style={{ background: C.bgElevated }}>
                  <div>
                    <span className="text-[13px] font-medium text-[#F0F2F8] block">{idx.name}</span>
                    <span className="text-[10px] text-[#5C6375]">期货: {idx.futures.toLocaleString()}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[14px] font-semibold text-[#F0F2F8] block" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {idx.close.toLocaleString()}
                    </span>
                    <span className={cn('text-[10px]', idx.change >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                      {idx.change >= 0 ? '+' : ''}
                      {idx.change} ({idx.changePercent}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {/* Sector Performance Chart */}
            <div className="mb-4">
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">板块表现</span>
              <div className="h-[180px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={data.usMarketWrap.sectorPerformance}
                    layout="vertical"
                    margin={{ top: 0, right: 20, left: 60, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis type="number" tick={{ fill: '#5C6375', fontSize: 10 }} stroke="#5C6375" domain={[-1, 2]} />
                    <YAxis dataKey="name" type="category" tick={{ fill: '#8A93A8', fontSize: 10 }} stroke="#5C6375" width={55} />
                    <Tooltip
                      contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                      itemStyle={{ color: '#F0F2F8', fontSize: 12 }}
                      formatter={(value: number) => [`${value >= 0 ? '+' : ''}${value}%`, '涨跌幅']}
                    />
                    <Bar dataKey="change" radius={[0, 4, 4, 0]}>
                      {data.usMarketWrap.sectorPerformance.map((entry, i) => (
                        <Cell key={i} fill={entry.change >= 0 ? C.bullish : C.bearish} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            {/* Notable Movers */}
            <div>
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">重点异动</span>
              <div className="space-y-1.5">
                {data.usMarketWrap.notableMovers.map((mover, i) => (
                  <div key={i} className="flex items-center gap-2 text-[12px] text-[#8A93A8]">
                    <span className="text-[#D4AF37]">●</span>
                    {mover}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.section>

        {/* ── Flows & Positioning ── */}
        <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.5, ease: easeOut }}>
          <div
            className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 h-full"
            style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
          >
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4 flex items-center gap-2">
              <Wallet className="h-5 w-5 text-[#8A93A8]" />
              资金流向与仓位
            </h2>

            {/* ETF Flows Bar Chart */}
            <div className="mb-5">
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">ETF 净流量 (十亿美元)</span>
              <div className="h-[160px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={etfFlowData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="name" tick={{ fill: '#5C6375', fontSize: 11 }} stroke="#5C6375" />
                    <YAxis tick={{ fill: '#5C6375', fontSize: 10 }} stroke="#5C6375" />
                    <Tooltip
                      contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                      itemStyle={{ color: '#F0F2F8', fontSize: 12 }}
                      formatter={(value: number) => [`${value >= 0 ? '+' : ''}${value}B`, '流量']}
                    />
                    <Bar dataKey="flow" radius={[4, 4, 0, 0]}>
                      {etfFlowData.map((entry, i) => (
                        <Cell key={i} fill={entry.flow >= 0 ? C.bullish : C.bearish} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Institutional Positioning */}
            <div className="rounded-lg p-4 mb-4" style={{ background: C.bgElevated }}>
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">机构持仓</span>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: '#232837' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${data.flowsPositioning.institutionalPositioning.netLong}%` }}
                    transition={{ delay: 0.8, duration: 0.8, ease: easeOut }}
                    className="h-full rounded-full"
                    style={{ background: C.bullish }}
                  />
                </div>
                <span className="text-[13px] font-semibold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {data.flowsPositioning.institutionalPositioning.netLong}%
                </span>
              </div>
              <span className="text-[11px] text-[#5C6375] mt-1 block">{data.flowsPositioning.institutionalPositioning.label}</span>
            </div>

            {/* Retail Sentiment */}
            <div className="rounded-lg p-4 mb-4" style={{ background: C.bgElevated }}>
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">散户情绪</span>
              <div className="flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-full border-4 flex items-center justify-center"
                  style={{
                    borderColor:
                      data.flowsPositioning.retailSentiment.score > 60
                        ? C.bullish
                        : data.flowsPositioning.retailSentiment.score > 40
                          ? C.neutral
                          : C.bearish,
                  }}
                >
                  <span className="text-[13px] font-bold text-[#F0F2F8]">{data.flowsPositioning.retailSentiment.score}</span>
                </div>
                <div>
                  <span className="text-[13px] font-semibold text-[#F0F2F8] block">{data.flowsPositioning.retailSentiment.label}</span>
                  <span className="text-[10px] text-[#5C6375]">
                    {data.flowsPositioning.retailSentiment.score > 75 ? '极度贪婪 - 需警惕' : data.flowsPositioning.retailSentiment.score > 60 ? '贪婪区间' : '中性'}
                  </span>
                </div>
              </div>
            </div>

            {/* Futures Positioning */}
            <div className="rounded-lg p-4" style={{ background: C.bgElevated }}>
              <span className="text-[10px] uppercase tracking-wider block mb-2 text-[#5C6375]">期货持仓</span>
              <p className="text-[12px] text-[#8A93A8] leading-relaxed">{data.flowsPositioning.futuresPositioning}</p>
            </div>
          </div>
        </motion.section>
      </div>

      {/* ═══════════════ NEWS TIMELINE ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.5, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
        >
          <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-6 flex items-center gap-2">
            <Bell className="h-5 w-5 text-[#D4AF37]" />
            新闻时间线
          </h2>
          <div className="relative pl-8">
            {/* Timeline line */}
            <div className="absolute left-3 top-0 bottom-0 w-px" style={{ background: 'linear-gradient(180deg, #2A2F3D 0%, transparent 100%)' }} />
            <div className="space-y-6">
              {data.newsEvents.map((event, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + i * 0.06, duration: 0.4, ease: easeOut }}
                  className="relative"
                >
                  {/* Dot */}
                  <div
                    className="absolute -left-6 top-1 w-3 h-3 rounded-full border-2"
                    style={{
                      borderColor: event.impact === 'bullish' ? C.bullish : event.impact === 'bearish' ? C.bearish : C.neutral,
                      background: C.bgCard,
                    }}
                  />
                  <div className="flex items-start gap-4">
                    <span className="text-[11px] font-medium mt-0.5 min-w-[40px] text-[#5C6375]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {event.time}
                    </span>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[14px] font-semibold mb-1 text-[#F0F2F8]">{event.headline}</h4>
                      <p className="text-[12px] text-[#8A93A8] mb-1.5 leading-relaxed">{event.description}</p>
                      <div className="flex items-center gap-2">
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide"
                          style={{ background: signalBg(event.impact), color: signalColor(event.impact) }}
                        >
                          {event.impact === 'bullish' && <ArrowUp className="h-3 w-3" />}
                          {event.impact === 'bearish' && <ArrowDown className="h-3 w-3" />}
                          {event.impact === 'neutral' && <Minus className="h-3 w-3" />}
                          {event.impact.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-[#5C6375]">{event.source}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ UPDATED TIMING SIGNALS ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7, duration: 0.5, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
        >
          <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-[#D4AF37]" />
              更新后的时机信号
            </h2>
            <div className="flex gap-2 flex-wrap">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={{ background: 'rgba(59,130,246,0.12)', color: C.info }}>
                新增: {data.updatedTimingSignals.changes.new}
              </span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={{ background: signalBg('bullish'), color: C.bullish }}>
                上调: {data.updatedTimingSignals.changes.upgraded}
              </span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={{ background: signalBg('bearish'), color: C.bearish }}>
                下调: {data.updatedTimingSignals.changes.downgraded}
              </span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={{ background: C.bgElevated, color: C.textTertiary }}>
                不变: {data.updatedTimingSignals.changes.unchanged}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: C.bgElevated }}>
                  {['排名', '标的', '信号', '入场', '目标', '止损', '盈亏比', '变化', '走势'].map((h) => (
                    <th key={h} className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.updatedTimingSignals.signals.map((s, i) => (
                  <motion.tr
                    key={s.rank}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + i * 0.04, duration: 0.4, ease: easeOut }}
                    className="border-t border-[rgba(255,255,255,0.06)] hover:bg-[#232837] transition-colors"
                    style={{ borderLeft: `3px solid ${signalColor(s.signal)}` }}
                  >
                    <td className="px-3 py-3 text-[11px] text-[#5C6375]">{s.rank}</td>
                    <td className="px-3 py-3">
                      <span className="text-[13px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                        {s.asset}
                      </span>
                      {s.changeNote && <p className="text-[10px] text-[#8A93A8] mt-0.5">{s.changeNote}</p>}
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide"
                        style={{ background: signalBg(s.signal), color: signalColor(s.signal) }}
                      >
                        {s.signal === 'bullish' && <ArrowUp className="h-3 w-3" />}
                        {s.signal === 'bearish' && <ArrowDown className="h-3 w-3" />}
                        {s.signal === 'neutral' && <Minus className="h-3 w-3" />}
                        {s.signal.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-[12px] text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {s.entry}
                    </td>
                    <td className="px-3 py-3 text-[12px] text-emerald-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {s.target}
                    </td>
                    <td className="px-3 py-3 text-[12px] text-red-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {s.stop}
                    </td>
                    <td className="px-3 py-3 text-[12px] font-medium text-[#3B82F6]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {s.rr}
                    </td>
                    <td className="px-3 py-3">
                      {s.change !== 'unchanged' ? (
                        <span
                          className="px-2 py-0.5 rounded text-[10px] font-semibold"
                          style={{
                            background: signalBg(s.change === 'up' ? 'bullish' : s.change === 'down' ? 'bearish' : 'neutral'),
                            color: changeColor(s.change),
                          }}
                        >
                          {changeLabel(s.change)}
                        </span>
                      ) : (
                        <span className="text-[11px] text-[#5C6375]">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <MiniSparkline data={s.trend} color={signalColor(s.signal)} />
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ DAY SCORECARD (improved with radar chart) ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8, duration: 0.5, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
        >
          <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-5 flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5 text-[#D4AF37]" />
            日评分卡
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: Original metrics */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">方向判断</span>
                  <span className={cn('text-[16px] font-bold', data.dayScorecard.directionalAccuracy.correct ? 'text-emerald-400' : 'text-red-400')}>
                    {data.dayScorecard.directionalAccuracy.correct ? '✓' : '✗'} {data.dayScorecard.directionalAccuracy.label}
                  </span>
                </div>
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">关键位触及</span>
                  <span className="text-[16px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.dayScorecard.keyLevelsHit.hit}/{data.dayScorecard.keyLevelsHit.total}
                  </span>
                </div>
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">信号表现</span>
                  <span className="text-[16px] font-bold text-emerald-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.dayScorecard.signalPerformance.label}
                  </span>
                </div>
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">波动预测</span>
                  <span className={cn('text-[16px] font-bold', data.dayScorecard.volatilityForecast.correct ? 'text-emerald-400' : 'text-red-400')}>
                    {data.dayScorecard.volatilityForecast.correct ? '✓' : '✗'} {data.dayScorecard.volatilityForecast.label}
                  </span>
                </div>
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">新闻影响</span>
                  <span className="text-[14px] font-bold text-[#F0F2F8]">
                    {data.dayScorecard.newsImpact.predicted}/{data.dayScorecard.newsImpact.total} 已预测
                  </span>
                </div>
                <div className="rounded-lg p-3 text-center" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-1 text-[#5C6375]">综合评分</span>
                  <span className="text-[28px] font-bold" style={{ color: gradeColor(data.dayScorecard.overallGrade), fontFamily: "'JetBrains Mono', monospace" }}>
                    {data.dayScorecard.overallGrade}
                  </span>
                </div>
              </div>

              {/* Winners / Losers */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg p-3" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-2 text-emerald-400">领涨</span>
                  {data.dayScorecard.winners.map((w) => (
                    <div key={w.asset} className="flex items-center justify-between text-[12px] mb-1">
                      <span className="text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{w.asset}</span>
                      <span className="text-emerald-400 font-medium">+{w.return}%</span>
                    </div>
                  ))}
                </div>
                <div className="rounded-lg p-3" style={{ background: C.bgElevated }}>
                  <span className="text-[10px] uppercase tracking-wider block mb-2 text-red-400">领跌</span>
                  {data.dayScorecard.losers.map((l) => (
                    <div key={l.asset} className="flex items-center justify-between text-[12px] mb-1">
                      <span className="text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{l.asset}</span>
                      <span className="text-red-400 font-medium">{l.return}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Radar Chart */}
            <div className="flex flex-col items-center">
              <span className="text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase mb-2">多维度表现评估</span>
              <div className="w-full" style={{ height: 280 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="70%" data={scorecardDimensions}>
                    <PolarGrid stroke="rgba(255,255,255,0.1)" />
                    <PolarAngleAxis dataKey="dimension" tick={{ fill: '#8A93A8', fontSize: 11 }} />
                    <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fill: '#5C6375', fontSize: 9 }} />
                    <Radar
                      name="今日评分"
                      dataKey="score"
                      stroke={C.gold}
                      fill={C.gold}
                      fillOpacity={0.25}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center gap-4 mt-2">
                {scorecardDimensions.map((d) => (
                  <div key={d.dimension} className="text-center">
                    <span className="text-[10px] text-[#5C6375] block">{d.dimension}</span>
                    <span className="text-[12px] font-bold text-[#D4AF37]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                      {d.score}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ CIO CLOSING NOTES (improved structured) ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9, duration: 0.5, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6 relative overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
            boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            borderLeft: `3px solid ${C.gold}`,
          }}
        >
          <div className="absolute top-0 right-0 w-40 h-40 opacity-5" style={{ background: 'radial-gradient(circle, #D4AF37 0%, transparent 70%)' }} />

          <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-5 flex items-center gap-2">
            <User className="h-5 w-5 text-[#D4AF37]" />
            CIO收盘笔记
          </h2>

          {/* Structured cards: Right / Wrong / Tomorrow Plan */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* What went right */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0, duration: 0.4, ease: easeOut }}
              className="rounded-lg p-4 border border-[rgba(16,185,129,0.2)]"
              style={{ background: 'rgba(16,185,129,0.05)' }}
            >
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span className="text-[12px] font-semibold text-emerald-400 uppercase tracking-wider">今日做对的事</span>
              </div>
              <ul className="space-y-2">
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-emerald-400 mt-1">●</span>
                  正确判断美联储纪要鸽派倾向，提前增持科技仓位
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-emerald-400 mt-1">●</span>
                  NVIDIA业绩前维持 overweight，获益+8.7%
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-emerald-400 mt-1">●</span>
                  波动率预测准确，未过度对冲
                </li>
              </ul>
            </motion.div>

            {/* What went wrong */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.1, duration: 0.4, ease: easeOut }}
              className="rounded-lg p-4 border border-[rgba(239,68,68,0.2)]"
              style={{ background: 'rgba(239,68,68,0.05)' }}
            >
              <div className="flex items-center gap-2 mb-3">
                <XCircle className="h-4 w-4 text-red-400" />
                <span className="text-[12px] font-semibold text-red-400 uppercase tracking-wider">今日做错的事</span>
              </div>
              <ul className="space-y-2">
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-red-400 mt-1">●</span>
                  Apple减仓不够果断，-2.9%拖累组合
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-red-400 mt-1">●</span>
                  能源板块加仓时机偏早
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-red-400 mt-1">●</span>
                  港股开盘仓位偏重，承受了早盘波动
                </li>
              </ul>
            </motion.div>

            {/* Tomorrow Plan */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2, duration: 0.4, ease: easeOut }}
              className="rounded-lg p-4 border border-[rgba(59,130,246,0.2)]"
              style={{ background: 'rgba(59,130,246,0.05)' }}
            >
              <div className="flex items-center gap-2 mb-3">
                <CalendarDays className="h-4 w-4 text-[#3B82F6]" />
                <span className="text-[12px] font-semibold text-[#3B82F6] uppercase tracking-wider">明日计划</span>
              </div>
              <ul className="space-y-2">
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-[#3B82F6] mt-1">●</span>
                  关注核心PCE数据，准备应对波动
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-[#3B82F6] mt-1">●</span>
                  评估是否进一步减持AAPL
                </li>
                <li className="text-[12px] text-[#8A93A8] flex items-start gap-2">
                  <span className="text-[#3B82F6] mt-1">●</span>
                  观察5930阻力位的突破情况
                </li>
              </ul>
            </motion.div>
          </div>

          {/* Watch List */}
          <div className="rounded-lg p-4 mb-4" style={{ background: C.bgElevated }}>
            <span className="text-[11px] font-medium uppercase tracking-wider block mb-3 text-[#D4AF37]">隔夜观察清单</span>
            <div className="space-y-2">
              {data.cioClosingNote.watchList.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.3 + i * 0.08, duration: 0.4, ease: easeOut }}
                  className="flex items-start gap-2 text-[12px] text-[#8A93A8]"
                >
                  <ListChecks className="h-3.5 w-3.5 mt-0.5 text-[#D4AF37] flex-shrink-0" />
                  {item}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Tomorrow Preview */}
          <div className="rounded-lg p-4" style={{ background: 'rgba(212,175,55,0.08)', border: '1px solid rgba(212,175,55,0.15)' }}>
            <span className="text-[11px] font-medium uppercase tracking-wider block mb-1 text-[#D4AF37]">明日预览</span>
            <p className="text-[13px] text-[#D4AF37] leading-relaxed">{data.cioClosingNote.tomorrowPreview}</p>
          </div>
        </div>
      </motion.section>

      {/* ═══════════════ POSITION REVIEW (NEW!) ═══════════════ */}
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.0, duration: 0.5, ease: easeOut }}>
        <div
          className="rounded-xl border border-[rgba(255,255,255,0.06)] p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', boxShadow: '0 4px 24px rgba(0,0,0,0.4)' }}
        >
          <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
            <h2 className="text-[18px] font-semibold text-[#F0F2F8] flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-[#D4AF37]" />
              持仓复盘
            </h2>
            {/* KPI Cards */}
            <div className="flex gap-3 flex-wrap">
              <div className="rounded-lg px-4 py-2 text-center" style={{ background: C.bgElevated }}>
                <span className="text-[10px] uppercase tracking-wider text-[#5C6375] block">组合盈亏</span>
                <span className={cn('text-[16px] font-bold', totalPnl >= 0 ? 'text-emerald-400' : 'text-red-400')} style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {totalPnl >= 0 ? '+' : ''}
                  {totalPnl.toFixed(2)}%
                </span>
              </div>
              <div className="rounded-lg px-4 py-2 text-center" style={{ background: C.bgElevated }}>
                <span className="text-[10px] uppercase tracking-wider text-[#5C6375] block">最大回撤</span>
                <span className="text-[16px] font-bold text-red-400" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {maxPortfolioDrawdown.toFixed(1)}%
                </span>
              </div>
              <div className="rounded-lg px-4 py-2 text-center" style={{ background: C.bgElevated }}>
                <span className="text-[10px] uppercase tracking-wider text-[#5C6375] block">止损触发</span>
                <span className="text-[16px] font-bold text-[#F59E0B]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {stopsHit}
                </span>
              </div>
            </div>
          </div>

          {/* Position Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: C.bgElevated }}>
                  {['标的', '仓位%', '入场价', '当前价', '盈亏%', '止损', '状态', '最大回撤'].map((h) => (
                    <th key={h} className="text-left text-[11px] font-medium tracking-[0.06em] text-[#5C6375] uppercase px-3 py-3">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {mockPositions.map((pos, i) => (
                  <motion.tr
                    key={pos.ticker}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1.1 + i * 0.04, duration: 0.4, ease: easeOut }}
                    className="border-t border-[rgba(255,255,255,0.06)] hover:bg-[#232837] transition-colors"
                  >
                    <td className="px-3 py-3">
                      <span className="text-[13px] font-bold text-[#F0F2F8]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                        {pos.ticker}
                      </span>
                      <span className="text-[11px] text-[#5C6375] ml-2">{pos.name}</span>
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#F0F2F8]">{pos.position}%</td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#8A93A8]">${pos.entryPrice.toFixed(1)}</td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#F0F2F8]">${pos.currentPrice.toFixed(1)}</td>
                    <td className="px-3 py-3">
                      <span
                        className={cn(
                          'text-[12px] font-mono font-bold',
                          pos.pnlPercent >= 0 ? 'text-emerald-400' : 'text-red-400'
                        )}
                      >
                        {pos.pnlPercent >= 0 ? '+' : ''}
                        {pos.pnlPercent.toFixed(2)}%
                      </span>
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-red-400">${pos.stopLoss}</td>
                    <td className="px-3 py-3">
                      {pos.stopTriggered ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[rgba(239,68,68,0.12)] text-red-400">
                          <AlertTriangle className="h-3 w-3" />
                          已触发
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[rgba(16,185,129,0.12)] text-emerald-400">
                          <Target className="h-3 w-3" />
                          持仓中
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#F59E0B]">{pos.maxDrawdown}%</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.section>
    </div>
  )
}

/* ═══════════════════════════ Mini Sparkline ═══════════════════════════ */

function MiniSparkline({ data, color }: { data: number[]; color: string }) {
  if (!data || data.length < 2) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const w = 60
  const h = 24
  const points = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - 2 - ((v - min) / range) * (h - 4)}`).join(' ')
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" />
    </svg>
  )
}
