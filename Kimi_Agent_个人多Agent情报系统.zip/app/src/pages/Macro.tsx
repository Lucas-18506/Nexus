import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, Minus, AlertTriangle,
  Gauge, BarChart3,
  Clock, ChevronUp, ChevronDown
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area,
  XAxis, YAxis, BarChart, Bar, Cell
} from 'recharts';
import DataCard from '@/components/DataCard';
import SentimentGauge from '@/components/SentimentGauge';
import VerdictBadge from '@/components/VerdictBadge';

/* ───────── Types ───────── */
interface HistoryPoint {
  date: string;
  value: number;
}

interface IndicatorData {
  current: number;
  change: number;
  changePercent: number;
  signal: string;
  signalColor: string;
  history: HistoryPoint[];
  normalRange?: number[];
  note?: string;
  trend?: string;
}

interface TimingSignal {
  asset: string;
  name: string;
  signal: string;
  entry: number;
  target: number;
  stopLoss: number;
  rr: string;
  trend: number[];
  confidence: number;
  technicalSummary: string;
  note: string;
  updated: string;
}

interface YieldMaturity {
  maturity: string;
  yield: number;
}

interface YieldCurve {
  spread10Y2Y: number;
  inverted: boolean;
  warning: string;
  maturities: YieldMaturity[];
}

interface MacroData {
  vix: IndicatorData;
  treasury10y: IndicatorData;
  goldSilverRatio: IndicatorData;
  copperOilRatio: IndicatorData;
  cpi: IndicatorData;
  ppi: IndicatorData;
  dxy: IndicatorData;
  usdcny: IndicatorData;
  yieldCurve: YieldCurve;
  timingSignals: TimingSignal[];
}

interface SentimentData {
  overallScore: number;
  overallLabel: string;
  dimensions: { name: string; score: number }[];
  emotionMatrix: { dimension: string; value: number; status: string }[];
}

/* ───────── Colors ───────── */
const C = {
  bullish: '#10B981',
  bearish: '#EF4444',
  neutral: '#F59E0B',
  info: '#3B82F6',
  gold: '#D4AF37',
  textPrimary: '#F0F2F8',
  textSecondary: '#8A93A8',
  textTertiary: '#5C6375',
  bgCard: '#14171F',
  bgElevated: '#1C1F2B',
  borderSubtle: 'rgba(255,255,255,0.06)',
};

/* ───────── Helpers ───────── */
const signalColor = (s: string) => {
  const col = s?.toLowerCase();
  if (col === 'bullish' || col === 'buy' || col === 'add') return C.bullish;
  if (col === 'bearish' || col === 'sell') return C.bearish;
  return C.neutral;
};

function fearGreedLabel(score: number): string {
  if (score <= 20) return '极度恐惧';
  if (score <= 40) return '恐惧';
  if (score <= 60) return '中性';
  if (score <= 80) return '贪婪';
  return '极度贪婪';
}

function fearGreedColor(score: number): string {
  if (score <= 20) return C.bearish;
  if (score <= 40) return '#F87171';
  if (score <= 60) return C.neutral;
  if (score <= 80) return '#34D399';
  return C.bullish;
}

function calcPercentile(history: HistoryPoint[]): string {
  if (!history || history.length < 2) return '--';
  const values = history.map(h => h.value);
  const latest = values[values.length - 1];
  const sorted = [...values].sort((a, b) => a - b);
  const rank = sorted.indexOf(latest);
  const pct = Math.round((rank / (sorted.length - 1)) * 100);
  return `${pct}th`;
}

function trendArrow(current: number, previous: number) {
  if (current > previous) return <ChevronUp size={14} className="text-bullish" />;
  if (current < previous) return <ChevronDown size={14} className="text-bearish" />;
  return <Minus size={14} className="text-neutral" />;
}

/* Extract keyword tags from technical summary */
function extractTechTags(summary: string): string[] {
  if (!summary) return [];
  // Common technical analysis keywords
  const keywords = [
    '突破', '跌破', '金叉', '死叉', '顶背离', '底背离',
    '多头排列', '空头排列', '盘整', '震荡',
    '上升三角', '下降三角', '头肩', '双底', '双顶',
    '杯柄', '旗形', '楔形', '通道',
    '超买', '超卖', '背离', '共振',
    '放量', '缩量', '背驰',
    '支撑位', '阻力位', '趋势线',
    'MA20', 'MA50', 'MA200', 'MACD', 'RSI', '布林带'
  ];
  const found: string[] = [];
  keywords.forEach(kw => {
    if (summary.includes(kw)) found.push(kw);
  });
  if (found.length === 0) return [summary]; // fallback: return full summary
  return found;
}

/* ───────── Data Hook ───────── */
function useMacroData() {
  const [macro, setMacro] = useState<MacroData | null>(null);
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetch('/data/macro.json').then(r => r.json()).catch(() => null),
      fetch('/data/sentiment.json').then(r => r.json()).catch(() => null),
    ])
      .then(([m, s]) => {
        setMacro(m);
        // Build sentiment data with fallback
        setSentiment(s || {
          overallScore: 55,
          overallLabel: '中性',
          dimensions: [
            { name: 'VIX情绪', score: 45 },
            { name: '资金流向', score: 62 },
            { name: '动量指标', score: 58 },
          ],
          emotionMatrix: [
            { dimension: '趋势动能', value: 65, status: 'positive' },
            { dimension: '情绪极端度', value: 35, status: 'neutral' },
            { dimension: '宏观动能', value: 58, status: 'neutral' },
            { dimension: '资金流向', value: 72, status: 'positive' },
            { dimension: '波动率结构', value: 42, status: 'neutral' },
            { dimension: '相关性结构', value: 55, status: 'neutral' },
          ]
        });
        setLoading(false);
      })
      .catch(err => {
        setError(String(err));
        setLoading(false);
      });
  }, []);

  return { macro, sentiment, loading, error };
}

/* ───────── Sparkline Component ───────── */
function Sparkline({ data, color, height = 80 }: { data: HistoryPoint[]; color: string; height?: number }) {
  const chartData = useMemo(() =>
    (data || []).map((h, i) => ({ i, v: h.value })),
    [data]
  );

  if (!chartData.length) return <div style={{ height }} className="flex items-center justify-center"><span style={{ color: C.textTertiary }} className="text-[10px]">无数据</span></div>;

  return (
    <div style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
          <defs>
            <linearGradient id={`spark-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.3} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="i" hide />
          <YAxis hide domain={['auto', 'auto']} />
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={2}
            fill={`url(#spark-${color.replace('#', '')})`}
            isAnimationActive
            animationDuration={1000}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ───────── Macro Calendar (Preset) ───────── */
const MACRO_CALENDAR = [
  { date: '2025-05-29', event: '美国GDP修正值', expectation: '1.3%', previous: '1.2%', importance: 'high' as const },
  { date: '2025-05-30', event: '核心PCE价格指数', expectation: '2.6%', previous: '2.8%', importance: 'high' as const },
  { date: '2025-06-02', event: 'ISM制造业PMI', expectation: '49.8', previous: '48.7', importance: 'high' as const },
  { date: '2025-06-04', event: '美联储FOMC议息', expectation: '维持5.25-5.50%', previous: '5.25-5.50%', importance: 'high' as const },
  { date: '2025-06-05', event: '美联储主席新闻发布会', expectation: '--', previous: '--', importance: 'high' as const },
  { date: '2025-06-06', event: '非农就业报告(NFP)', expectation: '18.5万', previous: '17.5万', importance: 'high' as const },
  { date: '2025-06-10', event: '美国CPI同比', expectation: '2.3%', previous: '2.4%', importance: 'high' as const },
  { date: '2025-06-11', event: 'PPI生产者价格指数', expectation: '1.7%', previous: '1.8%', importance: 'medium' as const },
  { date: '2025-06-12', event: '初请失业金人数', expectation: '21.5万', previous: '21.8万', importance: 'medium' as const },
  { date: '2025-06-17', event: '零售销售月率', expectation: '0.3%', previous: '0.1%', importance: 'medium' as const },
  { date: '2025-06-18', event: '新屋开工', expectation: '138万', previous: '136万', importance: 'medium' as const },
  { date: '2025-06-20', event: '消费者信心指数', expectation: '103.5', previous: '104.2', importance: 'medium' as const },
  { date: '2025-06-25', event: '耐用品订单', expectation: '0.5%', previous: '-0.1%', importance: 'low' as const },
  { date: '2025-06-27', event: '个人收入与支出', expectation: '0.4%', previous: '0.5%', importance: 'medium' as const },
  { date: '2025-06-28', event: '密歇根大学通胀预期', expectation: '3.2%', previous: '3.3%', importance: 'medium' as const },
];

/* ───────── Indicator Config ───────── */
const INDICATOR_CONFIG = [
  { key: 'vix', en: 'VIX', cn: '波动率指数', desc: '恐慌指数，>20警戒市场恐慌', color: C.info },
  { key: 'treasury10y', en: '10Y Treasury', cn: '10年期美债收益率', desc: '全球资产定价锚，影响估值贴现率', color: C.neutral },
  { key: 'goldSilverRatio', en: 'Gold/Silver Ratio', cn: '金银比', desc: '>80表示避险情绪升温，<60表示风险偏好升温', color: C.gold },
  { key: 'copperOilRatio', en: 'Copper/Oil Ratio', cn: '铜油比', desc: '经济增长代理指标，上升表明工业需求强劲', color: C.bullish },
  { key: 'cpi', en: 'CPI YoY', cn: 'CPI同比', desc: '消费端通胀水平，2%为美联储目标', color: C.bullish },
  { key: 'ppi', en: 'PPI YoY', cn: 'PPI同比', desc: '生产端通胀，领先CPI约3-6个月', color: C.neutral },
  { key: 'dxy', en: 'DXY', cn: '美元指数', desc: '美元对6大货币汇率，影响全球流动性', color: C.info },
  { key: 'usdcny', en: 'USD/CNY', cn: '美元兑人民币', desc: '中美利差与资本流动，>7.2触发情绪警戒', color: C.neutral },
];

/* ───────── Emotion Matrix Heatmap ───────── */
function EmotionMatrix({ matrix }: { matrix: { dimension: string; value: number; status: string }[] }) {
  const getColor = (val: number, status: string) => {
    if (status === 'positive') return val > 70 ? 'rgba(16,185,129,0.6)' : val > 50 ? 'rgba(16,185,129,0.35)' : 'rgba(16,185,129,0.15)';
    if (status === 'negative') return val > 70 ? 'rgba(239,68,68,0.6)' : val > 50 ? 'rgba(239,68,68,0.35)' : 'rgba(239,68,68,0.15)';
    return val > 70 ? 'rgba(245,158,11,0.6)' : val > 50 ? 'rgba(245,158,11,0.35)' : 'rgba(245,158,11,0.15)';
  };

  return (
    <div className="grid grid-cols-3 gap-3">
      {matrix.map((item, i) => (
        <motion.div
          key={item.dimension}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.08, duration: 0.4 }}
          className="rounded-lg p-4 text-center"
          style={{ background: getColor(item.value, item.status), border: `1px solid ${C.borderSubtle}` }}
        >
          <span className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: C.textSecondary }}>{item.dimension}</span>
          <span className="text-xl font-bold font-mono block" style={{ color: C.textPrimary }}>{item.value}</span>
          <div className="mt-1 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${item.value}%` }}
              transition={{ delay: i * 0.08 + 0.3, duration: 0.6 }}
              className="h-full rounded-full"
              style={{ background: item.status === 'positive' ? C.bullish : item.status === 'negative' ? C.bearish : C.neutral }}
            />
          </div>
        </motion.div>
      ))}
    </div>
  );
}

/* ───────── Yield Curve Bar Chart ───────── */
function YieldCurveChart({ data }: { data: YieldCurve }) {
  if (!data) return null;
  const chartData = data.maturities.map(m => ({
    maturity: m.maturity,
    yield: m.yield,
  }));

  return (
    <div className="mt-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-[10px]" style={{ color: data.inverted ? C.bearish : C.bullish }}>
          10Y-2Y = {data.spread10Y2Y}%
        </span>
        {data.inverted && <AlertTriangle size={12} style={{ color: C.bearish }} />}
        <span className="text-[10px]" style={{ color: data.inverted ? C.bearish : C.textTertiary }}>{data.warning}</span>
      </div>
      <div className="h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
            <XAxis dataKey="maturity" tick={{ fontSize: 10, fill: C.textTertiary }} axisLine={false} tickLine={false} />
            <YAxis hide domain={[0, 'auto']} />
            <Bar dataKey="yield" radius={[4, 4, 0, 0]}>
              {chartData.map((_, i) => (
                <Cell key={i} fill={i === 1 || i === 4 ? C.gold : C.info} fillOpacity={0.8} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/* ═══════════════════════════ PAGE ═══════════════════════════ */
export default function Macro() {
  const { macro, sentiment, loading, error } = useMacroData();

  if (loading) {
    return (
      <>
        <div className="flex items-center justify-center min-h-[60vh]" style={{ color: C.textSecondary }}>
          <Activity className="animate-pulse mr-2" /> 加载宏观数据...
        </div>
      </>
    );
  }

  if (error || !macro) {
    return (
      <>
        <div className="flex items-center justify-center min-h-[60vh]" style={{ color: C.bearish }}>
          <AlertTriangle className="mr-2" /> 数据加载失败，请稍后重试
        </div>
      </>
    );
  }

  const fgScore = sentiment?.overallScore ?? 50;
  const fgLabel = fearGreedLabel(fgScore);
  const fgColor = fearGreedColor(fgScore);

  // Build emotion matrix with fallback
  const emotionMatrix = sentiment?.emotionMatrix || [
    { dimension: '趋势动能', value: 65, status: 'positive' },
    { dimension: '情绪极端度', value: 35, status: 'neutral' },
    { dimension: '宏观动能', value: 58, status: 'neutral' },
    { dimension: '资金流向', value: 72, status: 'positive' },
    { dimension: '波动率结构', value: 42, status: 'neutral' },
    { dimension: '相关性结构', value: 55, status: 'neutral' },
  ];

  return (
    <>
      <div className="space-y-8 pb-10">

        {/* ── Fear & Greed Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <DataCard featured>
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Gauge size={18} style={{ color: C.gold }} />
                  <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.gold }}>恐惧贪婪指数</span>
                </div>
                <div className="flex items-baseline gap-3 mb-2">
                  <motion.span
                    className="text-[48px] font-bold font-mono leading-none"
                    style={{ color: fgColor }}
                    initial={{ scale: 0.5 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                  >
                    {fgScore}
                  </motion.span>
                  <VerdictBadge verdict={fgLabel} size="lg" />
                </div>
                <div className="flex gap-4 flex-wrap">
                  {sentiment?.dimensions?.map((dim, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: dim.score > 60 ? C.bullish : dim.score > 40 ? C.neutral : C.bearish }} />
                      <span className="text-[11px]" style={{ color: C.textSecondary }}>{dim.name}: </span>
                      <span className="text-[11px] font-mono font-medium" style={{ color: C.textPrimary }}>{dim.score}</span>
                    </div>
                  )) || (
                    <span className="text-xs" style={{ color: C.textTertiary }}>情绪维度数据加载中...</span>
                  )}
                </div>
              </div>
              <SentimentGauge score={fgScore} size={200} delay={0.3} />
            </div>

            {/* Score Scale Reference */}
            <div className="mt-4 flex items-center gap-1">
              {[
                { label: '0-20', text: '极度恐惧', color: C.bearish },
                { label: '20-40', text: '恐惧', color: '#F87171' },
                { label: '40-60', text: '中性', color: C.neutral },
                { label: '60-80', text: '贪婪', color: '#34D399' },
                { label: '80-100', text: '极度贪婪', color: C.bullish },
              ].map((item, i) => (
                <div key={i} className="flex-1 text-center py-1.5 rounded-md" style={{ background: `${item.color}15` }}>
                  <span className="text-[9px] block" style={{ color: item.color }}>{item.label}</span>
                  <span className="text-[9px] block" style={{ color: C.textTertiary }}>{item.text}</span>
                </div>
              ))}
            </div>
          </DataCard>
        </motion.div>

        {/* ── 8 Macro Indicator Cards ── */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 size={16} style={{ color: C.gold }} />
            <h2 className="text-lg font-semibold" style={{ color: C.textPrimary }}>8大宏观指标</h2>
            <span className="text-[10px] ml-2" style={{ color: C.textTertiary }}>实时追踪 + 历史趋势</span>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {INDICATOR_CONFIG.map(({ key, en, cn, desc, color }, idx) => {
              const ind = (macro as any)[key] as IndicatorData | undefined;
              if (!ind) return null;
              const prevValue = ind.history && ind.history.length >= 2
                ? ind.history[ind.history.length - 2].value
                : ind.current;
              const isUp = ind.current > prevValue;
              const pct = calcPercentile(ind.history);
              const sparkColor = isUp ? C.bullish : C.bearish;

              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.06, duration: 0.4 }}
                >
                  <DataCard>
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>{en}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${color}15`, color }}>{cn}</span>
                        </div>
                        <p className="text-[10px] mt-0.5" style={{ color: C.textTertiary }}>{desc}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1 justify-end">
                          <span className="text-2xl font-bold font-mono" style={{ color: C.textPrimary }}>
                            {key === 'copperOilRatio' ? ind.current.toFixed(4) : ind.current}
                          </span>
                          {trendArrow(ind.current, prevValue)}
                        </div>
                        <div className="flex items-center gap-2 justify-end mt-1">
                          <span className={`text-[10px] ${isUp ? 'text-bullish' : 'text-bearish'}`}>
                            {isUp ? '+' : ''}{ind.change} ({ind.changePercent}%)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Sparkline */}
                    <Sparkline data={ind.history} color={sparkColor} height={80} />

                    {/* Footer Info */}
                    <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: `1px solid ${C.borderSubtle}` }}>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: signalColor(ind.signalColor) + '20', color: signalColor(ind.signalColor) }}>
                          {ind.signal}
                        </span>
                        <span className="text-[10px]" style={{ color: C.textTertiary }}>
                          {ind.history?.length > 0 && `${ind.history.length}周`}{pct}百分位
                        </span>
                      </div>
                      {ind.note && (
                        <span className="text-[9px] max-w-[200px] truncate" style={{ color: C.textTertiary }}>{ind.note}</span>
                      )}
                    </div>
                  </DataCard>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* ── Emotion Matrix + Yield Curve ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DataCard title="情绪矩阵" subtitle="6维度热力分析">
            <EmotionMatrix matrix={emotionMatrix} />
          </DataCard>

          <DataCard title="收益率曲线" subtitle="期限结构分析">
            <YieldCurveChart data={macro.yieldCurve} />
          </DataCard>
        </div>

        {/* ── Timing Signals Table ── */}
        <DataCard title="时机信号" subtitle="技术驱动交易机会" signal="bullish">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr style={{ background: C.bgElevated }}>
                  {['标的', '方向', '入场价', '目标价', '止损', '盈亏比', '置信度', '技术摘要'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-[10px] font-medium uppercase tracking-wider" style={{ color: C.textTertiary }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(macro.timingSignals || []).map((s, i) => {
                  const techTags = extractTechTags(s.technicalSummary);
                  return (
                    <motion.tr
                      key={i}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05, duration: 0.3 }}
                      className="hover:bg-[#232837] transition-colors"
                      style={{ background: i % 2 === 0 ? C.bgCard : 'rgba(35,40,55,0.5)', borderLeft: `3px solid ${signalColor(s.signal)}` }}
                    >
                      <td className="px-3 py-3">
                        <span className="text-sm font-semibold block" style={{ color: C.textPrimary, fontFamily: 'monospace' }}>{s.asset}</span>
                        <span className="text-[10px]" style={{ color: C.textTertiary }}>{s.name}</span>
                      </td>
                      <td className="px-3 py-3">
                        <VerdictBadge verdict={s.signal.toUpperCase()} size="sm" />
                      </td>
                      <td className="px-3 py-3 text-xs font-mono" style={{ color: C.textPrimary }}>{s.entry}</td>
                      <td className="px-3 py-3 text-xs font-mono" style={{ color: C.bullish }}>{s.target}</td>
                      <td className="px-3 py-3 text-xs font-mono" style={{ color: C.bearish }}>{s.stopLoss}</td>
                      <td className="px-3 py-3 text-xs font-medium font-mono" style={{ color: C.info }}>{s.rr}</td>
                      <td className="px-3 py-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold" style={{
                          background: s.confidence > 75 ? `${C.bullish}20` : s.confidence >= 50 ? `${C.neutral}20` : `${C.bearish}20`,
                          color: s.confidence > 75 ? C.bullish : s.confidence >= 50 ? C.neutral : C.bearish,
                        }}>
                          {s.confidence}%
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex flex-wrap gap-1">
                          {techTags.map((tag, ti) => (
                            <span key={ti} className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: `${C.info}15`, color: C.info }}>
                              {tag}
                            </span>
                          ))}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </DataCard>

        {/* ── Macro Calendar ── */}
        <DataCard title="宏观日历" subtitle="未来30天关键事件">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr style={{ background: C.bgElevated }}>
                  {['日期', '事件', '市场预期', '前值', '重要性'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-[10px] font-medium uppercase tracking-wider" style={{ color: C.textTertiary }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {MACRO_CALENDAR.map((evt, i) => (
                  <motion.tr
                    key={i}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.03, duration: 0.3 }}
                    className="hover:bg-[#232837] transition-colors"
                    style={{ background: i % 2 === 0 ? C.bgCard : 'rgba(35,40,55,0.5)' }}
                  >
                    <td className="px-3 py-2.5 text-xs font-mono" style={{ color: C.textSecondary }}>{evt.date}</td>
                    <td className="px-3 py-2.5 text-xs font-medium" style={{ color: C.textPrimary }}>{evt.event}</td>
                    <td className="px-3 py-2.5 text-xs font-mono" style={{ color: C.bullish }}>{evt.expectation}</td>
                    <td className="px-3 py-2.5 text-xs font-mono" style={{ color: C.textTertiary }}>{evt.previous}</td>
                    <td className="px-3 py-2.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase" style={{
                        background: evt.importance === 'high' ? `${C.bearish}20` : evt.importance === 'medium' ? `${C.neutral}20` : `${C.textTertiary}20`,
                        color: evt.importance === 'high' ? C.bearish : evt.importance === 'medium' ? C.neutral : C.textTertiary,
                      }}>
                        {evt.importance === 'high' ? '高' : evt.importance === 'medium' ? '中' : '低'}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </DataCard>

        {/* ── Footer ── */}
        <div className="text-center py-4">
          <p className="text-[10px]" style={{ color: C.textTertiary }}>
            <Clock size={10} className="inline mr-1" />
            数据最后更新: {macro.timingSignals?.[0]?.updated || 'N/A'} | 数据来源: 综合市场数据
          </p>
        </div>
      </div>
    </>
   );
}
