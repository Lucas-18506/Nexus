import { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router';
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  Radar, ResponsiveContainer, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip as ReTooltip, Legend, Line, ComposedChart,
  Area, AreaChart, PieChart, Pie, Cell, ReferenceLine
} from 'recharts';
import {
  Shield, TrendingUp, TrendingDown, AlertTriangle, Activity,
  Scale, Target, DollarSign, BarChart3, Zap,
  Landmark, Banknote, ArrowLeft
} from 'lucide-react';
import AnalystConsensus from '@/components/AnalystConsensus';
import InstitutionalHoldings from '@/components/InstitutionalHoldings';
import PriceChart from '@/components/PriceChart';
import AIAnalysisPanel from '@/components/AIAnalysisPanel';
import ExportButton from '@/components/ExportButton';
import type { Candle } from '@/utils/technicalIndicators';

/* ───────────────────── types ───────────────────── */

interface Identity {
  ticker: string;
  name: string;
  sector: string;
  subSector: string;
  tags: string[];
  price: number;
  change: number;
  changePercent: number;
  marketCap: number;
  signal: string;
  industrySlug: string;
  industryName: string;
}

interface MoatDim { name: string; score: number; }
interface MoatData {
  overall: number;
  descriptor: string;
  dimensions: MoatDim[];
  industryAverage: number[];
}

interface KeyMetric { label: string; value: string; context: string; signal: string; }

interface FinMetric { label: string; value: string; growth: string; }
interface Quarter { q: string; revenue: number; netIncome: number; eps: number; }
interface BalanceItem { name: string; value: number; percent: number; }
interface CFQuarter { q: string; operating: number; capex: number; fcf: number; }

interface Financials {
  income: { metrics: FinMetric[]; quarters: Quarter[] };
  balance: { metrics: FinMetric[]; composition: BalanceItem[] };
  cashflow: { metrics: FinMetric[]; quarters: CFQuarter[] };
}

interface ValRow { metric: string; company: number; sectorAvg: number; market: number; assessment: string; }

interface RiskItem {
  category: string;
  name: string;
  severity: number;
  probability: string;
  description: string;
  mitigation: string;
}

interface PricePoint {
  day: number; open: number; high: number; low: number; close: number;
  volume: number; ma20: number; ma50: number; ma200: number;
}

interface TechSignals {
  priceHistory: PricePoint[];
  signals: { trend: string; maPosition: string; rsi: number; macd: string; support: number; resistance: number; volumeTrend: string; };
  verdict: string;
}

interface Verdict {
  signal: string; confidence: number; rationale: string[];
  priceTarget: number; upside: number; action: string;
  allocation: string; entryZone: string; stopLoss: number; timeHorizon: string;
}

interface CompanyData {
  identity: Identity;
  moatScore: MoatData;
  keyMetrics: KeyMetric[];
  financials: Financials;
  valuation: ValRow[];
  riskFactors: { overall: string; overallScore: number; risks: RiskItem[] };
  technicalSignals: TechSignals;
  verdict: Verdict;
}

/* ───────────────────── helpers ───────────────────── */

const signalColor = (s: string) => {
  const sig = s?.toUpperCase() ?? 'NEUTRAL';
  if (sig === 'BULLISH') return { text: '#10B981', bg: 'rgba(16,185,129,0.12)', border: '#10B981' };
  if (sig === 'BEARISH') return { text: '#EF4444', bg: 'rgba(239,68,68,0.12)', border: '#EF4444' };
  return { text: '#F59E0B', bg: 'rgba(245,158,11,0.12)', border: '#F59E0B' };
};

const assessmentColor = (a: string) => {
  if (a === 'Undervalued' || a === 'Attractive' || a === 'Low') return { text: '#10B981', bg: 'rgba(16,185,129,0.12)' };
  if (a === 'Overvalued' || a === 'High') return { text: '#EF4444', bg: 'rgba(239,68,68,0.12)' };
  return { text: '#F59E0B', bg: 'rgba(245,158,11,0.12)' };
};

const assessmentLabel = (a: string) => {
  const map: Record<string, string> = {
    'Undervalued': '低估', 'Attractive': '有吸引力', 'Overvalued': '高估',
    'Fair': '合理', 'Expensive': '昂贵', 'Low': '低', 'High': '高',
  };
  return map[a] || a;
};

const DONUT_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

const tabBtnStyle = (active: boolean) => ({
  padding: '8px 16px',
  borderRadius: '8px',
  fontSize: '12px',
  fontWeight: 600,
  textTransform: 'uppercase' as const,
  letterSpacing: '0.04em',
  background: active ? '#1C1F2B' : 'transparent',
  color: active ? '#F0F2F8' : '#5C6375',
  borderBottom: active ? '2px solid #D4AF37' : '2px solid transparent',
  transition: 'all 0.2s',
});

/* ───────────────────── component ───────────────────── */

export default function Company() {
  const { ticker } = useParams<{ ticker: string }>();
  const [data, setData] = useState<CompanyData | null>(null);
  const [loading, setLoading] = useState(true);
  const [finTab, setFinTab] = useState<'income' | 'balance' | 'cashflow'>('income');

  useEffect(() => {
    const targetTicker = ticker || 'NVDA';
    setLoading(true);
    const filename = targetTicker.replace('.', '_');
    fetch(`/data/company_${filename}.json`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => { setData(null); setLoading(false); });
  }, [ticker]);

  /* radar data */
  const radarData = useMemo(() => {
    if (!data) return [];
    return data.moatScore.dimensions.map((d, i) => ({
      subject: d.name,
      company: d.score,
      industry: data.moatScore.industryAverage[i] ?? 50,
    }));
  }, [data]);

  /* candlestick-like data for technical */
  // Convert priceHistory to Candle[] for Lightweight Charts
  const chartCandles: Candle[] = useMemo(() => {
    if (!data) return [];
    return data.technicalSignals.priceHistory.map((p, i) => ({
      timestamp: Date.now() - (60 - i) * 86400000, // mock timestamps
      open: p.open,
      high: p.high,
      low: p.low,
      close: p.close,
      volume: p.volume || 0,
    }));
  }, [data]);

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-[#8A93A8] text-sm font-mono">加载公司数据...</div>
      </div>
    );
  }

  const id = data.identity;
  const sigColors = signalColor(id.signal);
  const isPositive = id.change >= 0;

  return (
    <div className="space-y-8 pb-12 bg-[#0B0D10] text-[#F0F2F8] min-h-[100dvh] p-6">
      {/* ── Breadcrumb ── */}
      <nav className="flex items-center gap-2 text-[13px] text-[#5C6375] pb-2">
        <Link to="/" className="text-[#D4AF37] hover:underline">仪表盘</Link>
        <span>/</span>
        <span>行业</span>
        <span>/</span>
        <Link to={`/industry/${id.industrySlug}`} className="text-[#D4AF37] hover:underline">{id.industryName}</Link>
        <span>/</span>
        <span className="text-[#F0F2F8] font-semibold">{id.ticker}</span>
      </nav>

      {/* ── Company Header ── */}
      <section
        className="relative rounded-xl p-6 md:p-10 overflow-hidden"
        style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.06) 0%, transparent 60%)', backgroundColor: '#14171F', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-[36px] font-bold text-[#D4AF37] font-mono tracking-[-0.02em]">{id.ticker}</h1>
            <p className="text-[24px] font-bold text-[#F0F2F8]">{id.name}</p>
            <div className="flex flex-wrap gap-2 pt-1">
              {id.tags.map(tag => (
                <span key={tag} className="px-2.5 py-1 rounded-full text-[10px] font-medium uppercase tracking-wider text-[#5C6375]" style={{ background: '#232837' }}>
                  {tag}
                </span>
              ))}
            </div>
          </div>
          <div className="flex flex-col items-start md:items-end gap-2">
            <p className="text-[36px] font-bold text-[#F0F2F8] font-mono tracking-[-0.02em]">
              {id.ticker.includes('HK') ? `HK$${id.price.toFixed(2)}` : `$${id.price.toFixed(2)}`}
            </p>
            <span
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[13px] font-semibold"
              style={{
                background: isPositive ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)',
                color: isPositive ? '#10B981' : '#EF4444',
              }}
            >
              {isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
              {isPositive ? '+' : ''}{id.change.toFixed(2)} ({isPositive ? '+' : ''}{id.changePercent.toFixed(2)}%)
            </span>
            <p className="text-[14px] text-[#8A93A8]">
              Mkt Cap: {id.marketCap >= 1000 ? `$${(id.marketCap / 1000).toFixed(2)}T` : `$${id.marketCap}B`}
            </p>
            <span
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-[13px] font-semibold uppercase mt-1"
              style={{ background: sigColors.bg, color: sigColors.text, border: `1px solid ${sigColors.border}` }}
            >
              {id.signal}
            </span>
          </div>
        </div>
      </section>

      {/* ── AI智能分析 ── */}
      <AIAnalysisPanel ticker={ticker || 'NVDA'} data={data as unknown as Record<string, unknown>} />

      {/* ── 导出按钮 ── */}
      <div className="flex justify-end mb-4">
        <ExportButton data={data} filename={`company_${ticker || 'NVDA'}`} />
      </div>

      {/* ── Moat Radar + Key Stats ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Moat Radar */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield size={18} className="text-[#D4AF37]" />
              <h2 className="text-[18px] font-semibold text-[#F0F2F8]">护城河分析</h2>
            </div>
            <div className="text-right">
              <p className="text-[28px] font-bold font-mono" style={{ color: data.moatScore.overall > 70 ? '#10B981' : data.moatScore.overall > 40 ? '#F59E0B' : '#EF4444' }}>
                {data.moatScore.overall}
              </p>
              <p className="text-[11px] uppercase tracking-[0.06em] font-medium" style={{ color: data.moatScore.overall > 70 ? '#10B981' : data.moatScore.overall > 40 ? '#F59E0B' : '#EF4444' }}>
                {data.moatScore.descriptor}
              </p>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer>
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                <PolarGrid stroke="rgba(255,255,255,0.08)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#5C6375', fontSize: 10 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#5C6375', fontSize: 9 }} />
                <Radar name="行业均值" dataKey="industry" stroke="#5C6375" strokeWidth={1} strokeDasharray="4 4" fill="transparent" />
                <Radar name="本公司" dataKey="company" stroke="#D4AF37" strokeWidth={2} fill="rgba(212,175,55,0.2)" />
                <Legend wrapperStyle={{ fontSize: '11px', color: '#8A93A8' }} />
                <ReTooltip
                  contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                  itemStyle={{ color: '#F0F2F8', fontSize: 12 }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Key Stats Grid */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4">核心指标</h2>
          <div className="grid grid-cols-2 gap-3">
            {data.keyMetrics.map(m => {
              const mc = signalColor(m.signal);
              return (
                <div
                  key={m.label}
                  className="rounded-lg p-3"
                  style={{ background: '#1C1F2B', borderLeft: `2px solid ${mc.border}` }}
                >
                  <p className="text-[10px] font-medium uppercase tracking-[0.06em] text-[#5C6375] mb-1">{m.label}</p>
                  <p className="text-[14px] font-bold text-[#F0F2F8] font-mono">{m.value}</p>
                  <p className="text-[10px] text-[#5C6375] mt-0.5">{m.context}</p>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* ── Financial Health Tabs ── */}
      <section
        className="rounded-xl p-5 md:p-6"
        style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <h2 className="text-[18px] font-semibold text-[#F0F2F8] mb-4">财务健康度</h2>
        {/* Tabs */}
        <div className="flex gap-1 mb-5 border-b border-[rgba(255,255,255,0.06)] pb-1">
          {([
            { key: 'income' as const, label: '利润表', icon: DollarSign },
            { key: 'balance' as const, label: '资产负债表', icon: Landmark },
            { key: 'cashflow' as const, label: '现金流量表', icon: Banknote },
          ]).map(t => (
            <button key={t.key} onClick={() => setFinTab(t.key)} style={tabBtnStyle(finTab === t.key)} className="flex items-center gap-1.5">
              <t.icon size={12} /> {t.label}
            </button>
          ))}
        </div>

        {/* Income Statement */}
        {finTab === 'income' && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {data.financials.income.metrics.map(m => (
                <div key={m.label} className="rounded-lg p-3" style={{ background: '#1C1F2B' }}>
                  <p className="text-[10px] uppercase tracking-[0.06em] text-[#5C6375] mb-1">{m.label}</p>
                  <p className="text-[16px] font-bold text-[#F0F2F8] font-mono">{m.value}</p>
                  <p className="text-[10px] mt-0.5" style={{ color: m.growth.startsWith('+') || m.growth.includes('bps') ? '#10B981' : m.growth.startsWith('-') ? '#EF4444' : '#8A93A8' }}>
                    {m.growth}
                  </p>
                </div>
              ))}
            </div>
            <div className="h-[240px]">
              <ResponsiveContainer>
                <ComposedChart data={data.financials.income.quarters}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="q" tick={{ fill: '#5C6375', fontSize: 10 }} />
                  <YAxis yAxisId="left" tick={{ fill: '#5C6375', fontSize: 10 }} label={{ value: '十亿美元', angle: -90, position: 'insideLeft', fill: '#5C6375', fontSize: 10 }} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fill: '#5C6375', fontSize: 10 }} label={{ value: '每股收益', angle: 90, position: 'insideRight', fill: '#5C6375', fontSize: 10 }} />
                  <ReTooltip contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} itemStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar yAxisId="left" dataKey="revenue" name="营收" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  <Line yAxisId="right" type="monotone" dataKey="eps" name="每股收益" stroke="#D4AF37" strokeWidth={2} dot={{ fill: '#D4AF37', r: 3 }} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Balance Sheet */}
        {finTab === 'balance' && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {data.financials.balance.metrics.map(m => (
                <div key={m.label} className="rounded-lg p-3" style={{ background: '#1C1F2B' }}>
                  <p className="text-[10px] uppercase tracking-[0.06em] text-[#5C6375] mb-1">{m.label}</p>
                  <p className="text-[16px] font-bold text-[#F0F2F8] font-mono">{m.value}</p>
                  <p className="text-[10px] text-[#8A93A8] mt-0.5">{m.growth}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-6 h-[200px]">
              <div className="w-[180px] h-[180px]">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={data.financials.balance.composition} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                      {data.financials.balance.composition.map((_e, i) => (
                        <Cell key={`cell-${i}`} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                      ))}
                    </Pie>
                    <ReTooltip contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2">
                {data.financials.balance.composition.map((item, i) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm" style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} />
                    <span className="text-[12px] text-[#8A93A8] flex-1">{item.name}</span>
                    <span className="text-[12px] font-mono text-[#F0F2F8]">{item.percent}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Cash Flow */}
        {finTab === 'cashflow' && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {data.financials.cashflow.metrics.map(m => (
                <div key={m.label} className="rounded-lg p-3" style={{ background: '#1C1F2B' }}>
                  <p className="text-[10px] uppercase tracking-[0.06em] text-[#5C6375] mb-1">{m.label}</p>
                  <p className="text-[16px] font-bold text-[#F0F2F8] font-mono">{m.value}</p>
                  <p className="text-[10px] text-[#8A93A8] mt-0.5">{m.growth}</p>
                </div>
              ))}
            </div>
            <div className="h-[240px]">
              <ResponsiveContainer>
                <ComposedChart data={data.financials.cashflow.quarters}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="q" tick={{ fill: '#5C6375', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#5C6375', fontSize: 10 }} />
                  <ReTooltip contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} itemStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" strokeDasharray="3 3" />
                  <Bar dataKey="operating" name="经营现金流" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="capex" name="资本开支" fill="#EF4444" radius={[4, 4, 0, 0]} />
                  <Line type="monotone" dataKey="fcf" name="自由现金流" stroke="#3B82F6" strokeWidth={2} dot={{ fill: '#3B82F6', r: 3 }} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </section>

      {/* ── Revenue & Earnings + Valuation ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue & Earnings Trend */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={18} className="text-[#D4AF37]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">营收与盈利趋势</h2>
          </div>
          <div className="h-[260px]">
            <ResponsiveContainer>
              <AreaChart data={data.financials.income.quarters}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="q" tick={{ fill: '#5C6375', fontSize: 10 }} />
                <YAxis yAxisId="left" tick={{ fill: '#5C6375', fontSize: 10 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill: '#5C6375', fontSize: 10 }} />
                <ReTooltip contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} itemStyle={{ fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Area yAxisId="left" type="monotone" dataKey="revenue" name="营收" stroke="#3B82F6" fill="url(#revGrad)" strokeWidth={2} />
                <Line yAxisId="right" type="monotone" dataKey="eps" name="每股收益" stroke="#D4AF37" strokeWidth={2} dot={{ fill: '#D4AF37', r: 3 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Valuation */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Scale size={18} className="text-[#D4AF37]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">估值分析</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr style={{ background: '#1C1F2B' }}>
                  {['指标', '本公司', '行业均值', '市场', '评估'].map(h => (
                    <th key={h} className="px-3 py-2 text-[11px] font-medium uppercase tracking-[0.06em] text-[#5C6375]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.valuation.map(v => {
                  const ac = assessmentColor(v.assessment);
                  return (
                    <tr key={v.metric} className="hover:bg-[#232837] transition-colors" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td className="px-3 py-2.5 text-[12px] font-medium text-[#F0F2F8]">{v.metric}</td>
                      <td className="px-3 py-2.5 text-[12px] font-mono text-[#F0F2F8]">{typeof v.company === 'number' ? v.company.toFixed(1) : v.company}</td>
                      <td className="px-3 py-2.5 text-[12px] font-mono text-[#8A93A8]">{v.sectorAvg.toFixed(1)}</td>
                      <td className="px-3 py-2.5 text-[12px] font-mono text-[#8A93A8]">{v.market.toFixed(1)}</td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: ac.bg, color: ac.text }}>
                          {assessmentLabel(v.assessment)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {/* Valuation gauge */}
          <div className="mt-5 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <div className="relative h-4 rounded-full overflow-hidden" style={{ background: 'linear-gradient(90deg, #10B981 0%, #F59E0B 50%, #EF4444 100%)' }}>
              {/* Position indicator */}
              {(() => {
                const pe = data.valuation.find(v => v.metric === 'P/E');
                const pos = pe ? Math.min(100, Math.max(0, (pe.company / (pe.market * 2.5)) * 100)) : 50;
                return (
                  <div
                    className="absolute top-0 w-0 h-0 -translate-x-1/2"
                    style={{
                      left: `${pos}%`,
                      borderLeft: '6px solid transparent',
                      borderRight: '6px solid transparent',
                      borderTop: '8px solid #D4AF37',
                      marginTop: '-1px',
                    }}
                  />
                );
              })()}
            </div>
            <div className="flex justify-between mt-1">
              <span className="text-[10px] text-[#10B981]">便宜</span>
              <span className="text-[10px] text-[#F59E0B]">合理</span>
              <span className="text-[10px] text-[#EF4444]">昂贵</span>
            </div>
          </div>
        </section>
      </div>

      {/* ── Risk Factors ── */}
      <section
        className="rounded-xl p-5 md:p-6"
        style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <AlertTriangle size={18} className="text-[#D4AF37]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">风险因素</h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative w-[80px] h-[40px]">
              <svg viewBox="0 0 80 40" className="w-full h-full">
                <path d="M 5 35 A 35 35 0 0 1 75 35" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
                <path
                  d="M 5 35 A 35 35 0 0 1 75 35"
                  fill="none"
                  stroke={data.riskFactors.overallScore > 60 ? '#EF4444' : data.riskFactors.overallScore > 35 ? '#F59E0B' : '#10B981'}
                  strokeWidth="6"
                  strokeDasharray={`${data.riskFactors.overallScore * 1.1} 110`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 text-[11px] font-bold text-[#F0F2F8]">{data.riskFactors.overallScore}</div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.06em] text-[#5C6375]">综合风险</p>
              <p className="text-[14px] font-medium" style={{
                color: data.riskFactors.overallScore > 60 ? '#EF4444' : data.riskFactors.overallScore > 35 ? '#F59E0B' : '#10B981'
              }}>
                {data.riskFactors.overall}
              </p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.riskFactors.risks.map(r => (
            <div
              key={r.name}
              className="rounded-lg p-4 transition-all duration-200 hover:-translate-y-0.5"
              style={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <p className="text-[10px] uppercase tracking-[0.06em] text-[#5C6375] mb-1">{r.category}</p>
              <p className="text-[14px] font-semibold text-[#F0F2F8] mb-2">{r.name}</p>
              <div className="flex items-center gap-2 mb-2">
                <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${r.severity}%`,
                      background: r.severity > 70 ? '#EF4444' : r.severity > 40 ? '#F59E0B' : '#10B981'
                    }}
                  />
                </div>
                <span className="text-[10px] text-[#5C6375]">{r.severity}%</span>
              </div>
              <p className="text-[10px] uppercase tracking-wider mb-2"
                style={{ color: r.probability === 'HIGH' ? '#EF4444' : r.probability === 'MEDIUM' ? '#F59E0B' : '#10B981' }}
              >
                可能性: {r.probability}
              </p>
              <p className="text-[12px] text-[#8A93A8] leading-relaxed mb-2">{r.description}</p>
              <p className="text-[11px] text-[#5C6375]">应对措施: {r.mitigation}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Technical Analysis ── */}
      <section
        className="rounded-xl p-5 md:p-6"
        style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex items-center gap-2 mb-4">
          <Activity size={18} className="text-[#D4AF37]" />
          <h2 className="text-[18px] font-semibold text-[#F0F2F8]">技术分析</h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Chart - Lightweight Charts Professional K-Line */}
          <div className="lg:col-span-3">
            <PriceChart candles={chartCandles} height={380} />
            {/* Legend */}
            <div className="flex items-center gap-4 mt-2 px-1">
              <span className="flex items-center gap-1 text-[10px] text-[#5C6375]"><span className="w-3 h-[2px] bg-[#2962FF]" />MA5</span>
              <span className="flex items-center gap-1 text-[10px] text-[#5C6375]"><span className="w-3 h-[2px] bg-[#FF6D00]" />MA10</span>
              <span className="flex items-center gap-1 text-[10px] text-[#5C6375]"><span className="w-3 h-[2px] bg-[#00C853]" />MA20</span>
              <span className="flex items-center gap-1 text-[10px] text-[#5C6375]"><span className="w-3 h-[2px] bg-[#D500F9]" />MA60</span>
              <span className="flex items-center gap-1 text-[10px] text-[#5C6375]"><span className="w-3 h-[2px] bg-[rgba(255,255,255,0.2)]" />布林带</span>
            </div>
          </div>

          {/* Signal Panel */}
          <div className="lg:col-span-2 space-y-3">
            {([
              { label: '趋势', value: data.technicalSignals.signals.trend, icon: TrendingUp },
              { label: '均线位置', value: data.technicalSignals.signals.maPosition, icon: Activity },
              { label: 'RSI (14)', value: String(data.technicalSignals.signals.rsi), icon: BarChart3 },
              { label: 'MACD', value: data.technicalSignals.signals.macd, icon: Zap },
              { label: '支撑位', value: `$${data.technicalSignals.signals.support.toFixed(2)}`, icon: ArrowLeft },
              { label: '阻力位', value: `$${data.technicalSignals.signals.resistance.toFixed(2)}`, icon: Target },
              { label: '成交量', value: data.technicalSignals.signals.volumeTrend, icon: Activity },
            ]).map(item => {
              const Icon = item.icon;
              const isBullish = item.value.toLowerCase().includes('bull') || item.value.toLowerCase().includes('uptrend') || item.value.toLowerCase().includes('above');
              const isBearish = item.value.toLowerCase().includes('bear') || item.value.toLowerCase().includes('downtrend') || item.value.toLowerCase().includes('below');
              return (
                <div
                  key={item.label}
                  className="flex items-center gap-3 p-2.5 rounded-lg"
                  style={{ background: '#1C1F2B' }}
                >
                  <Icon size={14} className="text-[#5C6375] flex-shrink-0" />
                  <span className="text-[11px] uppercase tracking-[0.06em] text-[#5C6375] w-20 flex-shrink-0">{item.label}</span>
                  <span className="text-[13px] font-medium"
                    style={{ color: isBullish ? '#10B981' : isBearish ? '#EF4444' : '#F0F2F8' }}
                  >
                    {item.value}
                  </span>
                </div>
              );
            })}
            {/* RSI mini bar */}
            <div className="p-2.5 rounded-lg" style={{ background: '#1C1F2B' }}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] uppercase tracking-[0.06em] text-[#5C6375]">RSI区间</span>
                <span className="text-[11px] font-mono text-[#F0F2F8]">{data.technicalSignals.signals.rsi}</span>
              </div>
              <div className="h-2 rounded-full overflow-hidden flex">
                <div className="flex-1 h-full" style={{ background: '#10B981' }} /> {/* 0-30 */}
                <div className="flex-1 h-full" style={{ background: '#F59E0B' }} /> {/* 30-70 */}
                <div className="flex-1 h-full" style={{ background: '#EF4444' }} /> {/* 70-100 */}
              </div>
              <div className="relative h-2 mt-0.5">
                <div
                  className="absolute w-0 h-0 -translate-x-1/2"
                  style={{
                    left: `${data.technicalSignals.signals.rsi}%`,
                    borderLeft: '4px solid transparent',
                    borderRight: '4px solid transparent',
                    borderTop: '5px solid #D4AF37',
                  }}
                />
              </div>
            </div>
            {/* Verdict */}
            <div className="pt-2">
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[13px] font-semibold uppercase"
                style={{ background: signalColor(data.technicalSignals.verdict).bg, color: signalColor(data.technicalSignals.verdict).text, border: `1px solid ${signalColor(data.technicalSignals.verdict).border}` }}
              >
                综合: {data.technicalSignals.verdict}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ── Analyst Verdict ── */}
      <section
        className="relative rounded-xl p-6 md:p-8 overflow-hidden"
        style={{
          background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
          borderLeft: '3px solid rgba(212,175,55,0.25)',
          boxShadow: '0 0 20px rgba(212,175,55,0.15)',
        }}
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Verdict */}
          <div className="space-y-4">
            <p className="text-[11px] uppercase tracking-[0.06em] text-[#D4AF37] font-medium">IWM分析裁决</p>
            <span
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-[16px] font-bold uppercase"
              style={{ background: sigColors.bg, color: sigColors.text, border: `1px solid ${sigColors.border}` }}
            >
              {data.verdict.signal}
            </span>
            <p className="text-[14px] text-[#8A93A8]">置信度: <span className="text-[#F0F2F8] font-medium">{data.verdict.confidence}%</span></p>
            <ul className="space-y-2">
              {data.verdict.rationale.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-[13px] text-[#8A93A8] leading-relaxed">
                  <span className="text-[#D4AF37] mt-0.5">&#9679;</span>
                  {r}
                </li>
              ))}
            </ul>
            <p className="text-[14px]">
              <span className="text-[#8A93A8]">目标价: </span>
              <span className="text-[#10B981] font-bold font-mono">${data.verdict.priceTarget.toFixed(2)}</span>
              <span className="text-[11px] text-[#10B981] ml-2">(+{data.verdict.upside}%)</span>
            </p>
          </div>

          {/* Right: Action */}
          <div className="space-y-4">
            <p className="text-[11px] uppercase tracking-[0.06em] text-[#D4AF37] font-medium">建议操作</p>
            <p className="text-[24px] font-bold text-[#F0F2F8]">{data.verdict.action}</p>
            <div className="space-y-2 pt-2">
              <div className="flex justify-between py-1.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <span className="text-[12px] text-[#8A93A8]">建议配置</span>
                <span className="text-[12px] text-[#F0F2F8] font-medium">{data.verdict.allocation}</span>
              </div>
              <div className="flex justify-between py-1.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <span className="text-[12px] text-[#8A93A8]">理想入场区间</span>
                <span className="text-[12px] text-[#D4AF37] font-medium">{data.verdict.entryZone}</span>
              </div>
              <div className="flex justify-between py-1.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <span className="text-[12px] text-[#8A93A8]">止损</span>
                <span className="text-[12px] text-[#EF4444] font-medium">${data.verdict.stopLoss.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[12px] text-[#8A93A8]">时间跨度</span>
                <span className="text-[12px] text-[#F0F2F8] font-medium">{data.verdict.timeHorizon}</span>
              </div>
            </div>
            <p className="text-[10px] text-[#5C6375] pt-2">
              以上为分析输出，不构成投资建议。
            </p>
          </div>
        </div>
      </section>

      {/* ── P2: Analyst Consensus ── */}
      {ticker && <AnalystConsensus ticker={ticker} />}

      {/* ── P2: Institutional Holdings (13F) ── */}
      {ticker && <InstitutionalHoldings ticker={ticker} />}
    </div>
  );
}
