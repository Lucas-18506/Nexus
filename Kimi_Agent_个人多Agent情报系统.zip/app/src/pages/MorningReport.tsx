import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sunrise, FileText, Globe, TrendingUp,
  Newspaper, GitBranch, Clock, User,
  Star, CheckSquare, Square,
  AlertTriangle, Bell
} from 'lucide-react';
import {
  AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Line
} from 'recharts';
import DataCard from '@/components/DataCard';
import ProbabilityBar from '@/components/ProbabilityBar';
import SentimentGauge from '@/components/SentimentGauge';
import VerdictBadge from '@/components/VerdictBadge';

/* ───────── Types ───────── */
interface MorningReportData {
  reportDate: string;
  reportType: string;
  generatedAt: string;
  executiveSummary: {
    text: string;
    verdicts: { market: string; signal: string; label: string }[];
    timeToAct: string;
  };
  marketSnapshot: {
    asia: { title: string; indices: IndexData[]; summary: string };
    usFutures: { title: string; indices: IndexData[]; sparkline: number[] };
    europe: { title: string; indices: IndexData[]; summary: string };
  };
  newsDigest: NewsItem[];
  scenarioForecast: {
    probabilityDistribution: { bull: number; base: number; bear: number };
    scenarios: { name: string; timeframe: string; bullishSectors: string[]; bearishSectors: string[]; key: string }[];
  };
  timingSignals: TimingSignal[];
  riskAssessment: {
    overallScore: number;
    risks: Risk[];
    categoryScores: { [key: string]: number };
  };
  cioConclusion: {
    author: string;
    text: string;
    actionItems: { action: string; signal: string }[];
    positionSizing: string;
    signature: string;
  };
}

interface IndexData {
  name: string;
  value: number;
  change: number;
}

interface NewsItem {
  id: number;
  category: string;
  headline: string;
  summary: string;
  impact: string;
  impactLevel: number;
  affectedSectors: string[];
  source: string;
  time: string;
}

interface TimingSignal {
  rank: number;
  asset: string;
  signal: string;
  entry: string;
  target: string;
  stop: string;
  rr: string;
  catalyst: string;
  confidence: number;
}

interface Risk {
  name: string;
  severity: string;
  description: string;
  probability: number;
}

/* ───────── Colors ───────── */
const C = {
  bullish: '#10B981',
  bearish: '#EF4444',
  neutral: '#F59E0B',
  info: '#3B82F6',
  gold: '#D4AF37',
  textPrimary: '#F0F2F8',
  textSecondary: '#8A93A8',
  textTertiary: '#5C6375',
  bgCard: '#14171F',
  bgElevated: '#1C1F2B',
  borderSubtle: 'rgba(255,255,255,0.06)',
};

const signalColor = (s: string) => {
  const col = s?.toLowerCase();
  if (col === 'bullish' || col === 'buy' || col === 'add') return C.bullish;
  if (col === 'bearish' || col === 'sell' || col === 'trim') return C.bearish;
  return C.neutral;
};

/* ───────── Data Hook ───────── */
function useMorningData() {
  const [data, setData] = useState<MorningReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/data/morning_report.json')
      .then(r => r.json())
      .then((d: MorningReportData) => {
        setData(d);
        setLoading(false);
      })
      .catch(err => {
        setError(String(err));
        setLoading(false);
      });
  }, []);

  return { data, loading, error };
}

/* ───────── Sparkline Generator ───────── */
function generateSparkline(baseValue: number, changePercent: number, points = 10): number[] {
  // Generate a plausible intraday path ending at baseValue with given change
  const result: number[] = [];
  const endValue = baseValue;
  const startValue = endValue / (1 + changePercent / 100);
  for (let i = 0; i < points; i++) {
    const t = i / (points - 1);
    // Add some random walk noise
    const noise = (Math.sin(i * 1.5) * 0.3 + Math.cos(i * 2.3) * 0.2) * Math.abs(endValue - startValue) * 0.3;
    result.push(startValue + (endValue - startValue) * t + noise);
  }
  result[result.length - 1] = endValue;
  return result;
}

function computeMA(data: number[], period: number): (number | null)[] {
  return data.map((_, i) => {
    if (i < period - 1) return null;
    const slice = data.slice(i - period + 1, i + 1);
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  });
}

/* ───────── Index Sparkline Chart ───────── */
function IndexSparkline({ data, color, height = 50 }: { data: number[]; color: string; height?: number }) {
  const ma5 = computeMA(data, Math.min(5, data.length));
  const ma20 = computeMA(data, Math.min(10, data.length));
  const chartData = data.map((v, i) => ({ i, v, ma5: ma5[i], ma20: ma20[i] }));

  return (
    <div style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData} margin={{ top: 2, right: 2, left: 2, bottom: 2 }}>
          <defs>
            <linearGradient id={`idx-grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.25} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="i" hide />
          <YAxis hide domain={['auto', 'auto']} />
          <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} fill={`url(#idx-grad-${color.replace('#', '')})`} isAnimationActive={false} />
          <Line type="monotone" dataKey="ma5" stroke={color} strokeWidth={1} strokeDasharray="3 3" dot={false} opacity={0.6} />
          <Line type="monotone" dataKey="ma20" stroke={C.neutral} strokeWidth={1} strokeDasharray="5 2" dot={false} opacity={0.4} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ───────── Star Rating ───────── */
function StarRating({ level }: { level: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }, (_, i) => (
        <Star key={i} size={10} fill={i < level ? C.gold : 'transparent'} stroke={i < level ? C.gold : C.textTertiary} />
      ))}
    </div>
  );
}

/* ───────── Impact Level Badge ───────── */
function ImpactBadge({ level }: { level: number }) {
  const label = level >= 4 ? '高' : level >= 2 ? '中' : '低';
  const color = level >= 4 ? C.bearish : level >= 2 ? C.neutral : C.textTertiary;
  const bg = level >= 4 ? `${C.bearish}20` : level >= 2 ? `${C.neutral}20` : `${C.textTertiary}20`;
  return (
    <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold" style={{ background: bg, color }}>
      {label}
    </span>
  );
}

/* ───────── Sentiment Badge ───────── */
function SentimentBadge({ impact }: { impact: string }) {
  const label = impact === 'bullish' ? '利好' : impact === 'bearish' ? '利空' : '中性';
  const color = impact === 'bullish' ? C.bullish : impact === 'bearish' ? C.bearish : C.neutral;
  const bg = `${color}20`;
  return (
    <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold" style={{ background: bg, color }}>
      {label}
    </span>
  );
}

/* ───────── Section Divider ───────── */
function SectionDivider({ label }: { label?: string }) {
  return (
    <div className="relative my-8">
      {label && (
        <span className="absolute left-1/2 -translate-x-1/2 -top-3 px-4 text-[11px] font-medium uppercase tracking-widest" style={{ color: C.textTertiary, background: '#0B0D10' }}>
          {label}
        </span>
      )}
      <div className="h-px" style={{ background: 'linear-gradient(90deg, transparent 0%, #2A2F3D 50%, transparent 100%)' }} />
    </div>
  );
}

/* ───────── Risk Heatmap Matrix ───────── */
function RiskHeatmap({ categoryScores }: { categoryScores: { [key: string]: number } }) {
  const categories = [
    { key: 'market', label: '市场风险' },
    { key: 'credit', label: '信用风险' },
    { key: 'liquidity', label: '流动性风险' },
    { key: 'geopolitical', label: '地缘政治风险' },
    { key: 'operational', label: '操作风险' },
  ];

  const probabilityLabels = ['低概率', '中概率', '高概率'];
  const impactLabels = ['低影响', '中影响', '高影响'];

  // Compute probability × impact positions based on score
  const getHeatPosition = (score: number): { probIdx: number; impIdx: number; intensity: number } => {
    const probIdx = score > 65 ? 2 : score > 40 ? 1 : 0;
    const impIdx = score > 60 ? 2 : score > 35 ? 1 : 0;
    const intensity = score / 100;
    return { probIdx, impIdx, intensity };
  };

  return (
    <div className="space-y-4">
      {/* Risk Category Bars */}
      <div className="space-y-3">
        {categories.map((cat) => {
          const score = categoryScores[cat.key] || 50;
          const color = score > 60 ? C.bearish : score > 40 ? C.neutral : C.bullish;
          return (
            <div key={cat.key}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px]" style={{ color: C.textSecondary }}>{cat.label}</span>
                <span className="text-[11px] font-mono font-medium" style={{ color }}>{score}</span>
              </div>
              <div className="h-2 rounded-full overflow-hidden" style={{ background: C.bgElevated }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${score}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="h-full rounded-full"
                  style={{ background: color }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* 3x3 Heatmap Grid */}
      <div className="mt-4">
        <div className="grid grid-cols-4 gap-1">
          {/* Header */}
          <div className="text-[8px]" style={{ color: C.textTertiary }} />
          {impactLabels.map(l => (
            <div key={l} className="text-[8px] text-center py-1" style={{ color: C.textTertiary }}>{l}</div>
          ))}

          {/* Rows */}
          {probabilityLabels.map((probLabel, pi) => (
            <div key={probLabel} className="contents">
              <div className="text-[8px] flex items-center" style={{ color: C.textTertiary }}>{probLabel}</div>
              {[0, 1, 2].map(ii => {
                // Find which categories fall in this cell
                const cellCategories = categories.filter(cat => {
                  const pos = getHeatPosition(categoryScores[cat.key] || 50);
                  return pos.probIdx === (2 - pi) && pos.impIdx === ii;
                });
                const intensity = cellCategories.length > 0
                  ? cellCategories.reduce((sum, c) => sum + (categoryScores[c.key] || 50), 0) / cellCategories.length
                  : 0;
                const bgOpacity = intensity / 100;
                const bgColor = intensity > 60 ? `rgba(239,68,68,${bgOpacity * 0.6})` :
                  intensity > 40 ? `rgba(245,158,11,${bgOpacity * 0.6})` :
                    `rgba(16,185,129,${bgOpacity * 0.4})`;

                return (
                  <div
                    key={`${pi}-${ii}`}
                    className="h-10 rounded flex items-center justify-center"
                    style={{ background: bgColor, border: `1px solid ${C.borderSubtle}` }}
                  >
                    {cellCategories.map(c => (
                      <span key={c.key} className="text-[8px] block text-center leading-tight" style={{ color: C.textPrimary }}>
                        {c.label.replace('风险', '')}
                      </span>
                    ))}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ───────── Pre-market Checklist ───────── */
function PreMarketChecklist() {
  const [items, setItems] = useState([
    { id: 1, text: '检查NVDA止损单状态（止损110）', checked: false, priority: 'high' as const },
    { id: 2, text: '关注USD/CNY是否突破7.3关口', checked: false, priority: 'high' as const },
    { id: 3, text: '确认VIX期货走势（>18需警惕）', checked: true, priority: 'medium' as const },
    { id: 4, text: '复核今日宏观日历（FOMC/非农）', checked: false, priority: 'high' as const },
    { id: 5, text: '检查TSLA交付数据发布时间', checked: false, priority: 'medium' as const },
    { id: 6, text: '确认BABA入场单（86以下）', checked: false, priority: 'medium' as const },
  ]);

  const toggleItem = (id: number) => {
    setItems(prev => prev.map(item =>
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  return (
    <div className="space-y-2">
      {items.map(item => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, x: -4 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: item.id * 0.05 }}
          className="flex items-center gap-3 py-2 px-3 rounded-lg cursor-pointer transition-colors hover:bg-[#232837]"
          onClick={() => toggleItem(item.id)}
        >
          {item.checked
            ? <CheckSquare size={16} style={{ color: C.bullish }} />
            : <Square size={16} style={{ color: C.textTertiary }} />
          }
          <span className={`text-xs flex-1 ${item.checked ? 'line-through' : ''}`} style={{ color: item.checked ? C.textTertiary : C.textPrimary }}>
            {item.text}
          </span>
          <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold" style={{
            background: item.priority === 'high' ? `${C.bearish}20` : `${C.neutral}20`,
            color: item.priority === 'high' ? C.bearish : C.neutral,
          }}>
            {item.priority === 'high' ? '高' : '中'}
          </span>
        </motion.div>
      ))}
    </div>
  );
}

/* ───────── Key Timeline ───────── */
function KeyTimeline() {
  const events = [
    { time: '07:00', label: '欧洲市场开盘', status: 'passed' as const },
    { time: '08:30', label: '盘前简报发布', status: 'passed' as const },
    { time: '09:30', label: '美股开盘', status: 'upcoming' as const, important: true },
    { time: '10:00', label: '美联储主席讲话', status: 'upcoming' as const, important: true },
    { time: '12:00', label: '午间小结', status: 'upcoming' as const },
    { time: '14:00', label: '欧洲市场收盘', status: 'upcoming' as const },
    { time: '16:00', label: '美股收盘', status: 'upcoming' as const, important: true },
    { time: '20:30', label: '非农数据发布', status: 'upcoming' as const, important: true },
  ];

  return (
    <div className="relative pl-4">
      <div className="absolute left-1.5 top-0 bottom-0 w-px" style={{ background: C.borderSubtle }} />
      {events.map((evt, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.06, duration: 0.3 }}
          className="relative flex items-center gap-3 py-2.5"
        >
          <div
            className="absolute -left-4 w-3 h-3 rounded-full border-2"
            style={{
              background: evt.status === 'passed' ? C.textTertiary : evt.important ? C.gold : C.info,
              borderColor: evt.status === 'passed' ? C.textTertiary : evt.important ? C.gold : C.info,
            }}
          />
          <span
            className="text-[11px] font-mono w-12"
            style={{
              color: evt.status === 'passed' ? C.textTertiary : evt.important ? C.gold : C.textSecondary,
            }}
          >
            {evt.time}
          </span>
          <span
            className="text-xs"
            style={{
              color: evt.status === 'passed' ? C.textTertiary : C.textPrimary,
            }}
          >
            {evt.label}
          </span>
          {evt.important && evt.status === 'upcoming' && (
            <Bell size={10} style={{ color: C.gold }} />
          )}
        </motion.div>
      ))}
    </div>
  );
}

/* ═══════════════════════════ PAGE ═══════════════════════════ */
export default function MorningReport() {
  const { data, loading, error } = useMorningData();
  const [newsTab, setNewsTab] = useState('all');

  if (loading) {
    return (
      <>
        <div className="flex items-center justify-center min-h-[60vh]" style={{ color: C.textSecondary }}>
          <Sunrise className="animate-pulse mr-2" /> 加载早报...
        </div>
      </>
    );
  }

  if (error || !data) {
    return (
      <>
        <div className="flex items-center justify-center min-h-[60vh]" style={{ color: C.bearish }}>
          <AlertTriangle className="mr-2" /> 数据加载失败，请稍后重试
        </div>
      </>
    );
  }

  const filteredNews = newsTab === 'all'
    ? data.newsDigest
    : data.newsDigest.filter(n => n.category === newsTab);

  const categoryLabel = (c: string) =>
    c === 'macro' ? '宏观' : c === 'policy' ? '政策' : c === 'earnings' ? '业绩' : c === 'geopolitical' ? '地缘' : '板块';

  const categoryColor = (c: string) =>
    c === 'macro' ? C.info : c === 'policy' ? C.gold : c === 'earnings' ? C.bullish : c === 'geopolitical' ? C.bearish : C.neutral;

  /* 5-Scenario distribution: expand 3-scenario to 5 */
  const bullPct = data.scenarioForecast.probabilityDistribution.bull;
  const basePct = data.scenarioForecast.probabilityDistribution.base;
  const bearPct = data.scenarioForecast.probabilityDistribution.bear;
  // Split bull into strong bull (60%) and mild bull (40%), same for bear
  const strongBull = Math.round(bullPct * 0.6);
  const mildBull = bullPct - strongBull;
  const strongBear = Math.round(bearPct * 0.6);
  const mildBear = bearPct - strongBear;
  const neutralPct = basePct;

  const fiveScenarios = [
    { label: '强烈看涨', probability: strongBull, color: '#059669' },
    { label: '温和看涨', probability: mildBull, color: '#34D399' },
    { label: '中性', probability: neutralPct, color: C.info },
    { label: '温和看跌', probability: mildBear, color: '#F87171' },
    { label: '强烈看跌', probability: strongBear, color: '#DC2626' },
  ];

  return (
    <>
      <div className="space-y-6 pb-10">

        {/* ── Report Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative rounded-xl p-8 overflow-hidden"
          style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.06) 0%, transparent 60%)' }}
        >
          <div className="flex items-center gap-2 mb-3">
            <span className="px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest" style={{ background: 'rgba(212,175,55,0.12)', color: C.gold }}>
              盘前简报
            </span>
            <span className="px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest" style={{ background: `${C.bullish}20`, color: C.bullish }}>
              市场开盘
            </span>
          </div>
          <h1 className="text-4xl font-bold tracking-tight" style={{ color: C.textPrimary, fontFamily: 'monospace', letterSpacing: '-0.02em' }}>
            {data.generatedAt} 盘前简报
          </h1>
          <p className="mt-2 text-sm" style={{ color: C.textSecondary }}>
            {new Date(data.reportDate).toLocaleDateString('zh-CN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <p className="mt-1 text-sm" style={{ color: C.textTertiary }}>盘前情报与情景分析</p>
        </motion.div>

        {/* ── Executive Summary ── */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
          <DataCard signal="info">
            <div className="flex items-center gap-2 mb-3">
              <FileText size={16} style={{ color: C.gold }} />
              <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.gold }}>执行摘要</span>
            </div>
            <p className="text-base leading-relaxed mb-4 font-medium" style={{ color: C.textPrimary, lineHeight: 1.8 }}>
              {data.executiveSummary.text}
            </p>
            <div className="flex flex-wrap gap-2 mb-3">
              {data.executiveSummary.verdicts.map(v => (
                <VerdictBadge key={v.market} verdict={`${v.market}: ${v.label}`} size="md" />
              ))}
            </div>
            <p className="text-xs flex items-center gap-1" style={{ color: C.gold }}>
              <Clock size={12} /> {data.executiveSummary.timeToAct}
            </p>
          </DataCard>
        </motion.div>

        <SectionDivider label="市场快照" />

        {/* ── Market Snapshot with Sparklines ── */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Asia */}
          <DataCard>
            <div className="flex items-center gap-2 mb-3">
              <Globe size={14} style={{ color: C.textTertiary }} />
              <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.textTertiary }}>亚洲收盘</span>
            </div>
            <div className="space-y-3">
              {data.marketSnapshot.asia.indices.map(idx => {
                const sparkData = generateSparkline(idx.value, idx.change);
                const color = idx.change >= 0 ? C.bullish : C.bearish;
                return (
                  <div key={idx.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs" style={{ color: C.textSecondary }}>{idx.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium font-mono" style={{ color: C.textPrimary }}>{idx.value.toLocaleString()}</span>
                        <span className={`text-[10px] ${idx.change >= 0 ? 'text-bullish' : 'text-bearish'}`}>
                          {idx.change >= 0 ? '+' : ''}{idx.change}%
                        </span>
                      </div>
                    </div>
                    <IndexSparkline data={sparkData} color={color} height={40} />
                  </div>
                );
              })}
            </div>
            <p className="mt-3 text-[10px]" style={{ color: C.textTertiary }}>{data.marketSnapshot.asia.summary}</p>
          </DataCard>

          {/* US Futures */}
          <DataCard>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={14} style={{ color: C.textTertiary }} />
              <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.textTertiary }}>美股期货</span>
            </div>
            <div className="space-y-3">
              {data.marketSnapshot.usFutures.indices.map(idx => {
                const sparkData = idx.name.includes('VIX')
                  ? generateSparkline(idx.value, idx.change)
                  : data.marketSnapshot.usFutures.sparkline.length > 0
                    ? data.marketSnapshot.usFutures.sparkline
                    : generateSparkline(idx.value, idx.change);
                const color = idx.change >= 0
                  ? (idx.name.includes('VIX') ? C.bearish : C.bullish)
                  : (idx.name.includes('VIX') ? C.bullish : C.bearish);
                return (
                  <div key={idx.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs" style={{ color: C.textSecondary }}>{idx.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium font-mono" style={{ color: C.textPrimary }}>{idx.value.toLocaleString()}</span>
                        <span className={`text-[10px] ${idx.change >= 0 ? 'text-bullish' : 'text-bearish'}`}>
                          {idx.change >= 0 ? '+' : ''}{idx.change}%
                        </span>
                      </div>
                    </div>
                    <IndexSparkline data={sparkData} color={color} height={40} />
                  </div>
                );
              })}
            </div>
          </DataCard>

          {/* Europe */}
          <DataCard>
            <div className="flex items-center gap-2 mb-3">
              <Globe size={14} style={{ color: C.textTertiary }} />
              <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.textTertiary }}>欧洲盘前</span>
            </div>
            <div className="space-y-3">
              {data.marketSnapshot.europe.indices.map(idx => {
                const sparkData = generateSparkline(idx.value, idx.change);
                const color = idx.change >= 0 ? C.bullish : C.bearish;
                return (
                  <div key={idx.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs" style={{ color: C.textSecondary }}>{idx.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium font-mono" style={{ color: C.textPrimary }}>{idx.value.toLocaleString()}</span>
                        <span className={`text-[10px] ${idx.change >= 0 ? 'text-bullish' : 'text-bearish'}`}>
                          {idx.change >= 0 ? '+' : ''}{idx.change}%
                        </span>
                      </div>
                    </div>
                    <IndexSparkline data={sparkData} color={color} height={40} />
                  </div>
                );
              })}
            </div>
            <p className="mt-3 text-[10px]" style={{ color: C.textTertiary }}>{data.marketSnapshot.europe.summary}</p>
          </DataCard>
        </div>

        <SectionDivider />

        {/* ── News Digest + 5-Scenario Forecast ── */}
        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-6">
          {/* News Digest */}
          <DataCard>
            <div className="flex items-center gap-2 mb-4">
              <Newspaper size={16} style={{ color: C.gold }} />
              <span className="text-base font-semibold" style={{ color: C.textPrimary }}>新闻摘要</span>
            </div>
            {/* Tabs */}
            <div className="flex gap-1 mb-4 flex-wrap">
              {[
                { key: 'all', label: '全部' },
                { key: 'macro', label: '宏观' },
                { key: 'policy', label: '政策' },
                { key: 'earnings', label: '业绩' },
                { key: 'geopolitical', label: '地缘' },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setNewsTab(tab.key)}
                  className="px-3 py-1 rounded-md text-xs font-medium transition-all capitalize"
                  style={{
                    background: newsTab === tab.key ? C.bgElevated : 'transparent',
                    color: newsTab === tab.key ? C.gold : C.textTertiary,
                    borderBottom: newsTab === tab.key ? `2px solid ${C.gold}` : '2px solid transparent',
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            {/* News List */}
            <AnimatePresence mode="wait">
              <motion.div
                key={newsTab}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-3 max-h-[540px] overflow-y-auto pr-1"
              >
                {filteredNews.map(item => (
                  <div key={item.id} className="pb-3" style={{ borderBottom: `1px solid ${C.borderSubtle}` }}>
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span
                        className="px-1.5 py-0.5 rounded text-[9px] font-semibold uppercase tracking-wider"
                        style={{ background: `${categoryColor(item.category)}20`, color: categoryColor(item.category) }}
                      >
                        {categoryLabel(item.category)}
                      </span>
                      <StarRating level={item.impactLevel} />
                      <SentimentBadge impact={item.impact} />
                      <ImpactBadge level={item.impactLevel} />
                    </div>
                    <h4 className="text-sm font-semibold mb-1" style={{ color: C.textPrimary }}>{item.headline}</h4>
                    <p className="text-xs mb-1" style={{ color: C.textSecondary }}>{item.summary}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px]" style={{ color: C.textTertiary }}>{item.source} &bull; {item.time}</span>
                    </div>
                    {item.affectedSectors.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {item.affectedSectors.map(s => (
                          <span key={s} className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: C.bgElevated, color: C.textTertiary }}>{s}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </motion.div>
            </AnimatePresence>
          </DataCard>

          {/* 5-Scenario Forecast */}
          <div className="space-y-4">
            <DataCard>
              <div className="flex items-center gap-2 mb-4">
                <GitBranch size={16} style={{ color: C.gold }} />
                <span className="text-base font-semibold" style={{ color: C.textPrimary }}>五情景概率预测</span>
              </div>
              <p className="text-xs mb-4" style={{ color: C.textTertiary }}>概率加权市场情景分析</p>

              {/* Probability Bar */}
              <ProbabilityBar
                segments={fiveScenarios.map(s => ({
                  label: s.label,
                  probability: s.probability,
                  color: s.color,
                }))}
                height={36}
                delay={0.2}
              />

              {/* Scenario Detail Cards */}
              <div className="space-y-2 mt-5">
                {fiveScenarios.map((sc, i) => (
                  <motion.div
                    key={sc.label}
                    initial={{ opacity: 0, x: 8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + i * 0.08, duration: 0.3 }}
                    className="flex items-center justify-between rounded-lg p-3"
                    style={{ background: C.bgCard, borderLeft: `3px solid ${sc.color}` }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: sc.color }} />
                      <span className="text-xs font-medium" style={{ color: C.textPrimary }}>{sc.label}</span>
                    </div>
                    <span className="text-sm font-bold font-mono" style={{ color: sc.color }}>{sc.probability}%</span>
                  </motion.div>
                ))}
              </div>

              {/* Scenario Sector Mapping */}
              <div className="mt-4 space-y-3">
                {data.scenarioForecast.scenarios.map(sc => (
                  <div key={sc.name} className="rounded-lg p-3" style={{ background: C.bgCard }}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold" style={{ color: C.textPrimary }}>{sc.name} ({sc.timeframe})</span>
                    </div>
                    <p className="text-[10px] mb-2" style={{ color: C.textTertiary }}>关键: {sc.key}</p>
                    <div className="flex flex-wrap gap-1 mb-1">
                      {sc.bullishSectors.map(s => (
                        <span key={s} className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: `${C.bullish}20`, color: C.bullish }}>{s}</span>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {sc.bearishSectors.map(s => (
                        <span key={s} className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: `${C.bearish}20`, color: C.bearish }}>{s}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </DataCard>
          </div>
        </div>

        <SectionDivider />

        {/* ── Timing Signals Table ── */}
        <DataCard title="时机信号" subtitle="早盘更新" signal="bullish">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr style={{ background: C.bgElevated }}>
                  {['排名', '标的', '信号', '入场', '目标', '止损', '盈亏比', '催化剂', '置信度'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-[10px] font-medium uppercase tracking-wider" style={{ color: C.textTertiary }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.timingSignals.map((s, i) => (
                  <motion.tr
                    key={s.rank}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05, duration: 0.3 }}
                    className="hover:bg-[#232837] transition-colors"
                    style={{ background: i % 2 === 0 ? C.bgCard : 'rgba(35,40,55,0.5)', borderLeft: `3px solid ${signalColor(s.signal)}` }}
                  >
                    <td className="px-3 py-3 text-[10px]" style={{ color: C.textTertiary }}>{s.rank}</td>
                    <td className="px-3 py-3 text-sm font-semibold font-mono" style={{ color: C.textPrimary }}>{s.asset}</td>
                    <td className="px-3 py-3"><VerdictBadge verdict={s.signal.toUpperCase()} size="sm" /></td>
                    <td className="px-3 py-3 text-xs font-mono" style={{ color: C.textPrimary }}>{s.entry}</td>
                    <td className="px-3 py-3 text-xs font-mono" style={{ color: C.bullish }}>{s.target}</td>
                    <td className="px-3 py-3 text-xs font-mono" style={{ color: C.bearish }}>{s.stop}</td>
                    <td className="px-3 py-3 text-xs font-medium font-mono" style={{ color: C.info }}>{s.rr}</td>
                    <td className="px-3 py-3 text-xs" style={{ color: C.textSecondary }}>{s.catalyst}</td>
                    <td className="px-3 py-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold" style={{
                        background: s.confidence > 75 ? `${C.bullish}20` : s.confidence >= 50 ? `${C.neutral}20` : `${C.bearish}20`,
                        color: s.confidence > 75 ? C.bullish : s.confidence >= 50 ? C.neutral : C.bearish,
                      }}>
                        {s.confidence}%
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </DataCard>

        <SectionDivider />

        {/* ── Risk Assessment + CIO Conclusion ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Risk Assessment with Heatmap */}
          <DataCard title="风险评估矩阵" subtitle="多维度风险热力分析">
            {/* Overall Gauge */}
            <div className="flex flex-col items-center mb-4">
              <span className="text-xs mb-2" style={{ color: C.textTertiary }}>综合风险评分</span>
              <SentimentGauge score={data.riskAssessment.overallScore} size={140} delay={0.2} />
            </div>
            {/* Heatmap Matrix */}
            <RiskHeatmap categoryScores={data.riskAssessment.categoryScores} />
            {/* Risk Details */}
            <div className="mt-4 space-y-2 pt-4" style={{ borderTop: `1px solid ${C.borderSubtle}` }}>
              {data.riskAssessment.risks.map((risk, i) => (
                <div key={i} className="flex items-start gap-2">
                  <AlertTriangle size={12} style={{ color: risk.severity === 'HIGH' ? C.bearish : risk.severity === 'MEDIUM' ? C.neutral : C.info, marginTop: 2 }} />
                  <div>
                    <span className="text-[11px] font-medium block" style={{ color: C.textPrimary }}>{risk.name}</span>
                    <span className="text-[10px]" style={{ color: C.textTertiary }}>{risk.description}</span>
                  </div>
                </div>
              ))}
            </div>
          </DataCard>

          {/* CIO Conclusion */}
          <DataCard featured signal="info">
            <div className="flex items-center gap-2 mb-1">
              <User size={16} style={{ color: C.gold }} />
              <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: C.gold }}>CIO结论</span>
            </div>
            <span className="text-xs block mb-4" style={{ color: C.textTertiary }}>{data.cioConclusion.author}</span>

            <div className="space-y-3 mb-4">
              {data.cioConclusion.text.split('\n\n').map((para, i) => (
                <p key={i} className="text-sm" style={{ color: C.textSecondary, lineHeight: 1.7 }}>{para}</p>
              ))}
            </div>

            <div className="rounded-lg p-3 mb-4" style={{ background: C.bgElevated }}>
              <span className="text-[10px] font-medium uppercase tracking-wider block mb-2" style={{ color: C.gold }}>仓位管理</span>
              <p className="text-sm font-medium" style={{ color: C.textPrimary }}>{data.cioConclusion.positionSizing}</p>
            </div>

            <div className="mb-4">
              <span className="text-[10px] font-medium uppercase tracking-wider block mb-2" style={{ color: C.gold }}>行动项</span>
              <ul className="space-y-1.5">
                {data.cioConclusion.actionItems.map((item, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -4 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.1 }}
                    className="flex items-start gap-2 text-sm"
                    style={{ color: C.textPrimary }}
                  >
                    <span style={{ color: signalColor(item.signal) }}>●</span>
                    {item.action}
                  </motion.li>
                ))}
              </ul>
            </div>

            <p className="text-right text-xs italic" style={{ color: C.textTertiary }}>— {data.cioConclusion.signature}</p>
          </DataCard>
        </div>

        <SectionDivider />

        {/* ── Pre-market Checklist + Key Timeline ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DataCard title="盘前操作清单" subtitle="今日必须检查项">
            <PreMarketChecklist />
          </DataCard>

          <DataCard title="关键时间节点" subtitle="今日重要时间提醒">
            <KeyTimeline />
          </DataCard>
        </div>

        {/* ── Footer ── */}
        <div className="text-center py-4">
          <p className="text-[10px]" style={{ color: C.textTertiary }}>
            <Clock size={10} className="inline mr-1" />
            报告生成时间: {data.reportDate} {data.generatedAt} | IWM投资委员会
          </p>
        </div>
      </div>
    </>
  );
}
