import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Cpu,
  Database,
  Monitor,
  Info,
  Check,
  ExternalLink,
  Moon,
  Sun,
  Laptop,
  BarChart3,
  Globe,
  Bot,
  CloudLightning,
  Sparkles,
  BrainCircuit,
  KeyRound,
  Layers,
  TrendingUp,
  Wifi,
  WifiOff,
  AlertCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import TokenTracker from '@/components/TokenTracker';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

/* ================================================================
   Types
   ================================================================ */
type TabKey = 'model' | 'datasource' | 'display' | 'about';
type ThemeMode = 'system' | 'dark' | 'light';

interface LLMProvider {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  keyLabel: string;
  keyPlaceholder: string;
  requiresBaseUrl: boolean;
  baseUrlLabel?: string;
  baseUrlPlaceholder?: string;
}

interface DataSourceItem {
  id: string;
  name: string;
  description: string;
  status: 'connected' | 'disconnected' | 'error';
  icon: React.ReactNode;
}

/* ================================================================
   Constants
   ================================================================ */
const TABS: { key: TabKey; label: string; icon: React.ElementType }[] = [
  { key: 'model', label: '模型配置', icon: Cpu },
  { key: 'datasource', label: '数据源', icon: Database },
  { key: 'display', label: '显示设置', icon: Monitor },
  { key: 'about', label: '关于', icon: Info },
];

const LLM_PROVIDERS: LLMProvider[] = [
  {
    id: 'deepseek',
    name: 'DeepSeek',
    icon: <BrainCircuit size={18} />,
    description: 'DeepSeek V3 / R1 系列模型，国产高性能大模型',
    keyLabel: 'API Key',
    keyPlaceholder: 'sk-xxxxxxxxxxxxxxxx',
    requiresBaseUrl: false,
  },
  {
    id: 'openai',
    name: 'OpenAI',
    icon: <Sparkles size={18} />,
    description: 'GPT-4o / GPT-4o-mini 系列模型',
    keyLabel: 'API Key',
    keyPlaceholder: 'sk-xxxxxxxxxxxxxxxx',
    requiresBaseUrl: false,
  },
  {
    id: 'anthropic',
    name: 'Claude',
    icon: <Bot size={18} />,
    description: 'Claude 3.5 Sonnet / Claude 3 Opus',
    keyLabel: 'API Key',
    keyPlaceholder: 'sk-ant-xxxxxxxxxxxxxxxx',
    requiresBaseUrl: false,
  },
  {
    id: 'gemini',
    name: 'Gemini',
    icon: <CloudLightning size={18} />,
    description: 'Google Gemini 1.5 Pro / Flash',
    keyLabel: 'API Key',
    keyPlaceholder: 'AIxxxxxxxxxxxxxxxx',
    requiresBaseUrl: false,
  },
  {
    id: 'azure',
    name: 'Azure OpenAI',
    icon: <Layers size={18} />,
    description: 'Azure 部署的 OpenAI 服务',
    keyLabel: 'API Key',
    keyPlaceholder: 'xxxxxxxxxxxxxxxx',
    requiresBaseUrl: true,
    baseUrlLabel: 'Endpoint',
    baseUrlPlaceholder: 'https://xxx.openai.azure.com/',
  },
  {
    id: 'ollama',
    name: 'Ollama',
    icon: <Cpu size={18} />,
    description: '本地部署的开源模型 (Llama/Mistral等)',
    keyLabel: 'API Key (可选)',
    keyPlaceholder: '可选',
    requiresBaseUrl: true,
    baseUrlLabel: '服务地址',
    baseUrlPlaceholder: 'http://localhost:11434',
  },
  {
    id: 'custom',
    name: '自定义',
    icon: <KeyRound size={18} />,
    description: '兼容 OpenAI API 格式的自定义服务商',
    keyLabel: 'API Key',
    keyPlaceholder: 'sk-xxxxxxxxxxxxxxxx',
    requiresBaseUrl: true,
    baseUrlLabel: 'Base URL',
    baseUrlPlaceholder: 'https://api.example.com/v1',
  },
];

const INITIAL_DATA_SOURCES: DataSourceItem[] = [
  {
    id: 'ifind',
    name: 'iFind 同花顺',
    description: 'A股实时行情、财务报表、基本面数据',
    status: 'connected',
    icon: <TrendingUp size={18} />,
  },
  {
    id: 'yahoo',
    name: 'Yahoo Finance',
    description: '美股、港股、全球市场行情数据',
    status: 'connected',
    icon: <TrendingUp size={18} />,
  },
  {
    id: 'tushare',
    name: 'Tushare Pro',
    description: 'A股历史数据、量化分析数据接口',
    status: 'disconnected',
    icon: <Database size={18} />,
  },
  {
    id: 'akshare',
    name: 'AKShare',
    description: '开源财经数据接口库，免费A股数据',
    status: 'connected',
    icon: <Database size={18} />,
  },
];

/* ================================================================
   Sub-components
   ================================================================ */

/** ---- LLM Provider Card ---- */
function ProviderCard({
  provider,
  apiKey,
  baseUrl,
  onKeyChange,
  onBaseUrlChange,
}: {
  provider: LLMProvider;
  apiKey: string;
  baseUrl: string;
  onKeyChange: (id: string, val: string) => void;
  onBaseUrlChange: (id: string, val: string) => void;
}) {
  return (
    <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-4 transition-all duration-200 hover:border-gray-700">
      <div className="flex items-center gap-3 mb-3">
        <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-gray-800 text-[#D4AF37]">
          {provider.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-text-primary">{provider.name}</h4>
          <p className="text-xs text-text-tertiary">{provider.description}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div>
          <Label className="text-xs text-text-secondary mb-1.5 block">{provider.keyLabel}</Label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => onKeyChange(provider.id, e.target.value)}
            placeholder={provider.keyPlaceholder}
            className={cn(
              'w-full rounded-lg border border-gray-800 bg-gray-950 px-3 py-2 text-sm text-text-primary',
              'placeholder:text-text-tertiary/50',
              'focus:border-[#D4AF37]/60 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]/20',
              'transition-all duration-200'
            )}
          />
        </div>

        {provider.requiresBaseUrl && (
          <div>
            <Label className="text-xs text-text-secondary mb-1.5 block">
              {provider.baseUrlLabel}
            </Label>
            <input
              type="text"
              value={baseUrl}
              onChange={(e) => onBaseUrlChange(provider.id, e.target.value)}
              placeholder={provider.baseUrlPlaceholder}
              className={cn(
                'w-full rounded-lg border border-gray-800 bg-gray-950 px-3 py-2 text-sm text-text-primary',
                'placeholder:text-text-tertiary/50',
                'focus:border-[#D4AF37]/60 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]/20',
                'transition-all duration-200'
              )}
            />
          </div>
        )}
      </div>
    </div>
  );
}

/** ---- LLMProviderPanel ---- */
function LLMProviderPanel() {
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [urls, setUrls] = useState<Record<string, string>>({});

  const handleKeyChange = useCallback((id: string, val: string) => {
    setKeys((prev) => ({ ...prev, [id]: val }));
  }, []);

  const handleBaseUrlChange = useCallback((id: string, val: string) => {
    setUrls((prev) => ({ ...prev, [id]: val }));
  }, []);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-gray-800 bg-gray-900/40 p-4">
        <p className="text-sm text-text-secondary leading-relaxed">
          配置大语言模型提供商，用于AI分析功能。支持 DeepSeek、OpenAI、Claude、Gemini 等 7 个提供商。
          所有 API Key 仅存储在本地浏览器中，不会上传到服务器。
        </p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {LLM_PROVIDERS.map((p) => (
          <ProviderCard
            key={p.id}
            provider={p}
            apiKey={keys[p.id] || ''}
            baseUrl={urls[p.id] || ''}
            onKeyChange={handleKeyChange}
            onBaseUrlChange={handleBaseUrlChange}
          />
        ))}
      </div>
    </div>
  );
}

/** ---- DataSourcePanel ---- */
function DataSourcePanel() {
  const [sources, setSources] = useState<DataSourceItem[]>(INITIAL_DATA_SOURCES);
  const [editingToken, setEditingToken] = useState<Record<string, string>>({});

  const toggleStatus = useCallback((id: string) => {
    setSources((prev) =>
      prev.map((s) =>
        s.id === id
          ? { ...s, status: s.status === 'connected' ? 'disconnected' : 'connected' }
          : s
      )
    );
  }, []);

  const handleTokenChange = useCallback((id: string, val: string) => {
    setEditingToken((prev) => ({ ...prev, [id]: val }));
  }, []);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-gray-800 bg-gray-900/40 p-4">
        <p className="text-sm text-text-secondary leading-relaxed">
          配置金融数据源，用于获取实时行情和基本面数据。每个数据源需要对应的 API Token 才能正常工作。
        </p>
      </div>

      <div className="space-y-3">
        {sources.map((src) => {
          const isConnected = src.status === 'connected';
          const isError = src.status === 'error';
          return (
            <div
              key={src.id}
              className={cn(
                'rounded-xl border p-4 transition-all duration-200',
                isConnected
                  ? 'border-gray-800 bg-gray-900/60 hover:border-gray-700'
                  : isError
                    ? 'border-red-900/40 bg-red-950/20 hover:border-red-800/60'
                    : 'border-gray-800/60 bg-gray-900/30 hover:border-gray-700/80'
              )}
            >
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'flex items-center justify-center w-10 h-10 rounded-lg',
                    isConnected ? 'bg-emerald-950/40 text-emerald-400' : 'bg-gray-800 text-text-tertiary'
                  )}
                >
                  {src.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-semibold text-text-primary">{src.name}</h4>
                    <span
                      className={cn(
                        'inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-md',
                        isConnected
                          ? 'bg-emerald-950/50 text-emerald-400'
                          : isError
                            ? 'bg-red-950/50 text-red-400'
                            : 'bg-gray-800 text-text-tertiary'
                      )}
                    >
                      {isConnected ? (
                        <Wifi size={10} />
                      ) : isError ? (
                        <AlertCircle size={10} />
                      ) : (
                        <WifiOff size={10} />
                      )}
                      {isConnected ? '已连接' : isError ? '异常' : '未连接'}
                    </span>
                  </div>
                  <p className="text-xs text-text-tertiary mt-0.5">{src.description}</p>
                </div>
                <Switch
                  checked={isConnected}
                  onCheckedChange={() => toggleStatus(src.id)}
                />
              </div>

              {/* API Token input */}
              <div className="mt-3 pt-3 border-t border-gray-800">
                <div className="flex items-center gap-3">
                  <input
                    type="password"
                    value={editingToken[src.id] || ''}
                    onChange={(e) => handleTokenChange(src.id, e.target.value)}
                    placeholder={`输入 ${src.name} API Token`}
                    className={cn(
                      'flex-1 rounded-lg border border-gray-800 bg-gray-950 px-3 py-2 text-sm text-text-primary',
                      'placeholder:text-text-tertiary/50',
                      'focus:border-[#D4AF37]/60 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]/20',
                      'transition-all duration-200'
                    )}
                  />
                  {editingToken[src.id] && (
                    <button
                      className={cn(
                        'px-3 py-2 rounded-lg text-sm font-medium',
                        'bg-[#D4AF37]/10 text-[#D4AF37] hover:bg-[#D4AF37]/20',
                        'transition-colors duration-200'
                      )}
                    >
                      保存
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** ---- DisplaySettingsPanel ---- */
function DisplaySettingsPanel() {
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [language, setLanguage] = useState<'zh' | 'en'>('zh');
  const [chartAnimation, setChartAnimation] = useState(true);

  // Sync with ThemeContext on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('iwm-theme');
      if (stored === 'light' || stored === 'dark') {
        setThemeMode(stored);
      } else {
        setThemeMode('system');
      }
    } catch {
      // ignore
    }
  }, []);

  const applyTheme = useCallback((mode: ThemeMode) => {
    setThemeMode(mode);
    const root = document.documentElement;
    if (mode === 'system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.removeAttribute('data-theme');
        localStorage.setItem('iwm-theme', 'dark');
      } else {
        root.setAttribute('data-theme', 'light');
        localStorage.setItem('iwm-theme', 'light');
      }
    } else if (mode === 'light') {
      root.setAttribute('data-theme', 'light');
      localStorage.setItem('iwm-theme', 'light');
    } else {
      root.removeAttribute('data-theme');
      localStorage.setItem('iwm-theme', 'dark');
    }
  }, []);

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Theme */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Monitor size={16} className="text-[#D4AF37]" />
          <h3 className="text-sm font-semibold text-text-primary">主题设置</h3>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {([
            { mode: 'system' as ThemeMode, icon: Laptop, label: '跟随系统' },
            { mode: 'dark' as ThemeMode, icon: Moon, label: '深色模式' },
            { mode: 'light' as ThemeMode, icon: Sun, label: '浅色模式' },
          ]).map(({ mode, icon: Icon, label }) => (
            <button
              key={mode}
              onClick={() => applyTheme(mode)}
              className={cn(
                'flex flex-col items-center gap-2 rounded-lg border p-4 transition-all duration-200',
                themeMode === mode
                  ? 'border-[#D4AF37]/60 bg-[#D4AF37]/10 text-[#D4AF37]'
                  : 'border-gray-800 bg-gray-950/60 text-text-secondary hover:border-gray-700 hover:text-text-primary'
              )}
            >
              <Icon size={22} />
              <span className="text-xs font-medium">{label}</span>
              {themeMode === mode && (
                <Check size={14} className="text-[#D4AF37]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Language */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Globe size={16} className="text-[#D4AF37]" />
          <h3 className="text-sm font-semibold text-text-primary">语言设置</h3>
        </div>
        <Select value={language} onValueChange={(v: 'zh' | 'en') => setLanguage(v)}>
          <SelectTrigger className="w-48 border-gray-800 bg-gray-950">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="zh">中文 (简体)</SelectItem>
            <SelectItem value="en">English</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Chart Animation */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BarChart3 size={16} className="text-[#D4AF37]" />
            <div>
              <h3 className="text-sm font-semibold text-text-primary">图表动画</h3>
              <p className="text-xs text-text-tertiary mt-0.5">启用图表加载和交互动画效果</p>
            </div>
          </div>
          <Switch checked={chartAnimation} onCheckedChange={setChartAnimation} />
        </div>
      </div>
    </div>
  );
}

/** ---- AboutPanel ---- */
function AboutPanel() {
  return (
    <div className="max-w-2xl space-y-6">
      {/* Logo & Version */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-6 text-center">
        <div className="flex items-center justify-center gap-3 mb-3">
          <img src="/iwm-logo.svg" alt="IWM" className="w-12 h-12" />
          <div>
            <h2 className="text-xl font-bold text-text-primary">IWM 投资参谋系统</h2>
            <p className="text-sm text-text-tertiary">Investment Wisdom Matrix</p>
          </div>
        </div>
        <div className="inline-flex items-center gap-1.5 rounded-full bg-gray-800 px-3 py-1 text-xs text-text-secondary">
          <Check size={12} className="text-emerald-400" />
          版本 v2.6.1
        </div>
      </div>

      {/* Tech Stack */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-5">
        <h3 className="text-sm font-semibold text-text-primary mb-3">技术栈</h3>
        <div className="flex flex-wrap gap-2">
          {['React 19', 'TypeScript', 'Tailwind CSS', 'Lightweight Charts', 'Recharts', 'Vite'].map(
            (tech) => (
              <span
                key={tech}
                className="rounded-md bg-gray-800 px-2.5 py-1 text-xs text-text-secondary border border-gray-700"
              >
                {tech}
              </span>
            )
          )}
        </div>
      </div>

      {/* Acknowledgements */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/60 p-5">
        <h3 className="text-sm font-semibold text-text-primary mb-3">致谢</h3>
        <ul className="space-y-2">
          {[
            { name: 'TradingAgents-cn-PLUS', desc: 'AI 投研智能体框架', url: 'https://github.com/SuperPowered-Cat/TradingAgents-cn-PLUS' },
            { name: 'Lightweight Charts', desc: '专业金融图表库', url: 'https://tradingview.github.io/lightweight-charts/' },
            { name: 'Recharts', desc: 'React 数据可视化组件库', url: 'https://recharts.org' },
            { name: 'shadcn/ui', desc: 'React UI 组件库', url: 'https://ui.shadcn.com' },
          ].map((item) => (
            <li key={item.name} className="flex items-center justify-between group">
              <div>
                <span className="text-sm text-text-secondary">{item.name}</span>
                <span className="text-xs text-text-tertiary ml-2">{item.desc}</span>
              </div>
              <a
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-text-tertiary hover:text-[#D4AF37] transition-colors duration-200"
              >
                <ExternalLink size={14} />
              </a>
            </li>
          ))}
        </ul>
      </div>

      {/* License */}
      <div className="rounded-xl border border-gray-800 bg-gray-900/40 p-5">
        <p className="text-xs text-text-tertiary leading-relaxed">
          本软件仅供学习和研究使用。数据来源于公开渠道，不构成投资建议。投资有风险，入市需谨慎。
          所有第三方商标和版权属于其各自所有者。
        </p>
      </div>
    </div>
  );
}

/* ================================================================
   Main Settings Page
   ================================================================ */
export default function Settings() {
  const [activeTab, setActiveTab] = useState<TabKey>('model');

  const renderContent = () => {
    switch (activeTab) {
      case 'model':
        return (
          <>
            <LLMProviderPanel />
            <div className="mt-8">
              <TokenTracker />
            </div>
          </>
        );
      case 'datasource':
        return <DataSourcePanel />;
      case 'display':
        return <DisplaySettingsPanel />;
      case 'about':
        return <AboutPanel />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-full bg-gray-950">
      {/* Page Header */}
      <div className="border-b border-gray-800 bg-gray-900/40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
          <h1 className="text-2xl font-bold text-text-primary tracking-tight">系统设置</h1>
          <p className="text-sm text-text-tertiary mt-1">配置模型、数据源、显示偏好和查看系统信息</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
        {/* Desktop: horizontal tab list / Mobile: scrollable horizontal */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Tab Navigation */}
          <nav className="lg:w-56 flex-shrink-0">
            <div className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0 -mx-1 px-1">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={cn(
                      'flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium',
                      'whitespace-nowrap transition-all duration-200 flex-shrink-0',
                      isActive
                        ? 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30'
                        : 'text-text-secondary hover:text-text-primary hover:bg-gray-900 border border-transparent'
                    )}
                  >
                    <Icon size={18} />
                    {tab.label}
                    {isActive && (
                      <motion.div
                        layoutId="activeTabIndicator"
                        className="hidden lg:block ml-auto w-1 h-1 rounded-full bg-[#D4AF37]"
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </nav>

          {/* Tab Content */}
          <main className="flex-1 min-w-0">
            <div className="transition-all duration-300 ease-out">
              {renderContent()}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
