import { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import {
  ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, ZAxis,
  Tooltip as ReTooltip, Cell, ReferenceLine
} from 'recharts';
import {
  Layers, Users, AlertTriangle, Building2, TrendingUp,
  TrendingDown, Minus, ArrowRight, ChevronRight, Search,
  ArrowUpDown, Zap, Cpu, Car
} from 'lucide-react';
import AIAnalysisPanel from '@/components/AIAnalysisPanel';
import ExportButton from '@/components/ExportButton';

/* ───────────────────── types ───────────────────── */

interface IndustryMeta {
  slug: string;
  shortName: string;
  name: string;
  category: string;
  description: string;
  score: number;
  lifecycle: string;
  trend: string;
  signal: string;
}

interface SupplySegment {
  name: string;
  players: string[];
  margin: number;
  bottleneck: boolean;
  trend: string;
  description: string;
}

interface SupplyStage {
  stage: string;
  segments: SupplySegment[];
}

interface CompetitionPlayer {
  rank: number;
  ticker: string;
  name: string;
  marketShare: number;
  growthRate: number;
  moatScore: number;
  revenue: number;
  marketCap: number;
  signal: string;
  quadrant: string;
}

interface BottleneckItem {
  name: string;
  severity: number;
  description: string;
  impact: string;
  resolution: string;
  affected: string[];
}

interface MetricCard {
  label: string;
  value: string;
  context: string;
  signal: string;
}

interface CompanyRow {
  rank: number;
  ticker: string;
  name: string;
  marketCap: number;
  revenue: number;
  growth: number;
  moatScore: number;
  profitMargin: number;
  signal: string;
}

interface IndustryData {
  overview: {
    name: string;
    tag: string;
    description: string;
    verdict: string;
    trend: string;
    momentumScore: number;
    lastUpdated: string;
  };
  supplyChain: SupplyStage[];
  competition: { players: CompetitionPlayer[] };
  bottlenecks: { supplyTightness: number; items: BottleneckItem[] };
  metrics: MetricCard[];
  companies: CompanyRow[];
}

/* ───────────────────── helpers ───────────────────── */

const signalColor = (s: string) => {
  const sig = s?.toUpperCase() ?? 'NEUTRAL';
  if (sig === 'BULLISH') return { text: '#10B981', bg: 'rgba(16,185,129,0.12)', border: '#10B981' };
  if (sig === 'BEARISH') return { text: '#EF4444', bg: 'rgba(239,68,68,0.12)', border: '#EF4444' };
  return { text: '#F59E0B', bg: 'rgba(245,158,11,0.12)', border: '#F59E0B' };
};

const trendIcon = (t: string) => {
  if (t === 'up' || t === 'uptrend') return <TrendingUp size={14} className="text-[#10B981]" />;
  if (t === 'down' || t === 'downtrend') return <TrendingDown size={14} className="text-[#EF4444]" />;
  return <Minus size={14} className="text-[#F59E0B]" />;
};

const INDUSTRY_TABS = [
  { slug: 'ai', shortName: 'AI', icon: Cpu },
  { slug: 'semiconductor', shortName: '半导体', icon: Zap },
  { slug: 'ev', shortName: '电动车', icon: Car },
];

/* ───────────────────── component ───────────────────── */

export default function Industry() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug || 'ai';
  const navigate = useNavigate();
  const [, setIndustriesMeta] = useState<IndustryMeta[]>([]);
  const [industryData, setIndustryData] = useState<IndustryData | null>(null);
  const [loading, setLoading] = useState(true);

  /* table state */
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<keyof CompanyRow>('rank');
  const [sortAsc, setSortAsc] = useState(true);
  const [signalFilter, setSignalFilter] = useState<string>('All');

  useEffect(() => {
    setLoading(true);
    fetch('/data/industries.json')
      .then(r => r.json())
      .then(d => setIndustriesMeta(d.industries))
      .catch(() => setIndustriesMeta([]));
  }, []);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    fetch(`/data/industry_${slug}.json`)
      .then(r => r.json())
      .then(d => { setIndustryData(d); setLoading(false); })
      .catch(() => { setIndustryData(null); setLoading(false); });
  }, [slug]);

  /* memoized table rows */
  const filteredCompanies = useMemo(() => {
    if (!industryData) return [];
    let rows = [...industryData.companies];
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(r => r.ticker.toLowerCase().includes(q) || r.name.toLowerCase().includes(q));
    }
    if (signalFilter !== 'All') {
      rows = rows.filter(r => r.signal === signalFilter);
    }
    rows.sort((a, b) => {
      const va = a[sortField];
      const vb = b[sortField];
      if (typeof va === 'number' && typeof vb === 'number') {
        return sortAsc ? va - vb : vb - va;
      }
      return sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    });
    return rows;
  }, [industryData, search, sortField, sortAsc, signalFilter]);

  /* competition scatter data */
  const scatterData = useMemo(() => {
    if (!industryData) return [];
    return industryData.competition.players.map(p => ({
      x: p.marketShare,
      y: p.growthRate,
      z: p.marketCap / 50,
      ticker: p.ticker,
      name: p.name,
      quadrant: p.quadrant,
    }));
  }, [industryData]);

  const handleSort = (field: keyof CompanyRow) => {
    if (sortField === field) setSortAsc(!sortAsc);
    else { setSortField(field); setSortAsc(true); }
  };

  if (loading || !industryData) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-[#8A93A8] text-sm font-mono">加载行业数据...</div>
      </div>
    );
  }

  const o = industryData.overview;
  const sigColors = signalColor(o.verdict);

  return (
    <div className="space-y-8 pb-12 bg-[#0B0D10] text-[#F0F2F8] min-h-[100dvh] p-6">
      {/* ── Breadcrumb ── */}
      <nav className="flex items-center gap-2 text-[13px] text-[#5C6375] pb-2">
        <Link to="/" className="text-[#D4AF37] hover:underline">仪表盘</Link>
        <span>/</span>
        <span>行业</span>
        <span>/</span>
        <span className="text-[#F0F2F8] font-semibold">{o.name}</span>
      </nav>

      {/* ── Industry Hero ── */}
      <section
        className="relative rounded-xl p-8 md:p-10 overflow-hidden"
        style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(212,175,55,0.06) 0%, transparent 60%)', backgroundColor: '#14171F', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="space-y-3">
          <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-[#5C6375]">{o.tag}</p>
          <h1 className="text-[36px] font-bold text-[#F0F2F8] font-mono tracking-[-0.02em]">{o.name}</h1>
          <p className="text-[14px] text-[#8A93A8] max-w-[700px] leading-relaxed">{o.description}</p>
          <div className="flex items-center gap-4 pt-2">
            <span
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[13px] font-semibold uppercase"
              style={{ background: sigColors.bg, color: sigColors.text, border: `1px solid ${sigColors.border}` }}
            >
              {o.verdict}
            </span>
            <span className="flex items-center gap-1 text-[13px]" style={{ color: sigColors.text }}>
              {trendIcon(o.trend)}
              {o.trend === 'uptrend' ? '上升趋势' : o.trend === 'downtrend' ? '下降趋势' : '盘整'}
            </span>
            <div className="flex items-center gap-2">
              <div className="w-[60px] h-[30px] rounded-full relative overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${o.momentumScore}%`, background: o.momentumScore > 70 ? '#10B981' : o.momentumScore > 40 ? '#F59E0B' : '#EF4444' }}
                />
              </div>
              <span className="text-[11px] text-[#5C6375] uppercase tracking-wider">{o.momentumScore}/100</span>
            </div>
          </div>
          <p className="text-[11px] text-[#5C6375] uppercase tracking-[0.06em] pt-1">
            Last updated: {new Date(o.lastUpdated).toLocaleDateString()}
          </p>
        </div>
      </section>

      {/* ── AI智能分析 ── */}
      <AIAnalysisPanel industry={(industryData as any)?.overview?.name || 'AI' || 'AI'} data={industryData as unknown as Record<string, unknown>} />

      {/* ── 导出按钮 ── */}
      <div className="flex justify-end mb-4">
        <ExportButton data={industryData as unknown as Record<string, unknown>} filename={`industry_${slug || 'ai'}`} />
      </div>

      {/* ── Industry Selector Tabs ── */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2">
        {INDUSTRY_TABS.map(tab => {
          const active = slug === tab.slug;
          const Icon = tab.icon;
          return (
            <button
              key={tab.slug}
              onClick={() => navigate(`/industry/${tab.slug}`)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-medium whitespace-nowrap transition-all duration-200"
              style={{
                background: active ? '#1C1F2B' : 'transparent',
                color: active ? '#F0F2F8' : '#5C6375',
                borderBottom: active ? '2px solid #D4AF37' : '2px solid transparent',
              }}
              onMouseEnter={e => { if (!active) { e.currentTarget.style.background = '#232837'; e.currentTarget.style.color = '#8A93A8'; } }}
              onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#5C6375'; } }}
            >
              <Icon size={16} />
              {tab.shortName}
            </button>
          );
        })}
      </div>

      {/* ── Supply Chain Flow ── */}
      <section
        className="rounded-xl p-5 md:p-6"
        style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex items-center gap-2 mb-5">
          <Layers size={18} className="text-[#D4AF37]" />
          <h2 className="text-[18px] font-semibold text-[#F0F2F8]">供应链图谱</h2>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          {industryData.supplyChain.map((stage, si) => (
            <div key={stage.stage} className="flex-1 flex flex-col gap-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-medium uppercase tracking-[0.06em] text-[#D4AF37]">{stage.stage}</span>
                {si < industryData.supplyChain.length - 1 && (
                  <ArrowRight size={16} className="text-[#D4AF37] hidden md:block ml-auto" />
                )}
              </div>
              {stage.segments.map(seg => (
                <div
                  key={seg.name}
                  className="rounded-lg p-3 transition-all duration-200 hover:-translate-y-0.5 group"
                  style={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.06)' }}
                  title={seg.description}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[13px] font-semibold text-[#F0F2F8]">{seg.name}</span>
                    <div className="flex items-center gap-1.5">
                      {seg.bottleneck && <AlertTriangle size={12} className="text-[#F59E0B]" />}
                      {trendIcon(seg.trend)}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {seg.players.map(p => (
                      <span key={p} className="px-1.5 py-0.5 rounded text-[10px] font-medium text-[#8A93A8]" style={{ background: '#232837' }}>{p}</span>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${seg.margin}%`,
                          background: seg.margin > 50 ? '#10B981' : seg.margin > 25 ? '#F59E0B' : '#EF4444'
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-[#5C6375]">{seg.margin}%</span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ── Competition + Bottleneck ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Competition Landscape */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center gap-2 mb-1">
            <Users size={18} className="text-[#D4AF37]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">竞争格局</h2>
          </div>
          <p className="text-[13px] text-[#5C6375] mb-4">市场份额与竞争定位</p>
          <div className="h-[280px] w-full">
            <ResponsiveContainer>
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
                <XAxis
                  type="number" dataKey="x" name="Market Share" unit="%"
                  stroke="#5C6375" tick={{ fontSize: 10 }} label={{ value: '市场份额 →', position: 'bottom', fill: '#5C6375', fontSize: 10 }}
                />
                <YAxis
                  type="number" dataKey="y" name="Growth Rate" unit="%"
                  stroke="#5C6375" tick={{ fontSize: 10 }} label={{ value: '增长率 →', angle: -90, position: 'insideLeft', fill: '#5C6375', fontSize: 10 }}
                />
                <ZAxis type="number" dataKey="z" range={[60, 400]} />
                <ReTooltip
                  contentStyle={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                  itemStyle={{ color: '#F0F2F8', fontSize: 12 }}
                  formatter={(_v: unknown, _n: string, props: { payload?: { ticker?: string; name?: string } }) => {
                    const p = props?.payload;
                    return p ? [`${p.ticker} — ${p.name}`, ''] : ['', ''];
                  }}
                />
                <ReferenceLine x={20} stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                <ReferenceLine y={30} stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                {/* Quadrant labels */}
                <Scatter data={scatterData}>
                  {scatterData.map((entry, idx) => (
                    <Cell key={`cell-${idx}`} fill={
                      entry.quadrant === 'Leader' ? '#10B981' :
                      entry.quadrant === 'Challenger' ? '#3B82F6' :
                      entry.quadrant === 'Incumbent' ? '#D4AF37' : '#8A93A8'
                    } />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>
          {/* Compact player list */}
          <div className="mt-4 space-y-2">
            {industryData.competition.players.slice(0, 4).map(p => {
              const sc = signalColor(p.signal);
              return (
                <div key={p.ticker} className="flex items-center gap-3 py-1.5 px-2 rounded-md hover:bg-[#232837] transition-colors">
                  <span className="text-[11px] text-[#5C6375] w-5">{p.rank}</span>
                  <span className="text-[13px] font-mono font-bold text-[#F0F2F8] w-14">{p.ticker}</span>
                  <span className="text-[12px] text-[#8A93A8] flex-1">{p.name}</span>
                  <span className="text-[12px] font-mono text-[#F0F2F8]">{p.marketShare}%</span>
                  <span className="text-[12px] font-mono text-[#10B981]">+{p.growthRate}%</span>
                  <span
                    className="text-[10px] px-1.5 py-0.5 rounded-full uppercase font-medium"
                    style={{ background: sc.bg, color: sc.text }}
                  >{p.signal}</span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Bottleneck Analysis */}
        <section
          className="rounded-xl p-5 md:p-6"
          style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle size={18} className="text-[#D4AF37]" />
            <h2 className="text-[18px] font-semibold text-[#F0F2F8]">瓶颈分析</h2>
          </div>
          <p className="text-[13px] text-[#5C6375] mb-4">供应链约束与产能紧张度</p>

          {/* Overall gauge */}
          <div className="flex items-center gap-4 mb-5 p-3 rounded-lg" style={{ background: '#1C1F2B' }}>
            <div className="relative w-[80px] h-[40px]">
              <svg viewBox="0 0 80 40" className="w-full h-full">
                <path d="M 5 35 A 35 35 0 0 1 75 35" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
                <path
                  d="M 5 35 A 35 35 0 0 1 75 35"
                  fill="none"
                  stroke={industryData.bottlenecks.supplyTightness > 70 ? '#EF4444' : industryData.bottlenecks.supplyTightness > 40 ? '#F59E0B' : '#10B981'}
                  strokeWidth="6"
                  strokeDasharray={`${industryData.bottlenecks.supplyTightness * 1.1} 110`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 text-[11px] font-bold text-[#F0F2F8]">{industryData.bottlenecks.supplyTightness}</div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.06em] text-[#5C6375]">供应紧张度</p>
              <p className="text-[14px] text-[#F0F2F8] font-medium">
                {industryData.bottlenecks.supplyTightness > 70 ? '高度紧张' : industryData.bottlenecks.supplyTightness > 40 ? '中度紧张' : '低度紧张'}
              </p>
            </div>
          </div>

          {/* Bottleneck items */}
          <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1">
            {industryData.bottlenecks.items.map(bn => (
              <div key={bn.name} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-semibold text-[#F0F2F8]">{bn.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-medium"
                    style={{
                      background: bn.impact.includes('PRICE') ? 'rgba(239,68,68,0.12)' : bn.impact.includes('DELAY') ? 'rgba(245,158,11,0.12)' : 'rgba(59,130,246,0.12)',
                      color: bn.impact.includes('PRICE') ? '#EF4444' : bn.impact.includes('DELAY') ? '#F59E0B' : '#3B82F6'
                    }}
                  >{bn.impact}</span>
                </div>
                <p className="text-[12px] text-[#8A93A8] leading-relaxed">{bn.description}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${bn.severity}%`,
                        background: bn.severity > 80 ? '#EF4444' : bn.severity > 50 ? '#F59E0B' : '#10B981'
                      }}
                    />
                  </div>
                  <span className="text-[10px] text-[#5C6375]">{bn.severity}/100</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-[#5C6375]">缓解: {bn.resolution}</span>
                  <div className="flex gap-1">
                    {bn.affected.map(a => (
                      <span key={a} className="px-1 py-0.5 rounded text-[9px] text-[#8A93A8]" style={{ background: '#232837' }}>{a}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* ── Industry KPIs ── */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {industryData.metrics.map(m => {
          const mc = signalColor(m.signal);
          return (
            <div
              key={m.label}
              className="rounded-xl p-5 transition-all duration-200 hover:-translate-y-0.5"
              style={{
                background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)',
                borderLeft: `3px solid ${mc.border}`,
                borderTop: '1px solid rgba(255,255,255,0.06)',
                borderRight: '1px solid rgba(255,255,255,0.06)',
                borderBottom: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-[#5C6375] mb-2">{m.label}</p>
              <p className="text-[28px] font-bold text-[#F0F2F8] font-mono tracking-[-0.02em]">{m.value}</p>
              <p className="text-[12px] text-[#5C6375] mt-1">{m.context}</p>
            </div>
          );
        })}
      </section>

      {/* ── Company List Table ── */}
      <section
        className="rounded-xl p-5 md:p-6"
        style={{ background: 'linear-gradient(180deg, #1C1F2B 0%, #14171F 100%)', border: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex items-center gap-2 mb-1">
          <Building2 size={18} className="text-[#D4AF37]" />
          <h2 className="text-[18px] font-semibold text-[#F0F2F8]">行业公司列表</h2>
        </div>

        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row gap-3 mt-4 mb-4">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5C6375]" />
            <input
              type="text"
              placeholder="搜索公司或股票代码..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-2 rounded-lg text-[13px] text-[#F0F2F8] placeholder-[#5C6375] outline-none focus:ring-1 focus:ring-[#D4AF37]"
              style={{ background: '#1C1F2B', border: '1px solid rgba(255,255,255,0.06)' }}
            />
          </div>
          <div className="flex items-center gap-1">
            {[
              { val: 'All', label: '全部' },
              { val: 'Bullish', label: '看涨' },
              { val: 'Bearish', label: '看跌' },
              { val: 'Neutral', label: '中性' },
            ].map(f => (
              <button
                key={f.val}
                onClick={() => setSignalFilter(f.val)}
                className="px-3 py-1.5 rounded-lg text-[11px] font-medium uppercase transition-all duration-200"
                style={{
                  background: signalFilter === f.val ? '#1C1F2B' : 'transparent',
                  color: signalFilter === f.val ? '#F0F2F8' : '#5C6375',
                  border: signalFilter === f.val ? '1px solid rgba(212,175,55,0.25)' : '1px solid transparent',
                }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr style={{ background: '#1C1F2B' }}>
                {[
                  { key: 'rank', label: '排名' },
                  { key: 'ticker', label: '代码' },
                  { key: 'name', label: '公司' },
                  { key: 'marketCap', label: '市值' },
                  { key: 'revenue', label: '营收' },
                  { key: 'growth', label: '增速' },
                  { key: 'moatScore', label: '护城河' },
                  { key: 'signal', label: '信号' },
                ].map(col => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key as keyof CompanyRow)}
                    className="px-3 py-2.5 text-[11px] font-medium uppercase tracking-[0.06em] text-[#5C6375] cursor-pointer select-none hover:text-[#8A93A8] transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      {col.label}
                      <ArrowUpDown size={10} />
                    </div>
                  </th>
                ))}
                <th className="px-3 py-2.5 text-[11px] font-medium uppercase tracking-[0.06em] text-[#5C6375]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredCompanies.map((c, idx) => {
                const sc = signalColor(c.signal);
                const moatColor = c.moatScore > 70 ? '#10B981' : c.moatScore > 40 ? '#F59E0B' : '#EF4444';
                return (
                  <tr
                    key={c.ticker}
                    className="transition-colors duration-150 hover:bg-[#232837] cursor-pointer"
                    style={{ background: idx % 2 === 0 ? '#14171F' : '#1A1D26', borderLeft: `3px solid ${sc.border}` }}
                  >
                    <td className="px-3 py-3 text-[11px] text-[#5C6375]">{c.rank}</td>
                    <td className="px-3 py-3">
                      <Link
                        to={`/company/${c.ticker}`}
                        className="text-[13px] font-mono font-bold text-[#F0F2F8] hover:text-[#D4AF37] transition-colors"
                      >
                        {c.ticker}
                      </Link>
                    </td>
                    <td className="px-3 py-3 text-[12px] text-[#8A93A8]">{c.name}</td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#F0F2F8]">
                      {c.marketCap >= 1000 ? `$${(c.marketCap / 1000).toFixed(1)}T` : `$${c.marketCap}B`}
                    </td>
                    <td className="px-3 py-3 text-[12px] font-mono text-[#F0F2F8]">${c.revenue}B</td>
                    <td className="px-3 py-3 text-[12px] font-mono" style={{ color: c.growth > 0 ? '#10B981' : '#EF4444' }}>
                      {c.growth > 0 ? '+' : ''}{c.growth}%
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-[60px] h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                          <div className="h-full rounded-full" style={{ width: `${c.moatScore}%`, background: moatColor }} />
                        </div>
                        <span className="text-[11px] font-mono" style={{ color: moatColor }}>{c.moatScore}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className="inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase"
                        style={{ background: sc.bg, color: sc.text }}
                      >
                        {c.signal}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <Link
                        to={`/company/${c.ticker}`}
                        className="flex items-center gap-1 text-[12px] text-[#D4AF37] hover:text-[#C89B20] transition-colors"
                      >
                        分析 <ChevronRight size={12} />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredCompanies.length === 0 && (
          <div className="text-center py-8 text-[13px] text-[#5C6375]">没有符合筛选条件的公司。</div>
        )}
      </section>
    </div>
  );
}
