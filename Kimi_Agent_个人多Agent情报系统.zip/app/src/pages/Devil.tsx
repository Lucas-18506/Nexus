import { useState, useEffect, useCallback, useMemo } from 'react'
import type { ReactNode } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  AlertTriangle,
  ChevronDown,
  EyeOff,
  GitBranch,
  ArrowLeftRight,
  ShieldAlert,
  Activity,
  Target,
  TrendingDown,
  Zap,
  BarChart3,
  Crosshair,
  Copy,
  Check,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible'

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts'

/* ═══════════════════════════════════════════════════════════════
   Types
   ═══════════════════════════════════════════════════════════════ */

interface QuantDataItem {
  metric: string
  value: string
  peerAvg?: string
  historical?: string
  trend?: string
  normal?: string
  target?: string
  current?: string
  compatible?: string
  preCovid?: string
  recovery?: string
  firstTime?: string
  Scurve?: string
  impact?: string
  potential?: string
  BYD?: string
  threshold?: string
  lesson?: string
}

interface ThesisBullet {
  lead: string
  explanation: string
  quantEvidence: string
}

interface ContrarianThesis {
  statement: string
  confidence: number
  bullets: ThesisBullet[]
}

interface RefutationArg {
  title: string
  bullets: string[]
  quantData?: QuantDataItem[]
}

interface Refutation {
  id: string
  topic: string
  systemView: string
  contrarianView: string
  severity: string
  systemArgument: RefutationArg
  contrarianRebuttal: RefutationArg
  blindSpot: string
  probabilityAdjustment: string
  monitoringIndicator: string
}

interface BlindSpot {
  category: string
  name: string
  description: string
  severity: string
  mitigation: string
  monitoringIndicator: string
}

interface AssetAllocation {
  equity: string
  bond: string
  cash: string
  hedge: string
}

interface AltScenario {
  title: string
  probability: number
  trigger: string
  marketImpact: { sp500: string; vix: string; yield10y: string }
  hedge: string
  historicalParallel: string
  assetAllocation: AssetAllocation
  keyAssets: string[]
}

interface ProbCorrection {
  scenario: string
  baseline: number
  adjustment: number
  final: number
  rationale: string
}

interface ContrarianPosition {
  type: string
  asset: string
  direction: string
  rationale: string
  sizing: string
  conviction: string
  entryZone: string
  target: string
  stop: string
}

interface SingleStockScenario {
  shock: string
  trigger: string
  portfolioImpact: string
  daysToRecover: string
  hedge: string
}

interface SingleStockShock {
  ticker: string
  name: string
  scenarios: SingleStockScenario[]
}

interface SectorShock {
  sector: string
  shock: string
  trigger: string
  portfolioImpact: string
  affectedTickers: string[]
  hedge: string
}

interface TailRiskScenario {
  name: string
  probability: string
  sp500Impact: string
  recovery: string
  correlation: string
  hedge: string
}

interface StressTest {
  singleStockShocks: SingleStockShock[]
  sectorShocks: SectorShock[]
  tailRiskScenarios: TailRiskScenario[]
}

interface DevilData {
  contrarianThesis: ContrarianThesis
  refutations: Refutation[]
  blindSpots: BlindSpot[]
  alternativeScenarios: AltScenario[]
  probabilityCorrections: ProbCorrection[]
  contrarianPositions: ContrarianPosition[]
  stressTest: StressTest
  meta: { generatedAt: string; version: string }
}

/* ═══════════════════════════════════════════════════════════════
   Constants
   ═══════════════════════════════════════════════════════════════ */

const easeOut = [0.16, 1, 0.3, 1] as [number, number, number, number]

const PIE_COLORS = {
  equity: '#EF4444',
  bond: '#3B82F6',
  cash: '#F59E0B',
  hedge: '#10B981',
}

const SHOCK_COLORS: Record<string, string> = {
  '-20%': '#F59E0B',
  '-30%': '#EF4444',
  '-50%': '#DC2626',
}

const SEVERITY_MAP: Record<string, string> = {
  '致命': 'fatal',
  '高': 'high',
  '中': 'medium',
  '低': 'low',
}

/* ═══════════════════════════════════════════════════════════════
   Helpers
   ═══════════════════════════════════════════════════════════════ */

function getSeverityColor(sev: string) {
  const mapped = SEVERITY_MAP[sev] || sev.toLowerCase()
  switch (mapped) {
    case 'fatal':
      return { text: 'text-red-500', bg: 'bg-red-500/10', border: 'border-red-500', dot: '#EF4444', label: '致命' }
    case 'high':
      return { text: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500', dot: '#F59E0B', label: '高' }
    case 'medium':
      return { text: 'text-yellow-500', bg: 'bg-yellow-500/10', border: 'border-yellow-500', dot: '#EAB308', label: '中' }
    case 'low':
      return { text: 'text-emerald-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500', dot: '#10B981', label: '低' }
    default:
      return { text: 'text-gray-400', bg: 'bg-gray-400/10', border: 'border-gray-400', dot: '#9CA3AF', label: sev }
  }
}

function isValueAnomalous(value: string): boolean {
  const num = parseFloat(value.replace(/[^0-9.\-]/g, ''))
  if (isNaN(num)) return false
  return (value.includes('172') || value.includes('170')) && value.includes('x')
    ? true
    : Math.abs(num) > 100
}

function parseAllocation(alloc: AssetAllocation) {
  return [
    { name: 'Equity', key: 'equity', value: parseInt(alloc.equity), color: PIE_COLORS.equity },
    { name: 'Bond', key: 'bond', value: parseInt(alloc.bond), color: PIE_COLORS.bond },
    { name: 'Cash', key: 'cash', value: parseInt(alloc.cash), color: PIE_COLORS.cash },
    { name: 'Hedge', key: 'hedge', value: parseInt(alloc.hedge), color: PIE_COLORS.hedge },
  ]
}

/* ═══════════════════════════════════════════════════════════════
   Sub-components
   ═══════════════════════════════════════════════════════════════ */

function SectionHeader({ icon: Icon, title, subtitle }: { icon: typeof AlertTriangle; title: string; subtitle?: string }) {
  return (
    <div className="flex items-center gap-2 mb-5">
      <Icon className="h-5 w-5 text-gray-400" />
      <div>
        <h2 className="text-lg font-semibold text-gray-100">{title}</h2>
        {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
      </div>
    </div>
  )
}

function QuantEvidenceCard({ evidence }: { evidence: string }) {
  return (
    <div className="mt-3 rounded-lg border border-red-500/20 bg-red-500/5 px-4 py-3">
      <div className="flex items-center gap-2 mb-1">
        <BarChart3 className="h-3.5 w-3.5 text-red-500" />
        <span className="text-[11px] font-bold tracking-wider text-red-500 uppercase">量化证据</span>
      </div>
      <p className="text-sm font-mono text-red-400">{evidence}</p>
    </div>
  )
}

function QuantDataTable({ data }: { data: QuantDataItem[] }) {
  if (!data || data.length === 0) return null
  return (
    <div className="mt-4 overflow-x-auto rounded-lg border border-gray-800">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-gray-800/50">
            <th className="px-3 py-2 text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase">指标</th>
            <th className="px-3 py-2 text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase">当前值</th>
            <th className="px-3 py-2 text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase">对比基准</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => {
            const abnormal = isValueAnomalous(row.value)
            const comparison = row.peerAvg || row.historical || row.trend || row.normal || row.target || row.current || row.compatible || row.preCovid || row.recovery || row.firstTime || row.Scurve || row.impact || row.potential || row.BYD || row.threshold || row.lesson || '—'
            return (
              <tr key={i} className="border-t border-gray-800 hover:bg-gray-800/30 transition-colors">
                <td className="px-3 py-2.5 text-gray-300 font-medium">{row.metric}</td>
                <td className={cn('px-3 py-2.5 font-mono font-bold', abnormal ? 'text-red-400' : 'text-gray-100')}>
                  {row.value}
                </td>
                <td className="px-3 py-2.5 text-gray-500 text-xs">{comparison}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

function MonitoringChips({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  const items = useMemo(() => {
    return text.split(/[,;、，；]/).map(s => s.trim()).filter(Boolean)
  }, [text])

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }, [text])

  return (
    <div className="mt-3">
      <div className="flex items-center gap-2 mb-2">
        <Crosshair className="h-3.5 w-3.5 text-cyan-500" />
        <span className="text-[11px] font-bold tracking-wider text-cyan-500 uppercase">监测指标</span>
        <button
          onClick={handleCopy}
          className="ml-auto flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] text-gray-500 hover:text-gray-300 hover:bg-gray-800 transition-colors"
        >
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? '已复制' : '复制'}
        </button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {items.map((item, i) => (
          <span
            key={i}
            className="rounded-md bg-cyan-500/10 border border-cyan-500/20 px-2 py-1 text-[11px] text-cyan-400 font-mono"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  )
}

function SeverityBadge({ severity }: { severity: string }) {
  const sev = getSeverityColor(severity)
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-bold tracking-wider border', sev.bg, sev.text, sev.border)}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: sev.dot }} />
      {sev.label}
    </span>
  )
}

function PieChartIcon(props: Omit<React.SVGProps<SVGSVGElement>, 'onClick'>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
      <path d="M22 12A10 10 0 0 0 12 2v10z" />
    </svg>
  )
}

function SectionCard({ children, className, borderAccent }: { children: ReactNode; className?: string; borderAccent?: string }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: easeOut }}
      className={cn('rounded-xl border border-gray-800 bg-gray-900/50 p-6 relative overflow-hidden', className)}
      style={borderAccent ? { borderLeft: `3px solid ${borderAccent}` } : undefined}
    >
      {children}
    </motion.section>
  )
}

/* ═══════════════════════════════════════════════════════════════
   TOC Navigation
   ═══════════════════════════════════════════════════════════════ */

const TOC_ITEMS = [
  { id: 'thesis', label: '反向论点', icon: AlertTriangle },
  { id: 'refutations', label: '逐条反驳', icon: ShieldAlert },
  { id: 'blindspots', label: '盲点矩阵', icon: EyeOff },
  { id: 'scenarios', label: '替代情景', icon: GitBranch },
  { id: 'probability', label: '概率修正', icon: ArrowLeftRight },
  { id: 'positions', label: '反向对冲', icon: Target },
  { id: 'stresstest', label: '压力测试', icon: Activity },
]

function TOC() {
  const [active, setActive] = useState('thesis')

  useEffect(() => {
    const handleScroll = () => {
      const sections = TOC_ITEMS.map(item => {
        const el = document.getElementById(item.id)
        if (!el) return { id: item.id, top: Infinity }
        const rect = el.getBoundingClientRect()
        return { id: item.id, top: Math.abs(rect.top) }
      })
      const closest = sections.reduce((a, b) => (a.top < b.top ? a : b))
      if (closest.top < 300) setActive(closest.id)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div className="hidden xl:flex flex-col fixed left-4 top-1/2 -translate-y-1/2 z-40 gap-1">
      <div className="rounded-xl border border-gray-800 bg-gray-900/90 backdrop-blur-sm p-2 shadow-2xl">
        {TOC_ITEMS.map(item => {
          const isActive = active === item.id
          return (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className={cn(
                'flex items-center gap-2 w-full rounded-lg px-3 py-2 text-xs transition-all duration-200',
                isActive
                  ? 'bg-red-500/10 text-red-400 font-medium'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'
              )}
            >
              <item.icon className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden 2xl:inline whitespace-nowrap">{item.label}</span>
              {isActive && <motion.div layoutId="toc-dot" className="ml-auto h-1.5 w-1.5 rounded-full bg-red-500" />}
            </button>
          )
        })}
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════════════════════════ */

export default function Devil() {
  const [data, setData] = useState<DevilData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [openRefutations, setOpenRefutations] = useState<Set<string>>(new Set())

  useEffect(() => {
    let cancelled = false
    fetch('/data/devil_enhanced.json')
      .then(async r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((d: DevilData) => {
        if (!cancelled) {
          setData(d)
          setLoading(false)
        }
      })
      .catch(err => {
        if (!cancelled) {
          setError(err.message)
          setLoading(false)
        }
      })
    return () => { cancelled = true }
  }, [])

  const toggleRefutation = useCallback((id: string) => {
    setOpenRefutations(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  if (loading) {
    return (
      <div className="flex min-h-[60dvh] items-center justify-center">
        <div className="text-gray-500 font-mono text-sm animate-pulse">加载反驳者分析...</div>
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="flex min-h-[60dvh] items-center justify-center">
        <div className="text-red-400 font-mono text-sm">加载失败: {error || '未知错误'}</div>
      </div>
    )
  }

  const {
    contrarianThesis,
    refutations,
    blindSpots,
    alternativeScenarios,
    probabilityCorrections,
    contrarianPositions,
    stressTest,
    meta,
  } = data

  return (
    <div className="min-h-[100dvh] bg-gray-950 text-gray-100">
      <TOC />
      <div className="xl:ml-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 pb-20">

        {/* ═══════════════ HERO ═══════════════ */}
        <section id="thesis" className="relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: easeOut }}
          >
            <div
              className="relative rounded-xl p-8 md:p-10 border border-gray-800"
              style={{ background: 'radial-gradient(ellipse at 50% 50%, rgba(239,68,68,0.06) 0%, transparent 70%)' }}
            >
              <div className="flex items-center gap-3 mb-3">
                <AlertTriangle className="h-6 w-6 text-red-500" />
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-red-500" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  反驳者
                </h1>
              </div>
              <h2 className="text-xl font-bold text-gray-400 mb-4">
                对 conviction 进行压力测试
              </h2>
              <p className="text-sm leading-relaxed text-gray-400 max-w-2xl">
                系统中的每一项分析都会在这里受到挑战。反驳者Agent故意寻找反对我们仓位的证据，以识别盲点并防止确认偏误。
                这些都是蓄意的反论——不是基准情景。
              </p>
              <p className="mt-4 text-[11px] font-medium tracking-widest text-gray-600 uppercase">
                生成时间: {meta.generatedAt.replace('T', ' ').replace('Z', '')}
              </p>
            </div>
          </motion.div>
        </section>

        {/* ═══════════════ 反向论点摘要 ═══════════════ */}
        <SectionCard borderAccent="#EF4444">
          <div className="flex items-center gap-2 mb-4">
            <ShieldAlert className="h-5 w-5 text-red-500" />
            <span className="text-xs font-bold tracking-widest text-red-500 uppercase">反向论点</span>
            <span className="ml-auto text-xs font-mono text-gray-500">
              置信度: <span className="text-red-400 font-bold">{contrarianThesis.confidence}%</span>
            </span>
          </div>
          <p className="text-lg md:text-xl font-bold text-gray-100 leading-snug">
            {contrarianThesis.statement}
          </p>
          <div className="mt-6 space-y-4">
            {contrarianThesis.bullets.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.1, duration: 0.4, ease: easeOut }}
                className="rounded-lg border border-gray-800 bg-gray-800/30 p-4"
              >
                <div className="flex gap-3">
                  <span className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-red-500" />
                  <div className="flex-1">
                    <span className="text-sm font-bold text-gray-100">{b.lead}</span>
                    <p className="text-sm text-gray-400 mt-1 leading-relaxed">{b.explanation}</p>
                    <QuantEvidenceCard evidence={b.quantEvidence} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </SectionCard>

        {/* ═══════════════ 逐条反驳 ═══════════════ */}
        <section id="refutations">
          <SectionHeader icon={ShieldAlert} title="逐条反驳" subtitle="点击展开查看完整论证与量化数据" />
          <div className="space-y-4">
            {refutations.map((ref, idx) => {
              const sev = getSeverityColor(ref.severity)
              const isOpen = openRefutations.has(ref.id)
              return (
                <motion.div
                  key={ref.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + idx * 0.06, duration: 0.4, ease: easeOut }}
                >
                  <Collapsible open={isOpen} onOpenChange={() => toggleRefutation(ref.id)}>
                    <div className="rounded-xl border border-gray-800 bg-gray-900/50 overflow-hidden" style={{ borderLeft: `3px solid ${sev.dot}` }}>
                      <CollapsibleTrigger asChild>
                        <button className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-800/50 transition-colors duration-200">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 flex-1 min-w-0">
                            <span className="text-base font-semibold text-gray-100">{ref.topic}</span>
                            <div className="flex flex-wrap gap-2">
                              <span className="text-[11px] font-medium tracking-wider px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                我方: {ref.systemView}
                              </span>
                              <span className="text-[11px] font-medium tracking-wider px-2.5 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                                反驳: {ref.contrarianView}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 shrink-0 ml-3">
                            <SeverityBadge severity={ref.severity} />
                            <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.3, ease: easeOut }}>
                              <ChevronDown className="h-5 w-5 text-gray-500" />
                            </motion.div>
                          </div>
                        </button>
                      </CollapsibleTrigger>

                      <CollapsibleContent>
                        <AnimatePresence>
                          {isOpen && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.3, ease: easeOut }}
                              className="px-5 pb-5 space-y-4 overflow-hidden"
                            >
                              {/* System Argument */}
                              <div className="rounded-lg p-4 border-l-[3px] border-emerald-500 bg-emerald-500/5">
                                <p className="text-sm font-bold text-gray-100 mb-2 flex items-center gap-2">
                                  <span className="text-emerald-500">+</span>
                                  {ref.systemArgument.title}
                                </p>
                                <ul className="space-y-1.5">
                                  {ref.systemArgument.bullets.map((b, i) => (
                                    <li key={i} className="text-sm text-gray-400 flex gap-2">
                                      <span className="text-emerald-500">+</span>
                                      {b}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Contrarian Rebuttal */}
                              <div className="rounded-lg p-4 border-l-[3px] border-red-500 bg-red-500/5">
                                <p className="text-sm font-bold text-gray-100 mb-2 flex items-center gap-2">
                                  <span className="text-red-500">−</span>
                                  {ref.contrarianRebuttal.title}
                                </p>
                                <ul className="space-y-1.5">
                                  {ref.contrarianRebuttal.bullets.map((b, i) => (
                                    <li key={i} className="text-sm text-gray-400 flex gap-2">
                                      <span className="text-red-500">−</span>
                                      {b}
                                    </li>
                                  ))}
                                </ul>
                                {ref.contrarianRebuttal.quantData && (
                                  <QuantDataTable data={ref.contrarianRebuttal.quantData} />
                                )}
                              </div>

                              {/* Blind Spot */}
                              <div className="rounded-lg p-4 border-l-[3px] border-yellow-500 bg-yellow-500/5">
                                <p className="text-sm text-gray-100">
                                  <span className="font-bold text-yellow-500">盲点: </span>
                                  {ref.blindSpot}
                                </p>
                              </div>

                              {/* Monitoring Indicators */}
                              <MonitoringChips text={ref.monitoringIndicator} />

                              {/* Probability Adjustment */}
                              <p className="text-sm text-gray-500 font-mono">
                                概率调整: <span className="text-gray-300">{ref.probabilityAdjustment}</span>
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </CollapsibleContent>
                    </div>
                  </Collapsible>
                </motion.div>
              )
            })}
          </div>
        </section>

        {/* ═══════════════ 盲点矩阵 ═══════════════ */}
        <section id="blindspots">
          <SectionCard>
            <SectionHeader icon={EyeOff} title="盲点矩阵" subtitle="系统可能忽视的结构性风险" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {blindSpots.map((spot, idx) => {
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + idx * 0.08, duration: 0.4, ease: easeOut }}
                    className="rounded-lg border border-gray-800 bg-gray-800/30 p-4 hover:bg-gray-800/50 transition-colors duration-200"
                  >
                    <span className="text-[11px] font-medium tracking-wider text-gray-500 uppercase">
                      {spot.category}
                    </span>
                    <div className="mt-2 flex items-center justify-between">
                      <p className="text-sm font-bold text-gray-100">{spot.name}</p>
                      <SeverityBadge severity={spot.severity} />
                    </div>
                    <p className="mt-2 text-sm text-gray-400 leading-relaxed">{spot.description}</p>
                    <p className="mt-3 text-xs text-gray-500">
                      <span className="text-yellow-500 font-medium">应对措施: </span>
                      {spot.mitigation}
                    </p>
                    <MonitoringChips text={spot.monitoringIndicator} />
                  </motion.div>
                )
              })}
            </div>
          </SectionCard>
        </section>

        {/* ═══════════════ 替代情景 ═══════════════ */}
        <section id="scenarios">
          <SectionCard>
            <SectionHeader icon={GitBranch} title="替代情景" subtitle="三种情景下的资产配置与关键资产" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {alternativeScenarios.map((scenario, idx) => {
                const topBorder = idx === 0 ? '#EF4444' : idx === 1 ? '#F59E0B' : '#3B82F6'
                const alloc = parseAllocation(scenario.assetAllocation)
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + idx * 0.12, duration: 0.5, ease: easeOut }}
                    className="rounded-lg border border-gray-800 bg-gray-800/30 relative overflow-hidden"
                    style={{ borderTop: `3px solid ${topBorder}` }}
                  >
                    <div className="p-5">
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="text-base font-semibold text-gray-100 pr-16">{scenario.title}</h3>
                        <motion.span
                          initial={{ opacity: 0, scale: 0.5 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.3 + idx * 0.1, duration: 0.4 }}
                          className="absolute top-4 right-4 text-sm font-bold font-mono text-gray-100 bg-gray-800 px-2.5 py-1 rounded-full"
                        >
                          {scenario.probability}%
                        </motion.span>
                      </div>
                      <p className="text-sm text-gray-400 mb-3">
                        <span className="text-gray-500">触发条件: </span>
                        {scenario.trigger}
                      </p>
                      <div className="space-y-1.5 mb-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">S&P 500</span>
                          <span className="font-mono text-red-400">{scenario.marketImpact.sp500}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">VIX</span>
                          <span className="font-mono text-orange-400">{scenario.marketImpact.vix}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">10Y Yield</span>
                          <span className="font-mono text-emerald-400">{scenario.marketImpact.yield10y}</span>
                        </div>
                      </div>
                      <p className="text-sm text-yellow-400 mb-2">
                        <span className="text-gray-500">对冲: </span>
                        {scenario.hedge}
                      </p>
                      <p className="text-[11px] text-gray-500 tracking-wider uppercase">
                        {scenario.historicalParallel}
                      </p>

                      {/* Asset Allocation Pie */}
                      <div className="mt-4 pt-4 border-t border-gray-800">
                        <div className="flex items-center gap-2 mb-2">
                          <PieChartIcon className="h-3.5 w-3.5 text-blue-500" />
                          <span className="text-[11px] font-bold tracking-wider text-blue-500 uppercase">资产配置</span>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="h-24 w-24 shrink-0">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie data={alloc} cx="50%" cy="50%" innerRadius={18} outerRadius={40} paddingAngle={2} dataKey="value" stroke="none">
                                  {alloc.map((entry, i) => (
                                    <Cell key={`cell-${i}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip
                                  contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px', fontSize: '12px', color: '#e5e7eb' }}
                                  formatter={(value: number) => [`${value}%`, '']}
                                />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                            {alloc.map(d => (
                              <div key={d.key} className="flex items-center gap-1.5">
                                <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: d.color }} />
                                <span className="text-[11px] text-gray-400">{d.name}</span>
                                <span className="text-[11px] font-mono font-bold text-gray-200">{d.value}%</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Key Assets */}
                      <div className="mt-3 pt-3 border-t border-gray-800">
                        <div className="flex items-center gap-2 mb-2">
                          <Target className="h-3.5 w-3.5 text-emerald-500" />
                          <span className="text-[11px] font-bold tracking-wider text-emerald-500 uppercase">关键资产</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {scenario.keyAssets.map((asset, i) => (
                            <span key={i} className="rounded-md bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[11px] text-emerald-400 font-mono">
                              {asset}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </SectionCard>
        </section>

        {/* ═══════════════ 概率修正 ═══════════════ */}
        <section id="probability">
          <SectionCard>
            <SectionHeader icon={ArrowLeftRight} title="概率修正表" subtitle="基准概率 → 调整 → 最终概率" />
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-800/50">
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3 rounded-tl-lg">情景</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3">基准</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3">调整</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3">最终</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3 w-48">变动</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-4 py-3 rounded-tr-lg">理由</th>
                  </tr>
                </thead>
                <tbody>
                  {probabilityCorrections.map((row, idx) => {
                    const isUp = row.adjustment > 0
                    return (
                      <motion.tr
                        key={idx}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 + idx * 0.06, duration: 0.4, ease: easeOut }}
                        className="border-t border-gray-800 hover:bg-gray-800/30 transition-colors"
                      >
                        <td className="px-4 py-3 text-sm text-gray-100 font-medium">{row.scenario}</td>
                        <td className="px-4 py-3 text-sm font-mono text-gray-500">{row.baseline}%</td>
                        <td className={cn('px-4 py-3 text-sm font-mono font-bold', isUp ? 'text-red-400' : 'text-emerald-400')}>
                          {isUp ? '+' : ''}{row.adjustment}%
                        </td>
                        <td className="px-4 py-3 text-sm font-mono font-bold text-gray-100">{row.final}%</td>
                        <td className="px-4 py-3">
                          <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${(row.baseline / 60) * 100}%` }}
                              transition={{ delay: 0.3 + idx * 0.06, duration: 0.6, ease: easeOut }}
                              className="absolute top-0 left-0 h-full bg-gray-600 rounded-full"
                            />
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${(Math.abs(row.final) / 60) * 100}%` }}
                              transition={{ delay: 0.5 + idx * 0.06, duration: 0.8, ease: easeOut }}
                              className={cn('absolute top-0 left-0 h-full rounded-full opacity-80', isUp ? 'bg-red-500' : 'bg-emerald-500')}
                            />
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ delay: 0.7 + idx * 0.06, duration: 0.3 }}
                              className="absolute top-1/2 -translate-y-1/2 text-[9px] font-mono font-bold text-white drop-shadow"
                              style={{ left: `${Math.min((Math.abs(row.final) / 60) * 100, 90)}%` }}
                            >
                              {row.final}%
                            </motion.div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-400">{row.rationale}</td>
                      </motion.tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </section>

        {/* ═══════════════ 反向对冲建议 ═══════════════ */}
        <section id="positions">
          <SectionCard borderAccent="#EF4444">
            <SectionHeader icon={Target} title="反向对冲建议" subtitle="入场区间 · 目标价位 · 止损条件" />
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-800/50">
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3 rounded-tl-lg">类型</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">资产</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">方向</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">入场区间</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">目标</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">止损</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3">配置</th>
                    <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-3 rounded-tr-lg">信心</th>
                  </tr>
                </thead>
                <tbody>
                  {contrarianPositions.map((pos, idx) => {
                    const typeLabel = pos.type === 'HEDGE' ? '对冲' : pos.type === 'DIRECTIONAL' ? '方向性' : '逆向押注'
                    return (
                      <motion.tr
                        key={idx}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 + idx * 0.08, duration: 0.4, ease: easeOut }}
                        className="border-t border-gray-800 hover:bg-gray-800/30 transition-colors"
                      >
                        <td className="px-3 py-3">
                          <span className={cn(
                            'text-[11px] font-bold tracking-wider px-2 py-0.5 rounded-full',
                            pos.type === 'HEDGE' ? 'bg-orange-500/10 text-orange-400' : 'bg-red-500/10 text-red-400'
                          )}>
                            {typeLabel}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <p className="text-sm font-bold text-gray-100">{pos.asset}</p>
                          <p className="text-xs text-gray-500 mt-0.5 max-w-xs">{pos.rationale}</p>
                        </td>
                        <td className="px-3 py-3">
                          <span className={cn('text-xs font-mono', pos.direction.includes('做空') ? 'text-red-400' : 'text-emerald-400')}>
                            {pos.direction}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-xs font-mono text-cyan-400">{pos.entryZone}</td>
                        <td className="px-3 py-3 text-xs font-mono text-emerald-400">{pos.target}</td>
                        <td className="px-3 py-3 text-xs font-mono text-red-400">{pos.stop}</td>
                        <td className="px-3 py-3 text-xs text-gray-400">{pos.sizing}</td>
                        <td className="px-3 py-3">
                          <span className={cn(
                            'text-xs font-bold',
                            pos.conviction === 'High' ? 'text-red-400' : pos.conviction === 'Medium' ? 'text-orange-400' : 'text-gray-400'
                          )}>
                            {pos.conviction}
                          </span>
                        </td>
                      </motion.tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            <p className="mt-4 text-sm text-gray-500 italic">
              这些是蓄意的反向头寸，旨在对冲核心组合风险。如果基准情景实现，它们可能跑输大盘。
            </p>
          </SectionCard>
        </section>

        {/* ═══════════════ 压力测试 ═══════════════ */}
        <section id="stresstest">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: easeOut }}
          >
            <div className="flex items-center gap-2 mb-6">
              <Activity className="h-5 w-5 text-red-500" />
              <h2 className="text-lg font-semibold text-gray-100">压力测试模块</h2>
              <span className="text-[11px] font-bold tracking-wider text-red-500 uppercase bg-red-500/10 px-2 py-0.5 rounded-full border border-red-500/20">NEW</span>
            </div>

            {/* 单标的冲击测试 */}
            <div className="rounded-xl border border-gray-800 bg-gray-900/50 p-6 mb-6">
              <div className="flex items-center gap-2 mb-5">
                <TrendingDown className="h-5 w-5 text-orange-500" />
                <h3 className="text-base font-semibold text-gray-100">单标的冲击测试</h3>
              </div>
              <div className="space-y-6">
                {stressTest.singleStockShocks.map((stock, sIdx) => (
                  <motion.div
                    key={stock.ticker}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + sIdx * 0.08, duration: 0.4, ease: easeOut }}
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-sm font-bold font-mono text-gray-100 bg-gray-800 px-2 py-0.5 rounded">{stock.ticker}</span>
                      <span className="text-sm text-gray-400">{stock.name}</span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-800/50">
                            <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-2 rounded-tl-lg">冲击幅度</th>
                            <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-2">触发条件</th>
                            <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-2">组合影响</th>
                            <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-2">恢复天数</th>
                            <th className="text-left text-[11px] font-medium tracking-wider text-gray-500 uppercase px-3 py-2 rounded-tr-lg">对冲建议</th>
                          </tr>
                        </thead>
                        <tbody>
                          {stock.scenarios.map((scenario, i) => (
                            <tr key={i} className="border-t border-gray-800 hover:bg-gray-800/30 transition-colors">
                              <td className="px-3 py-2.5">
                                <span
                                  className="text-sm font-mono font-bold px-2 py-0.5 rounded"
                                  style={{
                                    color: SHOCK_COLORS[scenario.shock] || '#EF4444',
                                    backgroundColor: `${SHOCK_COLORS[scenario.shock] || '#EF4444'}15`,
                                  }}
                                >
                                  {scenario.shock}
                                </span>
                              </td>
                              <td className="px-3 py-2.5 text-gray-400">{scenario.trigger}</td>
                              <td className="px-3 py-2.5 text-sm font-mono font-bold text-red-400">{scenario.portfolioImpact}</td>
                              <td className="px-3 py-2.5 text-sm font-mono text-orange-400">{scenario.daysToRecover}</td>
                              <td className="px-3 py-2.5 text-xs text-gray-400">{scenario.hedge}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* 板块冲击测试 */}
            <div className="rounded-xl border border-gray-800 bg-gray-900/50 p-6 mb-6">
              <div className="flex items-center gap-2 mb-5">
                <Zap className="h-5 w-5 text-yellow-500" />
                <h3 className="text-base font-semibold text-gray-100">板块冲击测试</h3>
              </div>
              <div className="space-y-4">
                {stressTest.sectorShocks.map((sector, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + idx * 0.08, duration: 0.4, ease: easeOut }}
                    className="rounded-lg border border-gray-800 bg-gray-800/30 p-4 hover:bg-gray-800/50 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-3">
                      <span className="text-sm font-bold text-gray-100">{sector.sector}</span>
                      <span className="text-sm font-mono font-bold text-red-400 bg-red-500/10 px-2 py-0.5 rounded">{sector.shock}</span>
                      <span className="text-xs text-gray-500">{sector.trigger}</span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div>
                        <span className="text-gray-500 text-xs">组合影响: </span>
                        <span className="font-mono font-bold text-red-400">{sector.portfolioImpact}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 text-xs">对冲: </span>
                        <span className="text-gray-400">{sector.hedge}</span>
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <span className="text-[11px] text-gray-500">受影响标的:</span>
                      {sector.affectedTickers.map(t => (
                        <span key={t} className="text-[11px] font-mono text-gray-300 bg-gray-700/50 px-1.5 py-0.5 rounded">{t}</span>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* 尾部风险情景 */}
            <div className="rounded-xl border border-gray-800 bg-gray-900/50 p-6">
              <div className="flex items-center gap-2 mb-5">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h3 className="text-base font-semibold text-gray-100">尾部风险情景</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {stressTest.tailRiskScenarios.map((risk, idx) => {
                  const probVal = parseInt(risk.probability)
                  const probColor = probVal >= 8 ? 'text-red-400' : probVal >= 5 ? 'text-orange-400' : 'text-yellow-400'
                  return (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 + idx * 0.1, duration: 0.5, ease: easeOut }}
                      className="rounded-lg border border-gray-800 bg-gray-800/30 p-5 relative overflow-hidden"
                    >
                      <div className="absolute top-0 left-0 right-0 h-1" style={{
                        background: probVal >= 8 ? '#DC2626' : probVal >= 5 ? '#F59E0B' : '#EAB308'
                      }} />
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="text-sm font-bold text-gray-100">{risk.name}</h4>
                        <span className={cn('text-sm font-mono font-bold', probColor)}>
                          {risk.probability}
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">S&P 500 影响</span>
                          <span className="font-mono font-bold text-red-400">{risk.sp500Impact}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">恢复时间</span>
                          <span className="font-mono text-orange-400">{risk.recovery}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">相关性变化</span>
                          <span className="text-gray-300">{risk.correlation}</span>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-gray-800">
                        <span className="text-[11px] text-gray-500">对冲策略: </span>
                        <span className="text-xs text-cyan-400">{risk.hedge}</span>
                      </div>
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </motion.div>
        </section>

        {/* Footer */}
        <div className="text-center text-[11px] text-gray-600 pt-8 border-t border-gray-800">
          <p>反驳者分析 v{meta.version} · 数据生成于 {meta.generatedAt.replace('T', ' ').replace('Z', '')}</p>
        </div>
      </div>
    </div>
  )
}
