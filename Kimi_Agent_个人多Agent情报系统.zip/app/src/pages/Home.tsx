import { useState } from 'react';
import AnalystConsensus from '@/components/AnalystConsensus';
import InstitutionalHoldings from '@/components/InstitutionalHoldings';
import { cn } from '@/lib/utils';

const TICKERS = ['NVDA', 'TSLA', 'AAPL', '0700.HK', 'MSFT'];

export default function Home() {
  const [activeTicker, setActiveTicker] = useState('NVDA');

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-gray-100">P2 可复用组件演示</h1>
            <p className="text-sm text-gray-500 mt-0.5">AnalystConsensus + InstitutionalHoldings</p>
          </div>
          <div className="flex items-center gap-2">
            {TICKERS.map((t) => (
              <button
                key={t}
                onClick={() => setActiveTicker(t)}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200',
                  activeTicker === t
                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800 border border-transparent'
                )}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Analyst Consensus Panel */}
          <section>
            <AnalystConsensus ticker={activeTicker} />
          </section>

          {/* Institutional Holdings Panel */}
          <section>
            <InstitutionalHoldings ticker={activeTicker} />
          </section>
        </div>
      </main>
    </div>
  );
}
