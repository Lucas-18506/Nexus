import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  Legend,
} from 'recharts';
import {
  PieChart,
  TrendingUp,
  TrendingDown,
  Activity,
  Minus,
  BarChart3,
  Target,
  ShieldAlert,
  Info,
  Award,
  Layers,
  Percent,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import DataCard from '@/components/DataCard';

/* ─────────────────────── types ─────────────────────── */

interface MonthlyReturn {
  month: string;
  portfolio: number;
  benchmark: number;
}

interface SectorAttribution {
  sector: string;
  allocation: number;
  contribution: number;
  selection: number;
  allocation_effect: number;
}

interface TopHolding {
  ticker: string;
  name: string;
  weight: number;
  contribution: number;
  alpha: number;
  pnl: number;
}

interface RiskMetrics {
  var95: number;
  var99: number;
  sortino: number;
  treynor: number;
  informationRatio: number;
  trackingError: number;
}

interface Summary {
  totalAum: number;
  currency: string;
  ytdReturn: number;
  q2Return: number;
  benchmark: string;
  benchmarkYtdReturn: number;
  alpha: number;
  beta: number;
  sharpeRatio: number;
  maxDrawdown: number;
  volatility: number;
  winRate: number;
  currentDrawdown: number;
}

interface PortfolioData {
  lastUpdate: string;
  summary: Summary;
  monthlyReturns: MonthlyReturn[];
  attribution: SectorAttribution[];
  topHoldings: TopHolding[];
  riskMetrics: RiskMetrics;
}

/* ─────────────────────── helpers ─────────────────────── */

const formatPercent = (v: number, digits = 1) => `${v >= 0 ? '+' : ''}${v.toFixed(digits)}%`;



/* ─────────────────────── Overview Card ─────────────────────── */

function OverviewCard({
  title,
  value,
  subLabel,
  subValue,
  isPositive,
  isNegative,
  icon: Icon,
  delay = 0,
}: {
  title: string;
  value: string;
  subLabel: string;
  subValue: string;
  isPositive?: boolean;
  isNegative?: boolean;
  icon: React.ElementType;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        delay,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className="rounded-radius-lg border border-border-subtle bg-bg-card p-space-5 card-gradient"
    >
      <div className="flex items-center gap-space-2 mb-space-3">
        <Icon size={16} className="text-gold-400" />
        <span className="text-xs uppercase tracking-[0.06em] text-text-tertiary font-medium">
          {title}
        </span>
      </div>
      <div className="font-mono text-[28px] font-bold text-text-primary tracking-tight">
        {value}
      </div>
      <div className="flex items-center gap-space-2 mt-space-2">
        {isPositive ? (
          <TrendingUp size={14} className="text-bullish" />
        ) : isNegative ? (
          <TrendingDown size={14} className="text-bearish" />
        ) : (
          <Minus size={14} className="text-text-tertiary" />
        )}
        <span className="text-sm text-text-secondary">{subLabel}</span>
        <span
          className={cn(
            'text-sm font-mono font-semibold',
            isPositive ? 'text-bullish' : isNegative ? 'text-bearish' : 'text-text-secondary'
          )}
        >
          {subValue}
        </span>
      </div>
    </motion.div>
  );
}

/* ─────────────────────── Risk Metric Card ─────────────────────── */

function RiskMetricCard({
  label,
  value,
  tooltip,
  delay = 0,
}: {
  label: string;
  value: string;
  tooltip: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.35,
        delay,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className="group relative rounded-radius-lg border border-border-subtle bg-bg-card p-space-4 card-gradient hover:border-border-medium transition-all duration-200"
    >
      <div className="flex items-center gap-space-1.5 mb-space-2">
        <span className="text-[10px] uppercase tracking-[0.06em] text-text-tertiary font-medium">
          {label}
        </span>
        <Info
          size={12}
          className="text-text-tertiary opacity-50 group-hover:opacity-100 transition-opacity"
        />
      </div>
      <div className="font-mono text-xl font-bold text-text-primary">{value}</div>
      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-radius-md bg-bg-elevated border border-border-subtle shadow-lg text-xs text-text-primary whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 z-50 max-w-[200px] whitespace-normal text-center">
        {tooltip}
      </div>
    </motion.div>
  );
}

/* ─────────────────────── Custom Bar Colors ─────────────────────── */



/* ─────────────────────── Main Component ─────────────────────── */

export default function Portfolio() {
  const [data, setData] = useState<PortfolioData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await fetch('/data/portfolio_performance.json');
        if (!res.ok) throw new Error(`portfolio_performance.json: ${res.status}`);
        const json: PortfolioData = await res.json();
        setData(json);
      } catch (err) {
        setError(err instanceof Error ? err.message : '数据加载失败');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div
          className="flex flex-col items-center gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Activity className="w-8 h-8 text-gold-400 animate-spin" />
          <span className="text-sm text-text-tertiary">加载组合绩效数据...</span>
        </motion.div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <ShieldAlert className="w-8 h-8 text-bearish" />
          <span className="text-sm text-text-tertiary">
            {error || '数据加载失败，请稍后重试'}
          </span>
        </div>
      </div>
    );
  }

  const { summary, monthlyReturns, attribution, topHoldings, riskMetrics } = data;

  // Compute total excess
  const totalExcess = summary.alpha;

  // Custom tooltip for monthly returns chart
  const MonthlyTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null;
    return (
      <div className="rounded-radius-md bg-bg-elevated border border-border-subtle shadow-lg px-3 py-2">
        <p className="text-xs text-text-secondary mb-1">{label}</p>
        {payload.map((entry: any, idx: number) => (
          <p key={idx} className="text-xs font-mono" style={{ color: entry.color }}>
            {entry.name}: {entry.value >= 0 ? '+' : ''}{entry.value.toFixed(2)}%
          </p>
        ))}
      </div>
    );
  };

  // Custom tooltip for horizontal bar chart
  const HoldingsTooltip = ({ active, payload }: any) => {
    if (!active || !payload || !payload.length) return null;
    const d = payload[0].payload;
    return (
      <div className="rounded-radius-md bg-bg-elevated border border-border-subtle shadow-lg px-3 py-2">
        <p className="text-xs font-semibold text-text-primary mb-1">{d.name} ({d.ticker})</p>
        <p className="text-xs font-mono text-text-secondary">权重: {d.weight}%</p>
        <p className="text-xs font-mono" style={{ color: d.contribution >= 0 ? '#10B981' : '#EF4444' }}>
          贡献度: {d.contribution >= 0 ? '+' : ''}{d.contribution}%
        </p>
        <p className="text-xs font-mono text-text-secondary">
          Alpha: {d.alpha >= 0 ? '+' : ''}{d.alpha}%
        </p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* ── Page Header ── */}
      <motion.div
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center gap-3">
          <PieChart size={22} className="text-gold-400" />
          <h1 className="text-xl font-bold text-text-primary tracking-tight">组合绩效归因</h1>
        </div>
        <span className="text-xs text-text-tertiary">
          最后更新: {new Date(data.lastUpdate).toLocaleString('zh-CN')}
        </span>
      </motion.div>

      {/* ── Row 1: 4 Overview Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <OverviewCard
          title="总AUM"
          value={`$${(summary.totalAum / 10000).toFixed(1)}亿`}
          subLabel="YTD收益"
          subValue={formatPercent(summary.ytdReturn)}
          isPositive={summary.ytdReturn >= 0}
          icon={Layers}
          delay={0}
        />
        <OverviewCard
          title="Alpha"
          value={formatPercent(summary.alpha)}
          subLabel="Beta"
          subValue={summary.beta.toFixed(2)}
          isPositive={summary.alpha >= 0}
          icon={Award}
          delay={0.05}
        />
        <OverviewCard
          title="夏普比率"
          value={summary.sharpeRatio.toFixed(2)}
          subLabel="最大回撤"
          subValue={formatPercent(summary.maxDrawdown)}
          isPositive={summary.sharpeRatio >= 1}
          isNegative={summary.maxDrawdown < -5}
          icon={Target}
          delay={0.1}
        />
        <OverviewCard
          title="波动率"
          value={`${summary.volatility.toFixed(1)}%`}
          subLabel="胜率"
          subValue={`${summary.winRate.toFixed(1)}%`}
          icon={Percent}
          delay={0.15}
        />
      </div>

      {/* ── Row 2: Monthly Returns Comparison Chart ── */}
      <DataCard
        title="月度收益对比（组合 vs 基准）"
        subtitle="组合收益 vs S&P 500 月度表现"
        delay={0.2}
      >
        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyReturns}
              margin={{ top: 20, right: 30, left: 10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis
                dataKey="month"
                tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'JetBrains Mono' }}
                tickFormatter={(v) => {
                  const d = new Date(v + '-01');
                  return `${d.getMonth() + 1}月`;
                }}
                axisLine={{ stroke: 'rgba(255,255,255,0.08)' }}
              />
              <YAxis
                tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'JetBrains Mono' }}
                tickFormatter={(v) => `${v}%`}
                axisLine={{ stroke: 'rgba(255,255,255,0.08)' }}
              />
              <Tooltip content={<MonthlyTooltip />} />
              <Legend
                wrapperStyle={{ fontSize: 12, color: '#94A3B8' }}
                formatter={(value: string) => (
                  <span style={{ color: '#94A3B8' }}>{value}</span>
                )}
              />
              <Bar dataKey="portfolio" name="组合收益" radius={[4, 4, 0, 0]}>
                {monthlyReturns.map((entry, index) => (
                  <Cell
                    key={`p-${index}`}
                    fill={entry.portfolio >= 0 ? '#3B82F6' : '#EF4444'}
                  />
                ))}
              </Bar>
              <Bar dataKey="benchmark" name="基准 S&P 500" radius={[4, 4, 0, 0]}>
                {monthlyReturns.map((entry, index) => (
                  <Cell
                    key={`b-${index}`}
                    fill={entry.benchmark >= 0 ? '#64748B' : '#94A3B8'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </DataCard>

      {/* ── Row 3: Brinson Attribution Table ── */}
      <DataCard
        title="行业归因分析（Brinson模型）"
        subtitle="选股效应 + 配置效应 = 总超额收益"
        delay={0.3}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px]">
            <thead>
              <tr className="bg-[#1c1f2a]">
                {['行业', '配置比例', '收益贡献', '选股效应', '配置效应', '总超额'].map(
                  (col) => (
                    <th
                      key={col}
                      className="text-[10px] uppercase tracking-[0.06em] text-text-tertiary text-left px-4 py-3 font-medium"
                    >
                      {col}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {attribution.map((row, index) => {
                const total = row.selection + row.allocation_effect;
                return (
                  <motion.tr
                    key={row.sector}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{
                      duration: 0.3,
                      delay: 0.4 + index * 0.05,
                      ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
                    }}
                    className={cn(
                      'border-b border-border-subtle/60',
                      index % 2 === 0 ? 'bg-transparent' : 'bg-[rgba(35,40,55,0.35)]'
                    )}
                  >
                    <td className="px-4 py-3">
                      <span className="text-sm font-medium text-text-primary">
                        {row.sector}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm font-mono text-text-secondary">
                        {row.allocation}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'text-sm font-mono font-medium',
                          row.contribution >= 0 ? 'text-bullish' : 'text-bearish'
                        )}
                      >
                        {row.contribution >= 0 ? '+' : ''}
                        {row.contribution.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'text-sm font-mono',
                          row.selection >= 0 ? 'text-bullish' : 'text-bearish'
                        )}
                      >
                        {row.selection >= 0 ? '+' : ''}
                        {row.selection.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'text-sm font-mono',
                          row.allocation_effect >= 0 ? 'text-bullish' : 'text-bearish'
                        )}
                      >
                        {row.allocation_effect >= 0 ? '+' : ''}
                        {row.allocation_effect.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'text-sm font-mono font-semibold',
                          total >= 0 ? 'text-bullish' : 'text-bearish'
                        )}
                      >
                        {total >= 0 ? '+' : ''}
                        {total.toFixed(1)}%
                      </span>
                    </td>
                  </motion.tr>
                );
              })}
              {/* Summary Row */}
              <tr className="bg-[rgba(212,175,55,0.08)] border-t-2 border-gold-400/40">
                <td className="px-4 py-3">
                  <span className="text-sm font-bold text-gold-400">汇总</span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm font-mono font-bold text-text-primary">100%</span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm font-mono font-bold text-text-primary">
                    {attribution.reduce((s, r) => s + r.contribution, 0).toFixed(1)}%
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm font-mono font-bold text-bullish">
                    +
                    {attribution.reduce((s, r) => s + r.selection, 0).toFixed(1)}%
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      'text-sm font-mono font-bold',
                      attribution.reduce((s, r) => s + r.allocation_effect, 0) >= 0
                        ? 'text-bullish'
                        : 'text-bearish'
                    )}
                  >
                    {attribution.reduce((s, r) => s + r.allocation_effect, 0) >= 0 ? '+' : ''}
                    {attribution.reduce((s, r) => s + r.allocation_effect, 0).toFixed(1)}%
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm font-mono font-bold text-gold-400">
                    +{totalExcess.toFixed(1)}% (Alpha)
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </DataCard>

      {/* ── Row 4: TOP5 Holdings + Risk Metrics ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* TOP5 Holdings */}
        <DataCard
          title="TOP5持仓贡献度"
          subtitle="按超额贡献排序"
          delay={0.4}
        >
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[...topHoldings].sort((a, b) => b.contribution - a.contribution)}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" horizontal={false} />
                <XAxis
                  type="number"
                  tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'JetBrains Mono' }}
                  tickFormatter={(v) => `${v}%`}
                  axisLine={{ stroke: 'rgba(255,255,255,0.08)' }}
                />
                <YAxis
                  type="category"
                  dataKey="ticker"
                  tick={{ fill: '#94A3B8', fontSize: 12, fontFamily: 'JetBrains Mono' }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.08)' }}
                />
                <Tooltip content={<HoldingsTooltip />} />
                <Legend
                  wrapperStyle={{ fontSize: 12, color: '#94A3B8' }}
                  formatter={(value: string) => (
                    <span style={{ color: '#94A3B8' }}>{value}</span>
                  )}
                />
                <Bar dataKey="contribution" name="贡献度(%)" radius={[0, 4, 4, 0]}>
                  {topHoldings.map((entry, index) => (
                    <Cell
                      key={`h-${index}`}
                      fill={entry.contribution >= 0 ? '#10B981' : '#EF4444'}
                    />
                  ))}
                </Bar>
                <Bar dataKey="weight" name="权重(%)" fill="#3B82F6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Holdings detail table */}
          <div className="mt-4 space-y-2">
            {topHoldings.map((h, i) => (
              <motion.div
                key={h.ticker}
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.04, duration: 0.3 }}
                className="flex items-center justify-between py-1.5 border-b border-border-subtle/40 last:border-0"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm font-mono font-semibold text-text-primary w-20">
                    {h.ticker}
                  </span>
                  <span className="text-xs text-text-secondary">{h.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-text-secondary">权重 {h.weight}%</span>
                  <span
                    className={cn(
                      'text-xs font-mono font-medium',
                      h.contribution >= 0 ? 'text-bullish' : 'text-bearish'
                    )}
                  >
                    {h.contribution >= 0 ? '+' : ''}{h.contribution}%
                  </span>
                  <span
                    className={cn(
                      'text-xs font-mono',
                      h.alpha >= 0 ? 'text-bullish' : 'text-bearish'
                    )}
                  >
                    {' '}Alpha {h.alpha >= 0 ? '+' : ''}{h.alpha}%
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </DataCard>

        {/* Risk Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.4,
            delay: 0.45,
            ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
          }}
          className="space-y-4"
        >
          <div className="flex items-center gap-2 mb-2">
            <ShieldAlert size={16} className="text-gold-400" />
            <h2 className="text-sm font-semibold text-text-primary">风险指标</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <RiskMetricCard
              label="VaR 95%"
              value={`${riskMetrics.var95.toFixed(1)}%`}
              tooltip="在95%置信水平下，单日最大可能损失"
              delay={0.5}
            />
            <RiskMetricCard
              label="VaR 99%"
              value={`${riskMetrics.var99.toFixed(1)}%`}
              tooltip="在99%置信水平下，单日最大可能损失"
              delay={0.55}
            />
            <RiskMetricCard
              label="Sortino比率"
              value={riskMetrics.sortino.toFixed(1)}
              tooltip="下行风险调整后的收益比率，仅考虑负向波动"
              delay={0.6}
            />
            <RiskMetricCard
              label="Treynor比率"
              value={riskMetrics.treynor.toFixed(1)}
              tooltip="每单位系统性风险（Beta）所获得的超额收益"
              delay={0.65}
            />
            <RiskMetricCard
              label="信息比率"
              value={riskMetrics.informationRatio.toFixed(1)}
              tooltip="主动收益与跟踪误差的比值，衡量主动管理能力"
              delay={0.7}
            />
            <RiskMetricCard
              label="跟踪误差"
              value={`${riskMetrics.trackingError.toFixed(1)}%`}
              tooltip="组合收益与基准收益差异的标准差"
              delay={0.75}
            />
          </div>

          {/* Performance Summary Card */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.35,
              delay: 0.8,
              ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
            }}
            className="rounded-radius-lg border border-border-subtle bg-bg-card p-space-5 card-gradient mt-6"
          >
            <div className="flex items-center gap-2 mb-space-3">
              <BarChart3 size={16} className="text-gold-400" />
              <h3 className="text-sm font-semibold text-text-primary">绩效总结</h3>
            </div>
            <div className="space-y-3">
              <p className="text-sm text-text-secondary leading-relaxed">
                组合本年跑赢基准 <span className="text-bullish font-mono font-semibold">+{summary.alpha.toFixed(1)}%</span>，
                主要超额来自科技行业的选股能力（NVDA贡献
                <span className="text-bullish font-mono font-semibold">+3.2%</span>），
                但特斯拉拖累
                <span className="text-bearish font-mono font-semibold">-0.8%</span>。
              </p>
              <div className="flex items-center gap-2 pt-2 border-t border-border-subtle">
                <TrendingUp size={14} className="text-bullish" />
                <span className="text-xs text-text-tertiary">
                  夏普比率 {summary.sharpeRatio.toFixed(2)} · 信息比率 {riskMetrics.informationRatio.toFixed(1)} · 跟踪误差 {riskMetrics.trackingError.toFixed(1)}%
                </span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
