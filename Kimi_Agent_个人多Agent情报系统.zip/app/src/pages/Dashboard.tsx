import { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  ResponsiveContainer,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Activity,
  Globe,
  AlertTriangle,
  FileText,
  Zap,
  BarChart3,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import QuoteTicker from '@/components/QuoteTicker';
import MarketClock from '@/components/MarketClock';
import SmartAlerts from '@/components/SmartAlerts';
import ExportButton from '@/components/ExportButton';

/* ─────────────────────── types ─────────────────────── */

interface Dimension {
  name: string;
  score: number;
  label: string;
  description: string;
}

interface SupportingIndex {
  name: string;
  value: number;
  change: number;
}

interface Verdict {
  market: string;
  verdict: string;
  icon: string;
  score: number;
  indexName: string;
  indexValue: number;
  indexChange: number;
  supportingIndices: SupportingIndex[];
  keyDrivers: string[];
  riskFlags: string[];
}

interface SentimentData {
  overallScore: number;
  overallLabel: string;
  lastUpdate: string;
  history: number[];
  dimensions: Dimension[];
  verdicts: Verdict[];
  subGauges: Record<string, { score: number; label: string }>;
}

interface TimingSignal {
  asset: string;
  signal: string;
  entry: string;
  target: string;
  stop: string;
  riskReward: string;
  trend: number[];
}

interface Sector {
  name: string;
  change: number;
  momentumScore: number;
  topMover: string;
}

interface DashboardData {
  lastUpdate: string;
  systemStatus: string;
  briefing: string;
  briefingSource: string;
  timingSignals: TimingSignal[];
  sectorMomentum: Sector[];
}

/* ─────────────────────── helpers ─────────────────────── */

const getLabelForScore = (score: number): string => {
  if (score <= 20) return '极度恐惧';
  if (score <= 40) return '恐惧';
  if (score <= 60) return '中性';
  if (score <= 80) return '贪婪';
  return '极度贪婪';
};

const getColorForScore = (score: number): string => {
  if (score <= 20) return '#EF4444';
  if (score <= 40) return '#F97316';
  if (score <= 60) return '#F59E0B';
  if (score <= 80) return '#34D399';
  return '#10B981';
};

const getSignalColor = (signal: string): string => {
  const s = signal.toUpperCase();
  if (s === 'BULLISH' || s === 'BUY') return '#10B981';
  if (s === 'BEARISH' || s === 'SELL') return '#EF4444';
  return '#9CA3AF';
};

const getVerdictConfig = (verdict: string) => {
  const v = verdict.toLowerCase();
  if (v === 'bullish' || v === 'buy' || v === 'add')
    return {
      bg: 'bg-[rgba(16,185,129,0.12)]',
      text: 'text-[#10B981]',
      border: 'border-[rgba(16,185,129,0.3)]',
      icon: TrendingUp,
    };
  if (v === 'bearish' || v === 'sell' || v === 'trim')
    return {
      bg: 'bg-[rgba(239,68,68,0.12)]',
      text: 'text-[#EF4444]',
      border: 'border-[rgba(239,68,68,0.3)]',
      icon: TrendingDown,
    };
  return {
    bg: 'bg-[rgba(245,158,11,0.12)]',
    text: 'text-[#F59E0B]',
    border: 'border-[rgba(245,158,11,0.3)]',
    icon: Minus,
  };
};

const signalLabelMap: Record<string, string> = {
  BULLISH: '看涨',
  BEARISH: '看跌',
  NEUTRAL: '中性',
};



/* split briefing paragraph into bullet points */
const splitToBullets = (text: string): string[] => {
  if (!text) return [];
  // Try to split by sentence-ending punctuation
  const sentences = text
    .replace(/。/g, '。\n')
    .replace(/；/g, '；\n')
    .split('\n')
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  if (sentences.length >= 4) return sentences;

  // Fallback: split by roughly equal chunks
  const chunks: string[] = [];
  let remaining = text;
  const avgLen = Math.ceil(text.length / 6);
  while (remaining.length > 0) {
    if (remaining.length <= avgLen) {
      chunks.push(remaining);
      break;
    }
    let cut = remaining.lastIndexOf('，', avgLen);
    if (cut === -1) cut = remaining.lastIndexOf('。', avgLen);
    if (cut === -1) cut = avgLen;
    chunks.push(remaining.slice(0, cut + 1));
    remaining = remaining.slice(cut + 1).trim();
  }
  return chunks.filter((c) => c.length > 0);
};

/* ─────────────────────── Gauge Component ─────────────────────── */

function GaugeChart({ score, size = 240 }: { score: number; size?: number }) {
  const strokeWidth = 18;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const arcStart = -90;
  const arcEnd = 90;
  const arcRange = arcEnd - arcStart;

  const polarToCartesian = (
    cx: number,
    cy: number,
    r: number,
    angleDeg: number
  ) => {
    const angleRad = (angleDeg * Math.PI) / 180;
    return { x: cx + r * Math.cos(angleRad), y: cy + r * Math.sin(angleRad) };
  };

  const describeArc = (startAngle: number, endAngle: number, r: number) => {
    const start = polarToCartesian(center, center, r, endAngle);
    const end = polarToCartesian(center, center, r, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      'M',
      start.x,
      start.y,
      'A',
      r,
      r,
      0,
      largeArcFlag,
      0,
      end.x,
      end.y,
    ].join(' ');
  };

  const targetAngle = arcStart + (score / 100) * arcRange;
  const needleEnd = polarToCartesian(center, center, radius - 4, targetAngle);

  const gradientColors = [
    { offset: '0%', color: '#EF4444' },
    { offset: '25%', color: '#F97316' },
    { offset: '50%', color: '#F59E0B' },
    { offset: '75%', color: '#34D399' },
    { offset: '100%', color: '#10B981' },
  ];

  return (
    <svg
      width={size}
      height={size / 2 + 40}
      viewBox={`0 0 ${size} ${size / 2 + 40}`}
    >
      <defs>
        <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          {gradientColors.map((c) => (
            <stop key={c.offset} offset={c.offset} stopColor={c.color} />
          ))}
        </linearGradient>
      </defs>
      {/* Background arc */}
      <path
        d={describeArc(arcStart, arcEnd, radius)}
        fill="none"
        stroke="#232837"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />
      {/* Colored arc */}
      <path
        d={describeArc(arcStart, arcEnd, radius)}
        fill="none"
        stroke="url(#gaugeGrad)"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />
      {/* Tick marks */}
      {[0, 25, 50, 75, 100].map((tick) => {
        const angle = arcStart + (tick / 100) * arcRange;
        const inner = polarToCartesian(
          center,
          center,
          radius - strokeWidth / 2 - 8,
          angle
        );
        const outer = polarToCartesian(
          center,
          center,
          radius - strokeWidth / 2 + 4,
          angle
        );
        return (
          <line
            key={tick}
            x1={inner.x}
            y1={inner.y}
            x2={outer.x}
            y2={outer.y}
            stroke="#5C6375"
            strokeWidth={2}
          />
        );
      })}
      {/* Needle */}
      <motion.line
        x1={center}
        y1={center}
        x2={needleEnd.x}
        y2={needleEnd.y}
        stroke="#D4AF37"
        strokeWidth={3}
        strokeLinecap="round"
        initial={{ x2: center, y2: center }}
        animate={{ x2: needleEnd.x, y2: needleEnd.y }}
        transition={{ duration: 1.5, ease: 'easeOut', delay: 0.3 }}
      />
      {/* Center dot */}
      <circle cx={center} cy={center} r={7} fill="#D4AF37" />
      <circle cx={center} cy={center} r={3.5} fill="#14171F" />
      {/* Labels */}
      <text
        x="15"
        y={size / 2 + 24}
        fill="#5C6375"
        fontSize="10"
        fontFamily="JetBrains Mono, monospace"
        textAnchor="middle"
      >
        0
      </text>
      <text
        x={size / 2}
        y={size / 2 + 24}
        fill="#5C6375"
        fontSize="10"
        fontFamily="JetBrains Mono, monospace"
        textAnchor="middle"
      >
        50
      </text>
      <text
        x={size - 15}
        y={size / 2 + 24}
        fill="#5C6375"
        fontSize="10"
        fontFamily="JetBrains Mono, monospace"
        textAnchor="middle"
      >
        100
      </text>
    </svg>
  );
}

/* ─────────────────────── DimensionBar ─────────────────────── */

function DimensionBar({ name, score }: { name: string; score: number }) {
  const color = getColorForScore(score);
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-400">{name}</span>
        <span className="text-xs font-mono font-semibold" style={{ color }}>
          {score}
        </span>
      </div>
      <div className="w-full h-2 bg-[#232837] rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.8, ease: 'easeOut', delay: 0.5 }}
        />
      </div>
    </div>
  );
}

/* ─────────────────────── Sparkline ─────────────────────── */

function MiniSparkline({ data, color }: { data: number[]; color: string }) {
  const chartData = useMemo(() => data.map((v, i) => ({ i, v })), [data]);
  return (
    <div className="w-[100px] h-[30px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id={`spark-${chartData[0]?.i ?? 0}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.35} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={1.5}
            fill={`url(#spark-${chartData[0]?.i ?? 0})`}
            isAnimationActive
            animationDuration={600}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ─────────────────────── Main Dashboard ─────────────────────── */

const fadeInUp = {
  initial: { opacity: 1, y: 0 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.3 },
};

export default function Dashboard() {
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [sentRes, dashRes] = await Promise.all([
          fetch('/data/sentiment.json'),
          fetch('/data/dashboard.json'),
        ]);
        if (!sentRes.ok) throw new Error(`sentiment.json: ${sentRes.status}`);
        if (!dashRes.ok) throw new Error(`dashboard.json: ${dashRes.status}`);
        const sentData: SentimentData = await sentRes.json();
        const dashData: DashboardData = await dashRes.json();
        setSentiment(sentData);
        setDashboard(dashData);
      } catch (err) {
        setError(err instanceof Error ? err.message : '数据加载失败');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  /* ── default KPIs ── */
  const kpis = useMemo(
    () => [
      { label: 'VIX', value: '13.50', change: -0.32, changePercent: -2.32 },
      { label: '美元指数 (DXY)', value: '103.85', change: 0.14, changePercent: 0.14 },
      { label: '10Y 收益率', value: '4.32', change: 0.03, changePercent: 0.70 },
      { label: 'USD-CNY', value: '7.248', change: 0.005, changePercent: 0.07 },
      { label: '金银比', value: '84.2', change: 0.5, changePercent: 0.60 },
      { label: 'CPI 同比', value: '3.2', change: -0.1, changePercent: -3.03 },
    ],
    []
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div
          className="flex flex-col items-center gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Activity className="w-8 h-8 text-[#D4AF37] animate-spin" />
          <span className="text-sm text-gray-400">加载仪表盘数据...</span>
        </motion.div>
      </div>
    );
  }

  if (error || !sentiment || !dashboard) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <AlertTriangle className="w-8 h-8 text-[#EF4444]" />
          <span className="text-sm text-gray-400">
            {error || '数据加载失败，请稍后重试'}
          </span>
        </div>
      </div>
    );
  }

  const bullets = splitToBullets(dashboard.briefing);
  const sortedSectors = [...dashboard.sectorMomentum].sort(
    (a, b) => b.change - a.change
  );
  const overallLabel = getLabelForScore(sentiment.overallScore);
  const overallColor = getColorForScore(sentiment.overallScore);

  return (
    <div className="space-y-6">
      {/* ── Quote Ticker: Real-time Price Strip ── */}
      <QuoteTicker />

      {/* ── Market Clock: Global Exchange Status ── */}
      <MarketClock />

      {/* ── Row 1: Fear & Greed Gauge + 3 Verdict Cards ── */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Fear & Greed */}
        <motion.div
          className="lg:col-span-1 rounded-xl border border-gray-800 bg-[#161920] p-5 flex flex-col items-center"
          {...fadeInUp}
        >
          <div className="flex items-center gap-2 mb-3">
            <Activity size={16} className="text-[#D4AF37]" />
            <h2 className="text-sm font-semibold text-gray-200">恐惧贪婪指数</h2>
          </div>
          <GaugeChart score={sentiment.overallScore} size={240} />
          <div className="flex flex-col items-center -mt-1">
            <motion.span
              className="font-mono text-[36px] font-bold text-white"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.5 }}
            >
              {sentiment.overallScore}
            </motion.span>
            <motion.span
              className="text-xs uppercase tracking-[0.06em] font-medium"
              style={{ color: overallColor }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.0, duration: 0.5 }}
            >
              {overallLabel}
            </motion.span>
          </div>

          {/* 6 dimensions */}
          <div className="w-full mt-5 space-y-3">
            {sentiment.dimensions.map((dim) => (
              <DimensionBar key={dim.name} name={dim.name} score={dim.score} />
            ))}
          </div>
        </motion.div>

        {/* 3 Verdict Cards */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-5">
          {sentiment.verdicts.map((v, i) => {
            const cfg = getVerdictConfig(v.verdict);
            const Icon = cfg.icon;
            return (
              <motion.div
                key={v.market}
                className="rounded-xl border border-gray-800 bg-[#161920] p-5 flex flex-col"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.4,
                  delay: i * 0.1,
                  ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Globe size={16} className="text-gray-400" />
                    <span className="text-sm font-semibold text-gray-200">
                      {v.market}
                    </span>
                  </div>
                  <span
                    className={cn(
                      'inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border uppercase tracking-[0.04em]',
                      cfg.bg,
                      cfg.text,
                      cfg.border
                    )}
                  >
                    <Icon size={12} />
                    {v.verdict === 'neutral'
                      ? '中性'
                      : v.verdict === 'bullish'
                      ? '看涨'
                      : v.verdict === 'bearish'
                      ? '看跌'
                      : v.verdict}
                  </span>
                </div>

                <div className="mb-3">
                  <div className="flex items-baseline gap-2">
                    <span className="text-xs text-gray-500">{v.indexName}</span>
                    <span className="font-mono text-lg font-bold text-white">
                      {v.indexValue.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                    <span
                      className={cn(
                        'text-xs font-mono font-medium',
                        v.indexChange >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                      )}
                    >
                      {v.indexChange >= 0 ? '+' : ''}
                      {v.indexChange.toFixed(2)}%
                    </span>
                  </div>
                </div>

                {/* Supporting indices */}
                <div className="space-y-1.5 mb-4">
                  {v.supportingIndices.map((si) => (
                    <div key={si.name} className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{si.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-gray-300">
                          {si.value.toLocaleString()}
                        </span>
                        <span
                          className={cn(
                            'text-xs font-mono',
                            si.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                          )}
                        >
                          {si.change >= 0 ? '+' : ''}
                          {si.change.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Key drivers */}
                <div className="mt-auto space-y-1.5 pt-3 border-t border-gray-800">
                  <span className="text-[10px] uppercase tracking-[0.06em] text-gray-500 font-medium">
                    关键驱动
                  </span>
                  {v.keyDrivers.slice(0, 3).map((d, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span className="text-[#D4AF37] mt-0.5 text-xs">&#x2022;</span>
                      <span className="text-xs text-gray-400 leading-relaxed">{d}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ── Smart Alerts ── */}
      <SmartAlerts dashboard={null} sentimentScore={sentiment?.overallScore || 0} kpis={null} />

      {/* ── Export Button ── */}
      <div className="flex justify-end mb-2">
        <ExportButton data={{ sentiment, dashboardData: dashboard }} filename="dashboard" />
      </div>

      {/* ── Row 2: 6 KPI Cards ── */}
      <motion.div
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.4 }}
      >
        {kpis.map((kpi, i) => (
          <motion.div
            key={kpi.label}
            className="rounded-xl border border-gray-800 bg-[#161920] p-4 flex flex-col"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.4,
              delay: 0.3 + i * 0.06,
              ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
            }}
          >
            <span className="text-[10px] uppercase tracking-[0.06em] text-gray-500 font-medium">
              {kpi.label}
            </span>
            <span className="font-mono text-[24px] font-bold text-white mt-2">
              {kpi.value}
            </span>
            <div className="flex items-center gap-1.5 mt-1">
              {kpi.change > 0 ? (
                <TrendingUp size={12} className="text-[#10B981]" />
              ) : (
                <TrendingDown size={12} className="text-[#EF4444]" />
              )}
              <span
                className={cn(
                  'text-xs font-mono font-medium',
                  kpi.change > 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                )}
              >
                {kpi.change > 0 ? '+' : ''}
                {kpi.changePercent.toFixed(2)}%
              </span>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* ── Row 3: Briefing (1/3) + Signal Table (2/3) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Briefing */}
        <motion.div
          className="rounded-xl border border-gray-800 bg-[#161920] p-5"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.4,
            delay: 0.4,
            ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <FileText size={16} className="text-[#D4AF37]" />
            <h2 className="text-sm font-semibold text-gray-200">今日简报</h2>
            <span className="text-[10px] text-gray-500 ml-auto">
              {dashboard.briefingSource}
            </span>
          </div>
          <div className="space-y-3">
            {bullets.map((b, i) => (
              <motion.div
                key={i}
                className="flex items-start gap-2"
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.08, duration: 0.3 }}
              >
                <span className="text-[#D4AF37] mt-1 text-sm flex-shrink-0">
                  &#x2022;
                </span>
                <p className="text-sm text-gray-400 leading-relaxed">{b}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Signal Table */}
        <motion.div
          className="lg:col-span-2 rounded-xl border border-gray-800 bg-[#161920] p-5 overflow-x-auto"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.4,
            delay: 0.5,
            ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Zap size={16} className="text-[#D4AF37]" />
            <h2 className="text-sm font-semibold text-gray-200">时机信号</h2>
          </div>

          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="bg-[#1c1f2a]">
                {['标的', '信号', '入场价', '目标价', '止损', '盈亏比', '趋势'].map(
                  (col) => (
                    <th
                      key={col}
                      className="text-[10px] uppercase tracking-[0.06em] text-gray-500 text-left px-4 py-3 font-medium"
                    >
                      {col}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {dashboard.timingSignals.map((row, index) => {
                const signalColor = getSignalColor(row.signal);
                const label = signalLabelMap[row.signal.toUpperCase()] || row.signal;
                return (
                  <motion.tr
                    key={row.asset}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{
                      duration: 0.3,
                      delay: 0.6 + index * 0.04,
                      ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
                    }}
                    className={cn(
                      'border-b border-gray-800/60 cursor-pointer transition-colors duration-150 hover:bg-[#1c1f2a]',
                      index % 2 === 0 ? 'bg-transparent' : 'bg-[rgba(35,40,55,0.35)]'
                    )}
                    style={{ borderLeft: `3px solid ${signalColor}` }}
                  >
                    <td className="px-4 py-3">
                      <span className="text-sm font-mono font-semibold text-gray-200">
                        {row.asset}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border uppercase',
                          row.signal.toUpperCase() === 'BULLISH'
                            ? 'bg-[rgba(16,185,129,0.12)] text-[#10B981] border-[rgba(16,185,129,0.25)]'
                            : row.signal.toUpperCase() === 'BEARISH'
                            ? 'bg-[rgba(239,68,68,0.12)] text-[#EF4444] border-[rgba(239,68,68,0.25)]'
                            : 'bg-[rgba(156,163,175,0.12)] text-gray-400 border-[rgba(156,163,175,0.25)]'
                        )}
                      >
                        {label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-gray-300 font-mono">{row.entry}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-gray-300 font-mono">{row.target}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-[#EF4444] font-mono">{row.stop}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-[#3B82F6] font-mono font-medium">
                        {row.riskReward}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <MiniSparkline data={row.trend} color={signalColor} />
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </motion.div>
      </div>

      {/* ── Row 4: Sector Momentum ── */}
      <motion.div
        className="rounded-xl border border-gray-800 bg-[#161920] p-5"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{
          duration: 0.4,
          delay: 0.6,
          ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
        }}
      >
        <div className="flex items-center gap-2 mb-5">
          <BarChart3 size={16} className="text-[#D4AF37]" />
          <h2 className="text-sm font-semibold text-gray-200">行业热力</h2>
          <span className="text-[10px] text-gray-500 ml-auto">
            按涨跌幅排序
          </span>
        </div>

        <div className="space-y-3">
          {sortedSectors.map((sector, i) => {
            const isPositive = sector.change >= 0;
            const barColor = isPositive
              ? `rgba(16, 185, 129, ${Math.min(Math.abs(sector.change) / 2 + 0.3, 0.9)})`
              : `rgba(239, 68, 68, ${Math.min(Math.abs(sector.change) / 2 + 0.3, 0.9)})`;
            const maxChange = Math.max(
              ...sortedSectors.map((s) => Math.abs(s.change))
            );
            const barWidth = (Math.abs(sector.change) / maxChange) * 100;

            return (
              <motion.div
                key={sector.name}
                className="flex items-center gap-4"
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.35,
                  delay: 0.7 + i * 0.05,
                  ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
                }}
              >
                <span className="w-20 text-sm text-gray-300 font-medium flex-shrink-0 text-right">
                  {sector.name}
                </span>
                <div className="flex-1 h-7 bg-[#232837] rounded-lg overflow-hidden relative">
                  <motion.div
                    className="h-full rounded-lg flex items-center justify-end pr-2"
                    style={{ backgroundColor: barColor }}
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.max(barWidth, 8)}%` }}
                    transition={{
                      duration: 0.6,
                      delay: 0.8 + i * 0.06,
                      ease: 'easeOut',
                    }}
                  >
                    <span className="text-xs font-mono font-bold text-white drop-shadow">
                      {isPositive ? '+' : ''}
                      {sector.change.toFixed(2)}%
                    </span>
                  </motion.div>
                </div>
                <span className="w-16 text-[10px] text-gray-500 font-mono flex-shrink-0">
                  {sector.topMover}
                </span>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
