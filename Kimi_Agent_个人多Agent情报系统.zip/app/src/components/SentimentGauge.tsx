import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface SentimentGaugeProps {
  score: number; // 0-100
  size?: number;
  delay?: number;
  className?: string;
}

function getDescriptor(score: number): string {
  if (score <= 20) return '极度恐慌';
  if (score <= 40) return '恐慌';
  if (score <= 60) return '中性';
  if (score <= 80) return '贪婪';
  return '极度贪婪';
}

function getColorForScore(score: number): string {
  if (score <= 20) return '#EF4444';
  if (score <= 40) return '#F87171';
  if (score <= 60) return '#F59E0B';
  if (score <= 80) return '#34D399';
  return '#10B981';
}

export default function SentimentGauge({
  score,
  size = 220,
  delay = 0,
  className,
}: SentimentGaugeProps) {
  const [needleAngle, setNeedleAngle] = useState(-90);
  const strokeWidth = 16;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;

  // Semi-circle arc from -90° to 90°
  const arcStart = -90;
  const arcEnd = 90;
  const arcRange = arcEnd - arcStart;
  const targetAngle = arcStart + (score / 100) * arcRange;

  useEffect(() => {
    const timer = setTimeout(() => {
      setNeedleAngle(targetAngle);
    }, delay * 1000);
    return () => clearTimeout(timer);
  }, [targetAngle, delay]);

  // SVG arc path
  const describeArc = (startAngle: number, endAngle: number, r: number) => {
    const start = polarToCartesian(center, center, r, endAngle);
    const end = polarToCartesian(center, center, r, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      'M', start.x, start.y,
      'A', r, r, 0, largeArcFlag, 0, end.x, end.y,
    ].join(' ');
  };

  const polarToCartesian = (cx: number, cy: number, r: number, angleDeg: number) => {
    const angleRad = (angleDeg * Math.PI) / 180;
    return {
      x: cx + r * Math.cos(angleRad),
      y: cy + r * Math.sin(angleRad),
    };
  };

  const needleEnd = polarToCartesian(center, center, radius - 4, needleAngle);

  const gradientColors = [
    { offset: '0%', color: '#EF4444' },
    { offset: '25%', color: '#F87171' },
    { offset: '50%', color: '#F59E0B' },
    { offset: '75%', color: '#34D399' },
    { offset: '100%', color: '#10B981' },
  ];

  const descriptor = getDescriptor(score);

  return (
    <div className={cn('flex flex-col items-center', className)}>
      <svg width={size} height={size / 2 + 30} viewBox={`0 0 ${size} ${size / 2 + 30}`}>
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            {gradientColors.map((c) => (
              <stop key={c.offset} offset={c.offset} stopColor={c.color} />
            ))}
          </linearGradient>
        </defs>

        {/* Background arc */}
        <path
          d={describeArc(arcStart, arcEnd, radius)}
          fill="none"
          stroke="#232837"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />

        {/* Colored arc */}
        <path
          d={describeArc(arcStart, arcEnd, radius)}
          fill="none"
          stroke="url(#gaugeGradient)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />

        {/* Tick marks */}
        {[0, 25, 50, 75, 100].map((tick) => {
          const angle = arcStart + (tick / 100) * arcRange;
          const inner = polarToCartesian(center, center, radius - strokeWidth / 2 - 6, angle);
          const outer = polarToCartesian(center, center, radius - strokeWidth / 2 + 2, angle);
          return (
            <line
              key={tick}
              x1={inner.x}
              y1={inner.y}
              x2={outer.x}
              y2={outer.y}
              stroke="#5C6375"
              strokeWidth={2}
            />
          );
        })}

        {/* Needle */}
        <motion.line
          x1={center}
          y1={center}
          x2={needleEnd.x}
          y2={needleEnd.y}
          stroke="#D4AF37"
          strokeWidth={3}
          strokeLinecap="round"
          initial={false}
          animate={{ x2: needleEnd.x, y2: needleEnd.y }}
          transition={{ duration: 1.5, ease: 'easeOut', delay }}
        />

        {/* Center dot */}
        <circle cx={center} cy={center} r={6} fill="#D4AF37" />
        <circle cx={center} cy={center} r={3} fill="#14171F" />

        {/* Labels */}
        <text x="10" y={size / 2 + 20} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">
          0
        </text>
        <text x={size / 2} y={size / 2 + 20} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">
          50
        </text>
        <text x={size - 10} y={size / 2 + 20} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">
          100
        </text>
      </svg>

      {/* Score display */}
      <div className="flex flex-col items-center -mt-2">
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: delay + 0.8, duration: 0.5 }}
          className="metric-value text-text-primary font-mono text-[32px]"
        >
          {score}
        </motion.span>
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: delay + 1.0, duration: 0.5 }}
          className="caption uppercase tracking-[0.06em]"
          style={{ color: getColorForScore(score) }}
        >
          {descriptor}
        </motion.span>
      </div>
    </div>
  );
}
