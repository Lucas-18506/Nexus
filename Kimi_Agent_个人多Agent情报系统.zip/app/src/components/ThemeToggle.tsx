import { useTheme } from '@/contexts/ThemeContext';
import { Sun, Moon } from 'lucide-react';

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      title={theme === 'dark' ? '切换到浅色主题' : '切换到深色主题'}
      className="flex items-center justify-center rounded-full transition-transform duration-300 ease-in-out hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:ring-offset-2 focus:ring-offset-transparent"
      style={{
        width: 36,
        height: 36,
        backgroundColor: 'var(--bg-elevated, #1e293b)',
        color: 'var(--text-secondary, #94a3b8)',
        transform: 'rotate(0deg)',
      }}
      onMouseDown={(e) => {
        const btn = e.currentTarget;
        btn.style.transform = 'rotate(180deg)';
        setTimeout(() => {
          btn.style.transform = 'rotate(0deg)';
        }, 300);
      }}
    >
      {theme === 'dark' ? (
        <Sun size={18} style={{ color: '#f59e0b' }} />
      ) : (
        <Moon size={18} style={{ color: '#6366f1' }} />
      )}
    </button>
  );
}
