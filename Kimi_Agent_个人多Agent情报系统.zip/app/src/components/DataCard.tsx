import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

type SignalVariant = 'bullish' | 'bearish' | 'neutral' | 'info' | 'none';

interface DataCardProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  footer?: ReactNode;
  signal?: SignalVariant;
  featured?: boolean;
  className?: string;
  noPadding?: boolean;
  delay?: number;
}

const signalBorderMap: Record<SignalVariant, string> = {
  bullish: 'border-l-[3px] border-l-bullish',
  bearish: 'border-l-[3px] border-l-bearish',
  neutral: 'border-l-[3px] border-l-neutral',
  info: 'border-l-[3px] border-l-info',
  none: '',
};

export default function DataCard({
  children,
  title,
  subtitle,
  footer,
  signal = 'none',
  featured = false,
  className,
  noPadding = false,
  delay = 0,
}: DataCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        delay,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className={cn(
        'card-gradient rounded-radius-lg border shadow-card',
        'transition-all duration-250',
        'hover:translate-y-[-2px] hover:shadow-elevated hover:border-border-medium',
        featured ? 'border-border-gold' : 'border-border-subtle',
        signalBorderMap[signal],
        className
      )}
    >
      {(title || subtitle) && (
        <div className={cn('border-b border-border-subtle', !noPadding && 'px-space-5 py-space-4')}>
          {title && (
            <h3 className="card-title text-text-primary flex items-center gap-space-2">
              {title}
            </h3>
          )}
          {subtitle && (
            <p className="body-sm text-text-tertiary mt-space-1">{subtitle}</p>
          )}
        </div>
      )}
      <div className={!noPadding ? 'p-space-5' : ''}>{children}</div>
      {footer && (
        <div className={cn('border-t border-border-subtle', !noPadding && 'px-space-5 py-space-3')}>
          {footer}
        </div>
      )}
    </motion.div>
  );
}
