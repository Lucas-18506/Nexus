import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import {
  Loader2,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowUpCircle,
  ArrowDownCircle,
  CircleDot,
  AlertCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ─── Data Types ─── */
interface PriceTarget {
  high: number;
  median: number;
  low: number;
  upside: number;
  downside: number;
}

interface Consensus {
  rating: string;
  ratingScore: number;
  totalAnalysts: number;
  buy: number;
  hold: number;
  sell: number;
  buyPct: number;
  holdPct: number;
  sellPct: number;
}

interface RatingTrendItem {
  period: string;
  buyPct: number;
  holdPct: number;
  sellPct: number;
}

interface UpgradeDowngrade {
  date: string;
  firm: string;
  action: string;
  from?: string;
  to?: string;
  target: number;
}

interface StockConsensus {
  ticker: string;
  name: string;
  price: number;
  priceChange: number;
  priceChangePct: number;
  consensus: Consensus;
  priceTargets: PriceTarget;
  ratingTrend?: RatingTrendItem[];
  upgradesDowngrades?: UpgradeDowngrade[];
  recommendation: string;
}

interface AnalystConsensusData {
  lastUpdate: string;
  stocks: StockConsensus[];
}

/* ─── Helper: rating color ─── */
function getRatingColor(rating: string): string {
  if (rating.includes('买入') || rating.includes('强力买入')) return 'text-bullish';
  if (rating.includes('卖出') || rating.includes('减持')) return 'text-bearish';
  return 'text-neutral';
}

function getRatingBg(rating: string): string {
  if (rating.includes('买入') || rating.includes('强力买入')) return 'bg-bullish/10';
  if (rating.includes('卖出') || rating.includes('减持')) return 'bg-bearish/10';
  return 'bg-neutral/10';
}

function getActionColor(action: string): string {
  if (action === '上调') return 'text-bullish';
  if (action === '下调') return 'text-bearish';
  return 'text-neutral';
}

function getActionIcon(action: string) {
  if (action === '上调') return <ArrowUpCircle size={16} className="text-bullish" />;
  if (action === '下调') return <ArrowDownCircle size={16} className="text-bearish" />;
  return <Minus size={16} className="text-neutral" />;
}

/* ─── Animation variants ─── */
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 12 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] },
  },
};

/* ─── Custom Tooltip for Charts ─── */
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-elevated border border-border-subtle rounded-lg px-3 py-2 shadow-elevated">
      <p className="text-text-secondary text-xs mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} className="text-xs" style={{ color: p.color }}>
          {p.name}: {p.value}%
        </p>
      ))}
    </div>
  );
}

/* ─── Main Component ─── */
export default function AnalystConsensus({ ticker }: { ticker: string }) {
  const [data, setData] = useState<AnalystConsensusData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch('/data/analyst_consensus.json')
      .then((res) => {
        if (!res.ok) throw new Error(`请求失败: ${res.status}`);
        return res.json();
      })
      .then((json: AnalystConsensusData) => {
        if (cancelled) return;
        setData(json);
        setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : '加载数据时出错');
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  const stock = useMemo(() => {
    if (!data) return null;
    return data.stocks.find((s) => s.ticker === ticker) ?? null;
  }, [data, ticker]);

  /* ─── Loading State ─── */
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 size={28} className="animate-spin text-text-tertiary" />
        <span className="ml-3 text-text-secondary text-sm">加载分析师数据中...</span>
      </div>
    );
  }

  /* ─── Error State ─── */
  if (error) {
    return (
      <div className="flex items-center justify-center py-16 text-bearish">
        <AlertCircle size={20} className="mr-2" />
        <span className="text-sm">{error}</span>
      </div>
    );
  }

  /* ─── No Data State ─── */
  if (!stock) {
    return (
      <div className="flex items-center justify-center py-16 text-text-secondary">
        <AlertCircle size={20} className="mr-2" />
        <span className="text-sm">暂无该标的数据</span>
      </div>
    );
  }

  const { consensus, priceTargets, ratingTrend, upgradesDowngrades, recommendation, price } = stock;

  /* ─── Price Target Bar Data ─── */
  const priceTargetData = [
    { name: '最低目标', value: priceTargets.low, color: '#EF4444' },
    { name: '中位目标', value: priceTargets.median, color: '#F59E0B' },
    { name: '最高目标', value: priceTargets.high, color: '#10B981' },
  ];

  /* ─── Rating Trend Data ─── */
  const trendData = ratingTrend ?? [];

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      {/* ── Module Header ── */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h2 className="card-title text-text-primary flex items-center gap-2">
            <CircleDot size={18} className="text-info" />
            分析师共识
          </h2>
          <p className="caption text-text-tertiary mt-1">
            更新时间: {new Date(data!.lastUpdate).toLocaleString('zh-CN')}
          </p>
        </div>
        <span className={cn('px-3 py-1 rounded-full text-sm font-semibold', getRatingBg(consensus.rating), getRatingColor(consensus.rating))}>
          {consensus.rating}
        </span>
      </motion.div>

      {/* ── Rating Overview Card ── */}
      <motion.div
        variants={itemVariants}
        className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left: Consensus Rating */}
          <div className="flex flex-col justify-center space-y-3">
            <div>
              <span className="text-label">共识评级</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className={cn('text-3xl font-bold', getRatingColor(consensus.rating))}>
                  {consensus.rating}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="metric-label">评分</span>
              <span className="metric-value text-text-primary text-xl">{consensus.ratingScore}</span>
              <span className="text-text-tertiary text-sm">/ 5</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="metric-label">覆盖机构</span>
              <span className="text-text-primary font-semibold">{consensus.totalAnalysts} 家</span>
            </div>
            <div className="flex gap-3 pt-1">
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-bullish" />
                <span className="text-xs text-text-secondary">买入 {consensus.buy}</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-neutral" />
                <span className="text-xs text-text-secondary">持有 {consensus.hold}</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-bearish" />
                <span className="text-xs text-text-secondary">卖出 {consensus.sell}</span>
              </div>
            </div>
          </div>

          {/* Middle: Price Target Range */}
          <div className="flex flex-col justify-center">
            <span className="text-label mb-2">目标价区间</span>
            <div className="h-[140px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={priceTargetData}
                  layout="vertical"
                  margin={{ top: 0, right: 30, left: 20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" horizontal={false} />
                  <XAxis type="number" domain={[0, Math.max(priceTargets.high * 1.1, price * 1.1)]} hide />
                  <YAxis type="category" dataKey="name" width={60} tick={{ fill: '#94A3B8', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      return (
                        <div className="bg-bg-elevated border border-border-subtle rounded-lg px-3 py-2 shadow-elevated">
                          <p className="text-text-secondary text-xs">
                            {payload[0].payload.name}: ${payload[0].value}
                          </p>
                        </div>
                      );
                    }}
                  />
                  <ReferenceLine
                    x={price}
                    stroke="#3B82F6"
                    strokeDasharray="4 4"
                    strokeWidth={2}
                    label={{
                      value: `现价 $${price}`,
                      position: 'top',
                      fill: '#3B82F6',
                      fontSize: 10,
                    }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 4, 4]} barSize={18}>
                    {priceTargetData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Right: Upside / Downside */}
          <div className="flex flex-col justify-center space-y-4">
            <div className="bg-bullish/10 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp size={16} className="text-bullish" />
                <span className="text-label">上涨空间</span>
              </div>
              <span className="text-2xl font-bold text-bullish">+{priceTargets.upside}%</span>
              <p className="text-xs text-text-tertiary mt-1">
                基于中位目标 ${priceTargets.median}
              </p>
            </div>
            <div className="bg-bearish/10 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1">
                <TrendingDown size={16} className="text-bearish" />
                <span className="text-label">下跌风险</span>
              </div>
              <span className="text-2xl font-bold text-bearish">{priceTargets.downside}%</span>
              <p className="text-xs text-text-tertiary mt-1">
                基于最低目标 ${priceTargets.low}
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── Rating Trend Chart ── */}
      {trendData.length > 0 && (
        <motion.div
          variants={itemVariants}
          className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
        >
          <h3 className="card-title text-text-primary mb-4">评级趋势变化</h3>
          <div className="h-[220px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis
                  dataKey="period"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  domain={[0, 100]}
                  tickFormatter={(v: number) => `${v}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  wrapperStyle={{ fontSize: '12px', color: '#94A3B8' }}
                  formatter={(value: string) => <span className="text-text-secondary">{value}</span>}
                />
                <Line
                  type="monotone"
                  dataKey="buyPct"
                  name="买入"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  dot={{ fill: '#10B981', r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="holdPct"
                  name="持有"
                  stroke="#F59E0B"
                  strokeWidth={2.5}
                  dot={{ fill: '#F59E0B', r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="sellPct"
                  name="卖出"
                  stroke="#EF4444"
                  strokeWidth={2.5}
                  dot={{ fill: '#EF4444', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      )}

      {/* ── Recent Upgrades/Downgrades Timeline ── */}
      {upgradesDowngrades && upgradesDowngrades.length > 0 && (
        <motion.div
          variants={itemVariants}
          className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
        >
          <h3 className="card-title text-text-primary mb-4">近期调级动态</h3>
          <div className="relative pl-4">
            {/* Vertical timeline line */}
            <div className="absolute left-[11px] top-2 bottom-2 w-[2px] bg-border-subtle" />

            <div className="space-y-4">
              {upgradesDowngrades.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1, duration: 0.35 }}
                  className="relative flex items-start gap-3 pl-6"
                >
                  {/* Timeline dot */}
                  <div className={cn(
                    'absolute left-0 top-1 w-6 h-6 rounded-full flex items-center justify-center',
                    item.action === '上调' ? 'bg-bullish/20' :
                    item.action === '下调' ? 'bg-bearish/20' : 'bg-neutral/20'
                  )}>
                    {getActionIcon(item.action)}
                  </div>

                  <div className="flex-1 bg-bg-elevated/50 rounded-lg p-3 border border-border-subtle">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-text-primary">{item.firm}</span>
                      <span className="text-xs text-text-tertiary">{item.date}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={cn('text-sm font-semibold', getActionColor(item.action))}>
                        {item.action}
                      </span>
                      {item.from && item.to && (
                        <span className="text-xs text-text-secondary">
                          {item.from} → {item.to}
                        </span>
                      )}
                      {!item.from && item.to && (
                        <span className="text-xs text-text-secondary">{item.to}</span>
                      )}
                      <span className="text-sm font-semibold text-text-primary ml-auto">
                        目标 ${item.target}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* ── Investment Summary ── */}
      <motion.div
        variants={itemVariants}
        className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
      >
        <h3 className="card-title text-text-primary mb-2">投资摘要</h3>
        <p className="body-sm text-text-secondary leading-relaxed">{recommendation}</p>
      </motion.div>
    </motion.div>
  );
}
