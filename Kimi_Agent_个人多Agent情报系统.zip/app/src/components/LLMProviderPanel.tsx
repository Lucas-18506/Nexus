import React, { useState, useCallback, useMemo } from 'react';
import {
  Brain,
  Zap,
  Eye,
  EyeOff,
  Check,
  X,
  RotateCcw,
  Server,
  KeyRound,
  Globe,
  Cpu,
  Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useLLMConfig, type ProviderId } from '@/contexts/LLMContext';

// ─── 提供商图标映射 ─────────────────────────────────────

const PROVIDER_ICONS: Record<ProviderId, React.ReactNode> = {
  deepseek: <Brain className="size-5" />,
  openai: <Cpu className="size-5" />,
  anthropic: <Brain className="size-5" />,
  google: <Globe className="size-5" />,
  dashscope: <Server className="size-5" />,
  siliconflow: <Cpu className="size-5" />,
  openrouter: <Globe className="size-5" />,
};

// ─── 连接测试 ───────────────────────────────────────────

async function testConnection(
  baseUrl: string,
  apiKey: string,
  providerId: ProviderId
): Promise<{ success: boolean; message: string }> {
  if (!apiKey.trim()) {
    return { success: false, message: '请先输入API Key' };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    let testUrl = baseUrl;
    if (testUrl.endsWith('/')) {
      testUrl = testUrl.slice(0, -1);
    }

    // 各提供商的测试端点
    const endpoints: Record<string, string> = {
      deepseek: `${testUrl}/models`,
      openai: `${testUrl}/models`,
      anthropic: `${testUrl}/models`,
      google: `${testUrl}/models`,
      dashscope: `${testUrl}/models`,
      siliconflow: `${testUrl}/models`,
      openrouter: `${testUrl}/models`,
    };

    const headers: Record<string, string> = {
      Authorization: `Bearer ${apiKey}`,
    };

    if (providerId === 'anthropic') {
      headers['x-api-key'] = apiKey;
      headers['anthropic-version'] = '2023-06-01';
    }

    const response = await fetch(endpoints[providerId] || `${testUrl}/models`, {
      method: 'GET',
      headers,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      return { success: true, message: '连接成功' };
    }
    const statusText = response.statusText || `HTTP ${response.status}`;
    return { success: false, message: `连接失败: ${statusText}` };
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      return { success: false, message: '连接超时' };
    }
    return { success: false, message: '网络错误' };
  }
}

// ─── 单个提供商卡片 ─────────────────────────────────────

interface ProviderCardProps {
  providerId: ProviderId;
  name: string;
  baseUrl: string;
  apiKey: string;
  models: string[];
  enabled: boolean;
  isActive: boolean;
  onUpdate: (id: ProviderId, updates: Partial<{ baseUrl: string; apiKey: string; enabled: boolean; models: string[] }>) => void;
  onActivate: (id: ProviderId) => void;
}

function ProviderCard({
  providerId,
  name,
  baseUrl,
  apiKey,
  models: _models,
  enabled,
  isActive,
  onUpdate,
  onActivate,
}: ProviderCardProps) {
  const [showKey, setShowKey] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testMessage, setTestMessage] = useState('');

  const handleTest = useCallback(async () => {
    setTestStatus('testing');
    setTestMessage('');
    const result = await testConnection(baseUrl, apiKey, providerId);
    setTestStatus(result.success ? 'success' : 'error');
    setTestMessage(result.message);
  }, [baseUrl, apiKey, providerId]);

  const canActivate = enabled && apiKey.trim().length > 0;

  return (
    <Card
      className={cn(
        'transition-all duration-200',
        isActive
          ? 'border-emerald-500/60 ring-1 ring-emerald-500/30'
          : 'border-border/60 hover:border-border',
        !enabled && 'opacity-60'
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                'flex size-9 items-center justify-center rounded-lg',
                isActive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-muted text-muted-foreground'
              )}
            >
              {PROVIDER_ICONS[providerId]}
            </div>
            <div>
              <CardTitle className="text-sm font-semibold">{name}</CardTitle>
              <CardDescription className="text-xs">{providerId}</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isActive && (
              <Badge
                variant="outline"
                className="border-emerald-500/40 bg-emerald-500/10 text-emerald-400 text-xs"
              >
                <Check className="mr-1 size-3" />
                当前
              </Badge>
            )}
            <Switch
              checked={enabled}
              onCheckedChange={(checked) => onUpdate(providerId, { enabled: checked })}
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-3 pt-0">
        {/* API Key */}
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
            <KeyRound className="size-3" />
            API Key
          </Label>
          <div className="relative">
            <Input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => onUpdate(providerId, { apiKey: e.target.value })}
              placeholder="sk-..."
              className="h-8 pr-9 text-xs font-mono"
              disabled={!enabled}
            />
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              disabled={!enabled}
            >
              {showKey ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
            </button>
          </div>
        </div>

        {/* Base URL */}
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
            <Globe className="size-3" />
            Base URL
          </Label>
          <Input
            value={baseUrl}
            onChange={(e) => onUpdate(providerId, { baseUrl: e.target.value })}
            placeholder="https://api.example.com/v1"
            className="h-8 text-xs font-mono"
            disabled={!enabled}
          />
        </div>

        {/* 操作按钮 */}
        <div className="flex items-center gap-2 pt-1">
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1.5 flex-1"
            onClick={handleTest}
            disabled={!enabled || !apiKey.trim() || testStatus === 'testing'}
          >
            {testStatus === 'testing' ? (
              <Loader2 className="size-3 animate-spin" />
            ) : testStatus === 'success' ? (
              <Check className="size-3" />
            ) : testStatus === 'error' ? (
              <X className="size-3" />
            ) : null}
            {testStatus === 'testing' ? '测试中...' : '测试连接'}
          </Button>
          <Button
            variant={isActive ? 'default' : 'outline'}
            size="sm"
            className={cn(
              'h-7 text-xs gap-1.5 flex-1',
              isActive && 'bg-emerald-600 hover:bg-emerald-700'
            )}
            onClick={() => onActivate(providerId)}
            disabled={!canActivate || isActive}
          >
            {isActive ? '已激活' : '设为默认'}
          </Button>
        </div>

        {/* 测试结果 */}
        {testStatus !== 'idle' && testStatus !== 'testing' && (
          <div
            className={cn(
              'flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs',
              testStatus === 'success'
                ? 'bg-emerald-500/10 text-emerald-400'
                : 'bg-red-500/10 text-red-400'
            )}
          >
            {testStatus === 'success' ? (
              <Check className="size-3 shrink-0" />
            ) : (
              <X className="size-3 shrink-0" />
            )}
            {testMessage}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── 主面板组件 ─────────────────────────────────────────

export default function LLMProviderPanel() {
  const {
    config,
    updateProvider,
    setActiveProvider,
    updateModel,
    updateGlobalSettings,
    resetToDefaults,
  } = useLLMConfig();

  const activeProvider = config.providers.find(p => p.id === config.provider);

  // 获取所有可用模型（当前激活提供商的模型 + 已启用提供商的模型）
  const availableModels = useMemo(() => {
    const result: { id: string; name: string; provider: string }[] = [];
    for (const p of config.providers) {
      if (!p.enabled) continue;
      for (const m of p.models) {
        result.push({
          id: `${p.id}::${m}`,
          name: m,
          provider: p.name,
        });
      }
    }
    return result;
  }, [config.providers]);

  // 模型选择值格式: "providerId::modelName"
  const deepModelValue = useMemo(() => {
    if (!activeProvider) return '';
    return `${config.provider}::${config.deepThinkModel}`;
  }, [config.provider, config.deepThinkModel, activeProvider]);

  const quickModelValue = useMemo(() => {
    if (!activeProvider) return '';
    return `${config.provider}::${config.quickThinkModel}`;
  }, [config.provider, config.quickThinkModel, activeProvider]);

  const handleDeepModelChange = useCallback(
    (value: string) => {
      const parts = value.split('::');
      if (parts.length === 2) {
        const [, model] = parts;
        updateModel('deep', model);
      }
    },
    [updateModel]
  );

  const handleQuickModelChange = useCallback(
    (value: string) => {
      const parts = value.split('::');
      if (parts.length === 2) {
        const [, model] = parts;
        updateModel('quick', model);
      }
    },
    [updateModel]
  );

  const enabledCount = config.providers.filter(p => p.enabled).length;

  return (
    <div className="space-y-6">
      {/* 头部信息 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">LLM 提供商配置</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            已启用 {enabledCount} 个提供商，当前默认:{' '}
            <span className="text-emerald-400 font-medium">
              {activeProvider?.name || '未设置'}
            </span>
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="h-8 gap-1.5 text-xs"
          onClick={resetToDefaults}
        >
          <RotateCcw className="size-3.5" />
          恢复默认
        </Button>
      </div>

      {/* 模型选择区 */}
      <Card className="border-border/60">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Brain className="size-4 text-amber-400" />
            模型配置
          </CardTitle>
          <CardDescription className="text-xs">
            为不同思考模式选择模型，所有已启用提供商的模型均可选择
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 深度思考模型 */}
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5">
              <Brain className="size-3 text-amber-400" />
              深度思考模型
            </Label>
            <Select value={deepModelValue} onValueChange={handleDeepModelChange}>
              <SelectTrigger className="h-8 text-xs w-full">
                <SelectValue placeholder="选择深度思考模型" />
              </SelectTrigger>
              <SelectContent>
                {availableModels.length === 0 && (
                  <SelectItem value="" disabled>
                    请先启用至少一个提供商
                  </SelectItem>
                )}
                {availableModels.map(m => (
                  <SelectItem key={`deep-${m.id}`} value={m.id} className="text-xs">
                    <span className="flex items-center gap-2">
                      <span className="text-muted-foreground">[{m.provider}]</span>
                      <span>{m.name}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              用于深度分析、推理和复杂任务
            </p>
          </div>

          {/* 快速思考模型 */}
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5">
              <Zap className="size-3 text-sky-400" />
              快速思考模型
            </Label>
            <Select value={quickModelValue} onValueChange={handleQuickModelChange}>
              <SelectTrigger className="h-8 text-xs w-full">
                <SelectValue placeholder="选择快速思考模型" />
              </SelectTrigger>
              <SelectContent>
                {availableModels.length === 0 && (
                  <SelectItem value="" disabled>
                    请先启用至少一个提供商
                  </SelectItem>
                )}
                {availableModels.map(m => (
                  <SelectItem key={`quick-${m.id}`} value={m.id} className="text-xs">
                    <span className="flex items-center gap-2">
                      <span className="text-muted-foreground">[{m.provider}]</span>
                      <span>{m.name}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              用于快速响应、简单查询和实时交互
            </p>
          </div>

          {/* 全局参数 */}
          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border/40">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Temperature</Label>
              <Input
                type="number"
                min={0}
                max={2}
                step={0.1}
                value={config.temperature}
                onChange={(e) =>
                  updateGlobalSettings({ temperature: parseFloat(e.target.value) || 0 })
                }
                className="h-8 text-xs"
              />
              <p className="text-[11px] text-muted-foreground">0=确定性, 2=创造性</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Max Tokens</Label>
              <Input
                type="number"
                min={256}
                max={32768}
                step={256}
                value={config.maxTokens}
                onChange={(e) =>
                  updateGlobalSettings({ maxTokens: parseInt(e.target.value) || 4096 })
                }
                className="h-8 text-xs"
              />
              <p className="text-[11px] text-muted-foreground">最大输出长度</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 提供商卡片网格 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {config.providers.map(p => (
          <ProviderCard
            key={p.id}
            providerId={p.id}
            name={p.name}
            baseUrl={p.baseUrl}
            apiKey={p.apiKey}
            models={p.models}
            enabled={p.enabled}
            isActive={p.id === config.provider}
            onUpdate={updateProvider}
            onActivate={setActiveProvider}
          />
        ))}
      </div>
    </div>
  );
}
