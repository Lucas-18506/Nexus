import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  AlertTriangle,
  AlertCircle,
  Info,
  ShieldAlert,
  Bell,
  TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ═══════════════════════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════════════════════ */

export type AlertLevel = 'info' | 'warning' | 'danger';

export interface Alert {
  id: string;
  level: AlertLevel;
  title: string;
  message: string;
  source: string;
  time: string;
  dismissible: boolean;
}

/** SmartAlerts 所需的数据子集（与 Dashboard.tsx 中的类型兼容） */
export interface AlertsDashboardData {
  lastUpdate: string;
  sectorMomentum: Array<{
    name: string;
    change: number;
    momentumScore: number;
    topMover: string;
  }>;
  briefing: string;
}

/** 宏观 KPI 数据 */
export interface MacroKPIs {
  vix: number;
  yield10Y: number;
  yield2Y: number;
  ahPremium?: number;
}

/** 宏观日历事件 */
export interface MacroEvent {
  date: string;
  title: string;
}

/* ═══════════════════════════════════════════════════════════
   提醒生成逻辑
   ═══════════════════════════════════════════════════════════ */

interface GenerateAlertsInput {
  dashboard: AlertsDashboardData | null;
  sentimentScore: number;
  kpis: MacroKPIs | null;
  macroEvents?: MacroEvent[];
}

/**
 * 基于当前数据自动生成智能提醒
 *
 * 规则：
 * 1. VIX < 14 → danger
 * 2. 恐惧贪婪 >75 或 <25 → warning
 * 3. 10Y-2Y 利差 < 0 → danger
 * 4. AH 溢价 > 140 → info
 * 5. 行业 momentumScore > 85 → warning
 * 6. 有宏观日历事件 → info
 */
export function generateAlerts({
  dashboard,
  sentimentScore,
  kpis,
  macroEvents,
}: GenerateAlertsInput): Alert[] {
  const alerts: Alert[] = [];
  const now = new Date();
  const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

  // 1. VIX 极低提醒
  if (kpis && kpis.vix < 14) {
    alerts.push({
      id: 'vix-low',
      level: 'danger',
      title: 'VIX 极低风险',
      message: `VIX 处于 ${kpis.vix.toFixed(2)} 极低水平，市场自满情绪浓厚，历史上 VIX < 14 后 3 个月内出现 > 10% 回调的概率为 35%`,
      source: '波动率模型',
      time: timeStr,
      dismissible: true,
    });
  }

  // 2. 恐惧贪婪极值提醒
  if (sentimentScore > 75) {
    alerts.push({
      id: 'greed-extreme',
      level: 'warning',
      title: '恐惧贪婪极值',
      message: `恐惧贪婪指数达到 ${sentimentScore}，处于极度贪婪区间，建议反向操作（减持/对冲）`,
      source: '情绪模型',
      time: timeStr,
      dismissible: true,
    });
  } else if (sentimentScore < 25) {
    alerts.push({
      id: 'fear-extreme',
      level: 'warning',
      title: '恐惧贪婪极值',
      message: `恐惧贪婪指数达到 ${sentimentScore}，处于极度恐惧区间，建议反向操作（逢低布局）`,
      source: '情绪模型',
      time: timeStr,
      dismissible: true,
    });
  }

  // 3. 收益率曲线倒挂提醒
  if (kpis) {
    const spread = (kpis.yield10Y - kpis.yield2Y) * 100; // 转为 bp
    if (spread < 0) {
      alerts.push({
        id: 'yield-inversion',
        level: 'danger',
        title: '收益率曲线倒挂',
        message: `收益率曲线倒挂 ${Math.abs(spread).toFixed(0)}bp，历史上每次倒挂后 12-24 个月内出现衰退`,
        source: '宏观模型',
        time: timeStr,
        dismissible: true,
      });
    }
  }

  // 4. AH 溢价提醒
  if (kpis?.ahPremium && kpis.ahPremium > 140) {
    alerts.push({
      id: 'ah-premium',
      level: 'info',
      title: 'AH 溢价机会',
      message: `AH 溢价达到 ${kpis.ahPremium.toFixed(0)}%，港股相对 A 股估值吸引力凸显`,
      source: '估值模型',
      time: timeStr,
      dismissible: true,
    });
  }

  // 5. 行业过热提醒
  if (dashboard) {
    dashboard.sectorMomentum.forEach((sector) => {
      if (sector.momentumScore > 85) {
        alerts.push({
          id: `sector-hot-${sector.name}`,
          level: 'warning',
          title: '行业过热',
          message: `${sector.name} 板块动量评分达 ${sector.momentumScore}，短期过热，注意回调风险`,
          source: '动量模型',
          time: timeStr,
          dismissible: true,
        });
      }
    });
  }

  // 6. 美联储政策提醒
  if (macroEvents && macroEvents.length > 0) {
    const eventList = macroEvents.map((e) => `${e.date} ${e.title}`).join('、');
    alerts.push({
      id: 'macro-events',
      level: 'info',
      title: '本周宏观焦点',
      message: `本周重点关注：${eventList}`,
      source: '宏观日历',
      time: timeStr,
      dismissible: true,
    });
  }

  return alerts;
}

/**
 * 计算综合风险等级
 *   low    = 绿色（无 danger，warning ≤ 1）
 *   medium = 黄色（有 1-2 个 danger，或 warning ≥ 2）
 *   high   = 红色（≥ 3 个 danger，或 danger + warning ≥ 4）
 */
function calcRiskLevel(alerts: Alert[]): 'low' | 'medium' | 'high' {
  const dangerCount = alerts.filter((a) => a.level === 'danger').length;
  const warningCount = alerts.filter((a) => a.level === 'warning').length;

  if (dangerCount >= 3 || dangerCount + warningCount >= 4) return 'high';
  if (dangerCount >= 1 || warningCount >= 2) return 'medium';
  return 'low';
}

/* ═══════════════════════════════════════════════════════════
   Hook：useSmartAlerts
   ═══════════════════════════════════════════════════════════ */

export interface UseSmartAlertsResult {
  alerts: Alert[];
  dismissedIds: string[];
  activeAlerts: Alert[];
  unreadCount: number;
  dismissAlert: (id: string) => void;
  restoreAll: () => void;
  riskLevel: 'low' | 'medium' | 'high';
}

export function useSmartAlerts(
  input: GenerateAlertsInput
): UseSmartAlertsResult {
  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('smart_alerts_dismissed');
      return saved ? (JSON.parse(saved) as string[]) : [];
    } catch {
      return [];
    }
  });

  const alerts = useMemo(() => generateAlerts(input), [input]);

  const activeAlerts = useMemo(
    () => alerts.filter((a) => !dismissedIds.includes(a.id)),
    [alerts, dismissedIds]
  );

  const riskLevel = useMemo(() => calcRiskLevel(alerts), [alerts]);

  const dismissAlert = useCallback((id: string) => {
    setDismissedIds((prev) => {
      const next = prev.includes(id) ? prev : [...prev, id];
      try {
        localStorage.setItem('smart_alerts_dismissed', JSON.stringify(next));
      } catch {
        // ignore storage errors
      }
      return next;
    });
  }, []);

  const restoreAll = useCallback(() => {
    setDismissedIds([]);
    try {
      localStorage.removeItem('smart_alerts_dismissed');
    } catch {
      // ignore
    }
  }, []);

  return {
    alerts,
    dismissedIds,
    activeAlerts,
    unreadCount: activeAlerts.length,
    dismissAlert,
    restoreAll,
    riskLevel,
  };
}

/* ═══════════════════════════════════════════════════════════
   子组件：风险仪表盘
   ═══════════════════════════════════════════════════════════ */

function RiskGauge({ riskLevel }: { riskLevel: 'low' | 'medium' | 'high' }) {
  const config = {
    low: { label: '低风险', color: '#10B981', angle: -60 },
    medium: { label: '中风险', color: '#F59E0B', angle: 0 },
    high: { label: '高风险', color: '#EF4444', angle: 60 },
  }[riskLevel];

  const size = 140;
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;

  // 半圆弧：-90° 到 +90°
  const polarToCartesian = (cx: number, cy: number, r: number, angleDeg: number) => {
    const rad = (angleDeg * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const describeArc = (startAngle: number, endAngle: number, r: number) => {
    const start = polarToCartesian(center, center, r, endAngle);
    const end = polarToCartesian(center, center, r, startAngle);
    const largeArc = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      'M', start.x, start.y,
      'A', r, r, 0, largeArc, 0, end.x, end.y,
    ].join(' ');
  };

  const needleEnd = polarToCartesian(center, center, radius - 2, config.angle);

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={size} height={size / 2 + 28} viewBox={`0 0 ${size} ${size / 2 + 28}`}>
        <defs>
          <linearGradient id="riskGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="50%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#EF4444" />
          </linearGradient>
        </defs>
        {/* 背景弧 */}
        <path
          d={describeArc(-90, 90, radius)}
          fill="none"
          stroke="#232837"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        {/* 彩色弧 */}
        <path
          d={describeArc(-90, 90, radius)}
          fill="none"
          stroke="url(#riskGrad)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        {/* 指针 */}
        <motion.line
          x1={center}
          y1={center}
          x2={needleEnd.x}
          y2={needleEnd.y}
          stroke={config.color}
          strokeWidth={3}
          strokeLinecap="round"
          initial={{ x2: center, y2: center }}
          animate={{ x2: needleEnd.x, y2: needleEnd.y }}
          transition={{ duration: 1, ease: 'easeOut' }}
        />
        {/* 中心点 */}
        <circle cx={center} cy={center} r={5} fill={config.color} />
        <circle cx={center} cy={center} r={2.5} fill="#14171F" />
        {/* 标签 */}
        <text x="15" y={size / 2 + 18} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">低</text>
        <text x={size / 2} y={size / 2 + 18} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">中</text>
        <text x={size - 15} y={size / 2 + 18} fill="#5C6375" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">高</text>
      </svg>
      <span
        className="text-xs font-semibold tracking-wide"
        style={{ color: config.color }}
      >
        {config.label}
      </span>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   子组件：单个提醒卡片
   ═══════════════════════════════════════════════════════════ */

const levelConfig: Record<
  AlertLevel,
  { icon: typeof AlertTriangle; color: string; bg: string; border: string; label: string }
> = {
  info: {
    icon: Info,
    color: '#3B82F6',
    bg: 'bg-[rgba(59,130,246,0.08)]',
    border: 'border-l-[#3B82F6]',
    label: '提示',
  },
  warning: {
    icon: AlertTriangle,
    color: '#F59E0B',
    bg: 'bg-[rgba(245,158,11,0.08)]',
    border: 'border-l-[#F59E0B]',
    label: '警告',
  },
  danger: {
    icon: AlertCircle,
    color: '#EF4444',
    bg: 'bg-[rgba(239,68,68,0.08)]',
    border: 'border-l-[#EF4444]',
    label: '危险',
  },
};

function AlertCard({
  alert,
  onDismiss,
}: {
  alert: Alert;
  onDismiss: (id: string) => void;
}) {
  const cfg = levelConfig[alert.level];
  const Icon = cfg.icon;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -12, scale: 0.97 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 12, scale: 0.97 }}
      transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
      className={cn(
        'relative rounded-lg border border-gray-800 p-4',
        'border-l-[3px]',
        cfg.border,
        cfg.bg
      )}
    >
      {/* 关闭按钮 */}
      {alert.dismissible && (
        <button
          onClick={() => onDismiss(alert.id)}
          className="absolute top-2.5 right-2.5 p-1 rounded-md hover:bg-[rgba(255,255,255,0.08)] transition-colors duration-150"
          aria-label="关闭提醒"
        >
          <X size={14} className="text-text-tertiary hover:text-text-primary" />
        </button>
      )}

      {/* 标题行 */}
      <div className="flex items-center gap-2 mb-1.5 pr-6">
        <Icon size={14} style={{ color: cfg.color }} />
        <span className="text-sm font-bold text-gray-200">{alert.title}</span>
        <span
          className="text-[10px] px-1.5 py-0.5 rounded font-medium"
          style={{ color: cfg.color, backgroundColor: `${cfg.color}18` }}
        >
          {cfg.label}
        </span>
      </div>

      {/* 消息 */}
      <p className="text-xs text-gray-400 leading-relaxed mb-3">{alert.message}</p>

      {/* 底部：来源 + 时间 */}
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-gray-500">{alert.source}</span>
        <span className="text-[10px] text-gray-500 font-mono">{alert.time}</span>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════
   主组件：SmartAlerts
   ═══════════════════════════════════════════════════════════ */

export interface SmartAlertsProps {
  /** 智能提醒数据输入 */
  dashboard: AlertsDashboardData | null;
  /** 恐惧贪婪指数当前分数 */
  sentimentScore: number;
  /** 宏观 KPI 数据 */
  kpis: MacroKPIs | null;
  /** 宏观日历事件（可选） */
  macroEvents?: MacroEvent[];
}

/**
 * 智能提醒组件
 *
 * 显示在 Dashboard 页面，包含：
 * - 总体风险仪表盘（左） + 提醒列表（右）
 * - 自动根据数据生成提醒
 * - 支持关闭提醒（localStorage 持久化）
 */
export default function SmartAlerts({
  dashboard,
  sentimentScore,
  kpis,
  macroEvents,
}: SmartAlertsProps) {
  const {
    activeAlerts,
    dismissAlert,
    restoreAll,
    riskLevel,
    unreadCount,
  } = useSmartAlerts({
    dashboard,
    sentimentScore,
    kpis,
    macroEvents,
  });

  // 统计各等级提醒数量
  const dangerCount = useMemo(
    () => activeAlerts.filter((a) => a.level === 'danger').length,
    [activeAlerts]
  );
  const warningCount = useMemo(
    () => activeAlerts.filter((a) => a.level === 'warning').length,
    [activeAlerts]
  );
  const infoCount = useMemo(
    () => activeAlerts.filter((a) => a.level === 'info').length,
    [activeAlerts]
  );

  return (
    <motion.div
      className="rounded-xl border border-gray-800 bg-[#161920] p-5"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }
      }
    >
      {/* 头部 */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <ShieldAlert size={16} className="text-[#D4AF37]" />
          <h2 className="text-sm font-semibold text-gray-200">智能提醒</h2>
          {unreadCount > 0 && (
            <span className="flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-[#EF4444] text-[10px] text-white font-bold">
              {unreadCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {activeAlerts.length === 0 && (
            <button
              onClick={restoreAll}
              className="text-[10px] text-text-tertiary hover:text-text-primary transition-colors duration-150 underline"
            >
              恢复全部
            </button>
          )}
          <Bell size={14} className="text-gray-500" />
        </div>
      </div>

      {/* 内容区：仪表盘 + 列表 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        {/* 左侧：风险仪表盘 */}
        <div className="md:col-span-1 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-gray-800 pb-4 md:pb-0 md:pr-4">
          <span className="text-[10px] uppercase tracking-[0.06em] text-gray-500 font-medium mb-2">
            综合风险等级
          </span>
          <RiskGauge riskLevel={riskLevel} />
          <div className="flex items-center gap-3 mt-3">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#EF4444]" />
              <span className="text-[10px] text-gray-500">
                危险 {dangerCount}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#F59E0B]" />
              <span className="text-[10px] text-gray-500">
                警告 {warningCount}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#3B82F6]" />
              <span className="text-[10px] text-gray-500">
                提示 {infoCount}
              </span>
            </div>
          </div>
        </div>

        {/* 右侧：提醒列表 */}
        <div className="md:col-span-3">
          <AnimatePresence mode="popLayout">
            {activeAlerts.length > 0 ? (
              <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1 custom-scrollbar">
                {activeAlerts.map((alert) => (
                  <AlertCard key={alert.id} alert={alert} onDismiss={dismissAlert} />
                ))}
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full min-h-[200px] gap-3"
              >
                <TrendingUp size={28} className="text-[#10B981] opacity-60" />
                <span className="text-sm text-gray-400">暂无提醒，市场处于正常状态</span>
                <span className="text-[10px] text-gray-500">所有指标均在安全区间内</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
