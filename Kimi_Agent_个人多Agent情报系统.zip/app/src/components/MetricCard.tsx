import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';

interface MetricCardProps {
  label: string;
  value: string | number;
  change?: number;
  changePercent?: number;
  sparklineData?: number[];
  delay?: number;
  className?: string;
}

function getSparklineColor(change: number): string {
  if (change > 0) return '#10B981';
  if (change < 0) return '#EF4444';
  return '#F59E0B';
}

export default function MetricCard({
  label,
  value,
  change = 0,
  changePercent,
  sparklineData,
  delay = 0,
  className,
}: MetricCardProps) {
  const [displayValue, setDisplayValue] = useState(0);
  const numericValue = typeof value === 'string' ? parseFloat(value) : value;
  const isNumeric = !isNaN(numericValue);

  useEffect(() => {
    if (!isNumeric) return;
    const duration = 800;
    const startTime = performance.now();
    const from = 0;
    const to = numericValue;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(from + (to - from) * eased);
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    const timer = setTimeout(() => {
      requestAnimationFrame(animate);
    }, delay * 1000 + 100);

    return () => clearTimeout(timer);
  }, [numericValue, isNumeric, delay]);

  const formattedDisplay = isNumeric
    ? numericValue < 10
      ? displayValue.toFixed(2)
      : numericValue < 100
        ? displayValue.toFixed(1)
        : Math.round(displayValue).toLocaleString()
    : value;

  const chartColor = getSparklineColor(change);

  const chartData = sparklineData
    ? sparklineData.map((v, i) => ({ i, v }))
    : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        delay,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className={cn(
        'card-gradient rounded-radius-lg border border-border-subtle shadow-card',
        'p-space-4 min-w-[180px] flex flex-col',
        'transition-all duration-250',
        'hover:translate-y-[-2px] hover:shadow-elevated hover:border-border-medium',
        className
      )}
    >
      <span className="caption text-text-tertiary uppercase tracking-[0.06em]">
        {label}
      </span>
      <span className="metric-value text-text-primary font-mono mt-space-2 text-[28px]">
        {formattedDisplay}
      </span>

      <div className="flex items-center gap-space-2 mt-space-1">
        {change !== 0 && (
          <span
            className={cn(
              'inline-flex items-center px-space-2 py-0.5 rounded-radius-full text-caption font-medium',
              change > 0
                ? 'bg-[rgba(16,185,129,0.12)] text-bullish'
                : change < 0
                  ? 'bg-[rgba(239,68,68,0.12)] text-bearish'
                  : 'bg-[rgba(245,158,11,0.12)] text-neutral'
            )}
          >
            {change > 0 ? '+' : ''}
            {changePercent !== undefined
              ? `${changePercent.toFixed(2)}%`
              : change.toFixed(2)}
          </span>
        )}
      </div>

      {sparklineData && sparklineData.length > 0 && (
        <div className="mt-space-3 h-[40px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id={`grad-${label}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={chartColor} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={chartColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="v"
                stroke={chartColor}
                strokeWidth={2}
                fill={`url(#grad-${label})`}
                isAnimationActive
                animationDuration={800}
                
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </motion.div>
  );
}
