import { useLocation, useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  TrendingUp,
  Sunrise,
  Sunset,
  Factory,
  Building2,
  AlertTriangle,
  Briefcase,
  PieChart,
  Settings,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { path: '/', label: '仪表盘', icon: LayoutDashboard },
  { path: '/macro', label: '宏观情绪', icon: TrendingUp },
  { path: '/morning', label: '早报', icon: Sunrise },
  { path: '/evening', label: '晚报', icon: Sunset },
  { path: '/industry', label: '行业深度', icon: Factory },
  { path: '/company', label: '公司分析', icon: Building2 },
  { path: '/devil', label: '反驳者', icon: AlertTriangle },
  { path: '/cio', label: 'CIO汇总', icon: Briefcase },
  { path: '/portfolio', label: '组合绩效', icon: PieChart },
  { path: '/settings', label: '系统设置', icon: Settings },
];

const itemVariants = {
  hidden: { opacity: 0, x: -10 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: {
      delay: i * 0.05,
      duration: 0.3,
      ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
    },
  }),
};

interface NavbarProps {
  collapsed?: boolean;
  mobile?: boolean;
  onNavigate?: () => void;
}

export default function Navbar({ collapsed = false, mobile = false, onNavigate }: NavbarProps) {
  const location = useLocation();
  const navigate = useNavigate();

  // 加载全站数据最后更新时间
  const [lastUpdate, setLastUpdate] = useState<string>('');
  const [appVersion, setAppVersion] = useState<string>('');
  useEffect(() => {
    fetch('/data/last_update.json')
      .then(r => r.json())
      .then(d => {
        setLastUpdate(d.displayText || '');
        setAppVersion(d.version || '');
      })
      .catch(() => {
        setLastUpdate('');
        setAppVersion('');
      });
  }, []);

  const getIsActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  const handleNavClick = (path: string) => {
    navigate(path);
    onNavigate?.();
  };

  // Mobile mode: render without logo section (it's in the drawer header)
  if (mobile) {
    return (
      <nav className="flex flex-col py-space-3 px-space-3 gap-space-1">
        {navItems.map((item, index) => {
          const isActive = getIsActive(item.path);
          const Icon = item.icon;

          return (
            <motion.button
              key={item.path}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={itemVariants}
              onClick={() => handleNavClick(item.path)}
              className={cn(
                'flex items-center gap-space-3 px-space-4 py-space-3 rounded-radius-md',
                'transition-all duration-200 text-left w-full',
                isActive
                  ? 'bg-bg-elevated border-l-[3px] border-gold-400'
                  : 'bg-transparent border-l-[3px] border-transparent hover:bg-bg-subtle'
              )}
            >
              <Icon
                size={20}
                className={isActive ? 'text-gold-400' : 'text-text-tertiary'}
              />
              <span
                className={cn(
                  'nav-label',
                  isActive ? 'text-text-primary' : 'text-text-secondary'
                )}
              >
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </nav>
    );
  }

  // Desktop mode
  return (
    <nav className="h-full w-full bg-bg-card border-r border-border-subtle flex flex-col">
      {/* Logo */}
      <div
        className={cn(
          'flex items-center gap-space-3 overflow-hidden transition-all duration-250',
          collapsed ? 'p-space-3 justify-center' : 'p-space-5'
        )}
      >
        <img src="/iwm-logo.svg" alt="IWM" className="w-10 h-10 flex-shrink-0" />
        {!collapsed && (
          <motion.span
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -8 }}
            transition={{ duration: 0.2 }}
            className="font-mono text-[20px] font-bold text-text-primary tracking-[-0.02em] whitespace-nowrap"
          >
            IWM
          </motion.span>
        )}
      </div>

      {/* Divider */}
      <div
        className={cn(
          'h-px divider-gradient transition-all duration-250',
          collapsed ? 'mx-space-3' : 'mx-space-4'
        )}
      />

      {/* Nav Items */}
      <div
        className={cn(
          'flex-1 py-space-4 flex flex-col gap-space-1 overflow-y-auto',
          collapsed ? 'px-space-2 items-center' : 'px-space-3'
        )}
      >
        {navItems.map((item, index) => {
          const isActive = getIsActive(item.path);
          const Icon = item.icon;

          return (
            <motion.button
              key={item.path}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={itemVariants}
              onClick={() => handleNavClick(item.path)}
              className={cn(
                'flex items-center rounded-radius-md transition-all duration-200 text-left',
                'hover:bg-bg-subtle group relative',
                isActive
                  ? 'bg-bg-elevated border-l-[3px] border-gold-400'
                  : 'bg-transparent border-l-[3px] border-transparent',
                collapsed
                  ? 'w-12 h-12 justify-center px-0'
                  : 'w-full px-space-4 py-space-3 gap-space-3'
              )}
              title={collapsed ? item.label : undefined}
            >
              <Icon
                size={20}
                className={cn(
                  'flex-shrink-0',
                  isActive ? 'text-gold-400' : 'text-text-tertiary group-hover:text-text-secondary'
                )}
              />
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className={cn(
                    'nav-label whitespace-nowrap',
                    isActive ? 'text-text-primary' : 'text-text-secondary'
                  )}
                >
                  {item.label}
                </motion.span>
              )}
              {/* Tooltip for collapsed state */}
              {collapsed && (
                <div
                  className={cn(
                    'absolute left-full ml-2 px-2.5 py-1.5 rounded-radius-md',
                    'bg-bg-elevated border border-border-subtle shadow-lg',
                    'text-sm text-text-primary whitespace-nowrap',
                    'opacity-0 invisible group-hover:opacity-100 group-hover:visible',
                    'transition-all duration-150 z-[80]'
                  )}
                >
                  {item.label}
                </div>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Bottom Section */}
      <div
        className={cn(
          'border-t border-border-subtle transition-all duration-250',
          collapsed ? 'p-space-3' : 'p-space-4'
        )}
      >
        {!collapsed ? (
          <>
            <p className="caption text-text-tertiary uppercase">
              最后更新: {lastUpdate || '加载中...'}
            </p>
            <p className="caption text-text-tertiary mt-space-1">IWM {appVersion}</p>
          </>
        ) : (
          <p className="caption text-text-tertiary text-center">{appVersion}</p>
        )}
      </div>
    </nav>
  );
}
