import { motion, AnimatePresence } from 'framer-motion';
import { Wifi, WifiOff } from 'lucide-react';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { cn } from '@/lib/utils';

/**
 * 全局网络状态指示器
 *
 * - 在线：在页面右上角显示绿色小圆点 + "数据实时"
 * - 离线：顶部固定红色横幅，提示当前为缓存数据
 *
 * 使用方式：直接放到 Layout 的 <main> 上方即可。
 */
export default function OfflineIndicator() {
  const { online, rtt, effectiveType } = useNetworkStatus();

  return (
    <>
      {/* ====== 离线横幅 ====== */}
      <AnimatePresence>
        {!online && (
          <motion.div
            initial={{ y: -36, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -36, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
            className={cn(
              'fixed top-0 left-0 right-0 z-[100] h-9',
              'flex items-center justify-center gap-2',
              'bg-[rgba(239,68,68,0.18)] backdrop-blur-md',
              'border-b border-[rgba(239,68,68,0.35)]',
              'text-xs text-[#EF4444] font-medium'
            )}
          >
            <WifiOff size={14} className="flex-shrink-0" />
            <span>
              ⚠️ 网络已断开，当前显示缓存数据。部分功能可能不可用。
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ====== 在线状态小圆点 ====== */}
      <AnimatePresence>
        {online && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.25 }}
            className="fixed top-3 right-6 z-[55] flex items-center gap-1.5"
            title={rtt !== null ? `延迟 ${rtt}ms / ${effectiveType}` : '网络在线'}
          >
            <span className="relative flex h-2.5 w-2.5">
              {/* 脉冲动画 */}
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#10B981] opacity-60" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#10B981]" />
            </span>
            <span className="text-[10px] text-[#10B981] font-medium hidden lg:inline">
              数据实时
            </span>
            {rtt !== null && (
              <span className="text-[10px] text-text-tertiary font-mono hidden xl:inline">
                {rtt}ms
              </span>
            )}
            <Wifi size={10} className="text-[#10B981] opacity-60 hidden xl:block" />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
