import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Loader2,
  Building2,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Landmark,
  Briefcase,
  BarChart3,
  Cpu,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ─── Data Types ─── */
interface Institution {
  name: string;
  type: string;
  aum: string;
  topHoldings: string[];
  recentMove: string;
  activity: string;
}

interface StockHolding {
  ticker: string;
  institutions: number;
  totalShares: string;
  pctFloat: number;
  pctChange: number;
  topBuyers: string[];
  topSellers: string[];
}

interface Institutional13FData {
  lastUpdate: string;
  quarter: string;
  summary: {
    totalInstitutions: number;
    totalValue: string;
    netInflow: string;
    topActivity: string;
  };
  topInstitutions: Institution[];
  stockHoldings: StockHolding[];
}

/* ─── Style Config ─── */
const typeConfig: Record<string, { color: string; bg: string; icon: typeof Building2 }> = {
  '被动指数': { color: 'text-blue-400', bg: 'bg-blue-400/10', icon: BarChart3 },
  '价值投资': { color: 'text-bullish', bg: 'bg-bullish/10', icon: Landmark },
  '宏观对冲': { color: 'text-purple-400', bg: 'bg-purple-400/10', icon: TrendingUp },
  '量化交易': { color: 'text-orange-400', bg: 'bg-orange-400/10', icon: Cpu },
  '积极主义': { color: 'text-pink-400', bg: 'bg-pink-400/10', icon: Zap },
};

function getTypeStyle(type: string) {
  return typeConfig[type] ?? { color: 'text-text-secondary', bg: 'bg-gray-500/10', icon: Briefcase };
}

function getMoveColor(move: string): string {
  if (move.includes('增持') || move.includes('新增')) return 'text-bullish';
  if (move.includes('减持')) return 'text-bearish';
  if (move.includes('建仓')) return 'text-info';
  return 'text-text-secondary';
}

function getMoveBg(move: string): string {
  if (move.includes('增持') || move.includes('新增')) return 'bg-bullish/10';
  if (move.includes('减持')) return 'bg-bearish/10';
  if (move.includes('建仓')) return 'bg-info/10';
  return 'bg-gray-500/10';
}

/* ─── Animation variants ─── */
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 12 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] },
  },
};

/* ─── Main Component ─── */
export default function InstitutionalHoldings({ ticker }: { ticker: string }) {
  const [data, setData] = useState<Institutional13FData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch('/data/institutional_13f.json')
      .then((res) => {
        if (!res.ok) throw new Error(`请求失败: ${res.status}`);
        return res.json();
      })
      .then((json: Institutional13FData) => {
        if (cancelled) return;
        setData(json);
        setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : '加载数据时出错');
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  const holding = useMemo(() => {
    if (!data) return null;
    return data.stockHoldings.find((s) => s.ticker === ticker) ?? null;
  }, [data, ticker]);

  /* ─── Loading State ─── */
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 size={28} className="animate-spin text-text-tertiary" />
        <span className="ml-3 text-text-secondary text-sm">加载机构持仓数据中...</span>
      </div>
    );
  }

  /* ─── Error State ─── */
  if (error) {
    return (
      <div className="flex items-center justify-center py-16 text-bearish">
        <AlertCircle size={20} className="mr-2" />
        <span className="text-sm">{error}</span>
      </div>
    );
  }

  /* ─── No Data State ─── */
  if (!holding) {
    return (
      <div className="flex items-center justify-center py-16 text-text-secondary">
        <AlertCircle size={20} className="mr-2" />
        <span className="text-sm">暂无该标的数据</span>
      </div>
    );
  }

  const { quarter, topInstitutions, summary } = data!;
  const { institutions, pctFloat, pctChange, topBuyers, topSellers } = holding;

  /* ─── Filter top institutions related to this ticker ─── */
  const relatedInstitutions = useMemo(() => {
    return topInstitutions.filter((inst) =>
      inst.topHoldings.includes(ticker) ||
      inst.recentMove.toLowerCase().includes(ticker.toLowerCase())
    );
  }, [topInstitutions, ticker]);

  /* ─── Use all top institutions if none directly related ─── */
  const displayInstitutions = relatedInstitutions.length > 0
    ? relatedInstitutions
    : topInstitutions;

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      {/* ── Module Header ── */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h2 className="card-title text-text-primary flex items-center gap-2">
            <Building2 size={18} className="text-purple-400" />
            机构持仓追踪（13F）
          </h2>
          <p className="caption text-text-tertiary mt-1">
            季度: {quarter} | 更新: {new Date(data!.lastUpdate).toLocaleString('zh-CN')}
          </p>
        </div>
        <span className="px-3 py-1 rounded-full text-sm font-semibold bg-purple-400/10 text-purple-400">
          {quarter}
        </span>
      </motion.div>

      {/* ── Holdings Overview Card ── */}
      <motion.div
        variants={itemVariants}
        className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left: Key Metrics */}
          <div className="space-y-4">
            <div>
              <span className="text-label">持仓机构数</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="metric-value text-text-primary text-3xl">
                  {institutions.toLocaleString('zh-CN')}
                </span>
                <span className="text-text-tertiary text-sm">家</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div>
                <span className="text-label">机构持股比例</span>
                <div className="mt-1">
                  <span className="metric-value text-text-primary text-xl">{pctFloat}%</span>
                </div>
              </div>
              <div className="w-[1px] h-10 bg-border-subtle" />
              <div>
                <span className="text-label">季度变化</span>
                <div className="flex items-center gap-1 mt-1">
                  {pctChange >= 0 ? (
                    <ArrowUpRight size={16} className="text-bullish" />
                  ) : (
                    <ArrowDownRight size={16} className="text-bearish" />
                  )}
                  <span className={cn(
                    'metric-value text-xl',
                    pctChange >= 0 ? 'text-bullish' : 'text-bearish'
                  )}>
                    {pctChange >= 0 ? '+' : ''}{pctChange}%
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-400/10">
                <Landmark size={14} className="text-purple-400" />
                <span className="text-xs text-purple-400">总机构 {summary.totalInstitutions.toLocaleString('zh-CN')}</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-info/10">
                <TrendingUp size={14} className="text-info" />
                <span className="text-xs text-info">{summary.netInflow}</span>
              </div>
            </div>
          </div>

          {/* Right: Top Buyers & Sellers */}
          <div className="space-y-4">
            <div>
              <span className="text-label flex items-center gap-1.5 mb-2">
                <TrendingUp size={12} className="text-bullish" />
                TOP买方机构
              </span>
              <div className="flex flex-wrap gap-2">
                {topBuyers.map((buyer, i) => (
                  <motion.button
                    key={i}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-3 py-1.5 rounded-full text-xs font-medium bg-bullish/10 text-bullish border border-bullish/20 hover:bg-bullish/20 transition-colors"
                  >
                    {buyer}
                  </motion.button>
                ))}
                {topBuyers.length === 0 && (
                  <span className="text-xs text-text-tertiary">暂无数据</span>
                )}
              </div>
            </div>

            <div>
              <span className="text-label flex items-center gap-1.5 mb-2">
                <TrendingDown size={12} className="text-bearish" />
                TOP卖方机构
              </span>
              <div className="flex flex-wrap gap-2">
                {topSellers.map((seller, i) => (
                  <motion.button
                    key={i}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-3 py-1.5 rounded-full text-xs font-medium bg-bearish/10 text-bearish border border-bearish/20 hover:bg-bearish/20 transition-colors"
                  >
                    {seller}
                  </motion.button>
                ))}
                {topSellers.length === 0 && (
                  <span className="text-xs text-text-tertiary">暂无数据</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── TOP Institutions Table ── */}
      <motion.div
        variants={itemVariants}
        className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
      >
        <h3 className="card-title text-text-primary mb-4">顶级机构持仓</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border-subtle">
                <th className="text-left py-3 px-3 text-label">机构</th>
                <th className="text-left py-3 px-3 text-label">类型</th>
                <th className="text-left py-3 px-3 text-label">AUM</th>
                <th className="text-left py-3 px-3 text-label">近期操作</th>
                <th className="text-left py-3 px-3 text-label">动态</th>
              </tr>
            </thead>
            <tbody>
              {displayInstitutions.map((inst, index) => {
                const style = getTypeStyle(inst.type);
                const TypeIcon = style.icon;
                return (
                  <motion.tr
                    key={index}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + index * 0.07, duration: 0.3 }}
                    className={cn(
                      'border-b border-border-subtle/50 hover:bg-bg-elevated/30 transition-colors',
                      index % 2 === 0 ? 'bg-transparent' : 'bg-white/[0.02]'
                    )}
                  >
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-md bg-bg-elevated flex items-center justify-center">
                          <Building2 size={14} className="text-text-secondary" />
                        </div>
                        <span className="text-sm font-medium text-text-primary">{inst.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className={cn('inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium', style.bg, style.color)}>
                        <TypeIcon size={12} />
                        {inst.type}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-sm text-text-primary font-mono">{inst.aum}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={cn('inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium', getMoveBg(inst.recentMove), getMoveColor(inst.recentMove))}>
                        {inst.recentMove.includes('增持') && <TrendingUp size={12} />}
                        {inst.recentMove.includes('减持') && <TrendingDown size={12} />}
                        {inst.recentMove.includes('新建') && <Plus size={12} />}
                        {inst.recentMove.includes('新增') && <Plus size={12} />}
                        {inst.recentMove}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-xs text-text-secondary">{inst.activity}</span>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* ── Institution Style Tags ── */}
      <motion.div
        variants={itemVariants}
        className="bg-gray-900/60 border border-gray-800 rounded-xl p-5"
      >
        <h3 className="card-title text-text-primary mb-4">机构风格分布</h3>
        <div className="flex flex-wrap gap-3">
          {Object.entries(typeConfig).map(([type, config]) => {
            const count = topInstitutions.filter((i) => i.type === type).length;
            const TypeIcon = config.icon;
            return (
              <motion.div
                key={type}
                whileHover={{ scale: 1.05, y: -2 }}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 rounded-lg border cursor-default',
                  config.bg,
                  'border-opacity-20',
                  config.color.replace('text-', 'border-')
                )}
              >
                <TypeIcon size={16} className={config.color} />
                <span className={cn('text-sm font-medium', config.color)}>{type}</span>
                {count > 0 && (
                  <span className={cn('text-xs px-1.5 py-0.5 rounded-full', config.bg, config.color)}>
                    {count}
                  </span>
                )}
              </motion.div>
            );
          })}
        </div>
        <p className="text-xs text-text-tertiary mt-3">
          不同颜色的标签代表机构的投资风格，点击机构名称可查看详情
        </p>
      </motion.div>
    </motion.div>
  );
}
