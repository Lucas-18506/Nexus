import { Outlet } from 'react-router';
import Navbar from './Navbar';
import StatusBar from './StatusBar';
import SymbolSearch from './SymbolSearch';
import ThemeToggle from './ThemeToggle';
import OfflineIndicator from '@/components/OfflineIndicator';

export default function Layout() {
  return (
    <div className="flex h-screen bg-gray-950 text-gray-100">
      {/* Sidebar */}
      <div className="w-[260px] min-w-[260px] h-screen overflow-y-auto border-r border-gray-800 bg-[#111827]">
        <Navbar />
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top Bar: Search + Theme Toggle */}
        <div className="flex items-center justify-end gap-3 px-6 py-2 border-b border-gray-800/50 bg-[#0c1120]/50">
          <SymbolSearch />
          <ThemeToggle />
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <OfflineIndicator />
          <Outlet />
        </div>
        <StatusBar />
      </div>
    </div>
  );
}
