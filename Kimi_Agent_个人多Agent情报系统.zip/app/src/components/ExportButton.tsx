import { useState, useCallback, useRef, useEffect } from 'react';
import { Download, ChevronDown, FileJson, FileSpreadsheet, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ─────────────────────── 类型 ─────────────────────── */

export interface ExportButtonProps {
  data: unknown;
  filename?: string;
  type?: 'json' | 'csv' | 'pdf';
}

/* ─────────────────────── 辅助函数 ─────────────────────── */

/** 扁平化对象为键值对（用于 CSV 表头提取） */
function flattenObject(obj: unknown, prefix = ''): Record<string, string> {
  const result: Record<string, string> = {};

  if (obj === null || obj === undefined) {
    result[prefix] = '';
    return result;
  }

  if (typeof obj !== 'object') {
    result[prefix] = String(obj);
    return result;
  }

  if (Array.isArray(obj)) {
    if (obj.length === 0) {
      result[prefix] = '';
    } else {
      // 对于数组，取第一个元素来推断结构
      const first = obj[0];
      if (first !== null && typeof first === 'object' && !Array.isArray(first)) {
        for (const [key, val] of Object.entries(first)) {
          const newKey = prefix ? `${prefix}.${key}` : key;
          const flat = flattenObject(val, newKey);
          Object.assign(result, flat);
        }
      } else {
        result[prefix] = JSON.stringify(obj);
      }
    }
    return result;
  }

  for (const [key, val] of Object.entries(obj as Record<string, unknown>)) {
    const newKey = prefix ? `${prefix}.${key}` : key;
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      const flat = flattenObject(val, newKey);
      Object.assign(result, flat);
    } else if (Array.isArray(val)) {
      if (val.length > 0 && typeof val[0] === 'object') {
        result[newKey] = JSON.stringify(val);
      } else {
        result[newKey] = val.join('; ');
      }
    } else {
      result[newKey] = val === null || val === undefined ? '' : String(val);
    }
  }

  return result;
}

/** 将数据转为 CSV 字符串 */
function toCsv(data: unknown): string {
  if (!data) return '';

  let rows: unknown[];
  if (Array.isArray(data)) {
    rows = data;
  } else if (typeof data === 'object' && data !== null) {
    // 如果是对象，尝试找到其中的数组
    const obj = data as Record<string, unknown>;
    const arrKey = Object.keys(obj).find((k) => Array.isArray(obj[k]));
    if (arrKey) {
      rows = obj[arrKey] as unknown[];
    } else {
      rows = [data];
    }
  } else {
    rows = [data];
  }

  if (rows.length === 0) return '';

  // 提取表头
  const allKeys = new Set<string>();
  for (const row of rows) {
    if (row !== null && typeof row === 'object' && !Array.isArray(row)) {
      const flat = flattenObject(row);
      for (const key of Object.keys(flat)) {
        allKeys.add(key);
      }
    }
  }

  const headers = Array.from(allKeys);
  if (headers.length === 0) return '';

  // 构建 CSV
  const escapeCsv = (val: string): string => {
    if (val.includes(',') || val.includes('"') || val.includes('\n')) {
      return `"${val.replace(/"/g, '""')}"`;
    }
    return val;
  };

  const lines: string[] = [];
  lines.push(headers.map(escapeCsv).join(','));

  for (const row of rows) {
    if (row !== null && typeof row === 'object' && !Array.isArray(row)) {
      const flat = flattenObject(row);
      const values = headers.map((h) => escapeCsv(flat[h] ?? ''));
      lines.push(values.join(','));
    } else {
      lines.push(escapeCsv(String(row)));
    }
  }

  return lines.join('\n');
}

/** 触发文件下载 */
function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/* ─────────────────────── 导出选项类型 ─────────────────────── */

type ExportType = 'json' | 'csv' | 'pdf';

interface ExportOption {
  type: ExportType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  mimeType: string;
  ext: string;
}

const EXPORT_OPTIONS: ExportOption[] = [
  { type: 'json', label: '导出 JSON', icon: FileJson, mimeType: 'application/json', ext: 'json' },
  { type: 'csv', label: '导出 CSV', icon: FileSpreadsheet, mimeType: 'text/csv;charset=utf-8', ext: 'csv' },
  { type: 'pdf', label: '导出 PDF', icon: Printer, mimeType: '', ext: '' },
];

/* ─────────────────────── 主组件 ─────────────────────── */

function ExportButton({ data, filename = 'export', type }: ExportButtonProps) {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // 如果指定了 type，渲染单一导出按钮
  if (type) {
    return <SingleExportButton data={data} filename={filename} type={type} />;
  }

  // 点击外部关闭下拉
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }

    if (open) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [open]);

  const handleExport = useCallback(
    (option: ExportOption) => {
      if (option.type === 'pdf') {
        handlePdfExport();
      } else if (option.type === 'json') {
        handleJsonExport(data, filename);
      } else if (option.type === 'csv') {
        handleCsvExport(data, filename);
      }
      setOpen(false);
    },
    [data, filename]
  );

  return (
    <div ref={dropdownRef} className="relative inline-block">
      <Button
        variant="outline"
        size="sm"
        className="gap-1.5 bg-background border-border text-foreground hover:bg-accent hover:text-accent-foreground"
        onClick={() => setOpen((prev) => !prev)}
      >
        <Download className="size-4" />
        <span className="hidden sm:inline">导出</span>
        <ChevronDown
          className={cn('size-3 transition-transform duration-200', open && 'rotate-180')}
        />
      </Button>

      {open && (
        <div className="absolute right-0 top-full mt-1.5 z-50 min-w-[10rem] rounded-md border border-border bg-popover p-1 shadow-md animate-in fade-in-0 zoom-in-95 data-[side=bottom]:slide-in-from-top-2">
          {EXPORT_OPTIONS.map((option) => {
            const Icon = option.icon;
            return (
              <button
                key={option.type}
                onClick={() => handleExport(option)}
                className="relative flex w-full cursor-default items-center gap-2 rounded-sm px-2.5 py-2 text-sm text-popover-foreground outline-none transition-colors hover:bg-accent hover:text-accent-foreground select-none"
              >
                <Icon className="size-4 text-muted-foreground" />
                <span>{option.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ─────────────────────── 单一导出按钮 ─────────────────────── */

function SingleExportButton({ data, filename, type }: Required<ExportButtonProps>) {
  const handleClick = useCallback(() => {
    if (type === 'pdf') {
      handlePdfExport();
    } else if (type === 'json') {
      handleJsonExport(data, filename);
    } else if (type === 'csv') {
      handleCsvExport(data, filename);
    }
  }, [data, filename, type]);

  const option = EXPORT_OPTIONS.find((o) => o.type === type);
  const Icon = option?.icon ?? Download;
  const label = option?.label ?? '导出';

  return (
    <Button
      variant="outline"
      size="sm"
      className="gap-1.5 bg-background border-border text-foreground hover:bg-accent hover:text-accent-foreground"
      onClick={handleClick}
    >
      <Icon className="size-4" />
      <span className="hidden sm:inline">{label}</span>
    </Button>
  );
}

/* ─────────────────────── 导出逻辑 ─────────────────────── */

function handleJsonExport(data: unknown, filename: string): void {
  try {
    const json = JSON.stringify(data, null, 2);
    downloadFile(json, `${filename}.json`, 'application/json');
  } catch (err) {
    console.error('JSON 导出失败:', err);
  }
}

function handleCsvExport(data: unknown, filename: string): void {
  try {
    const csv = '\ufeff' + toCsv(data);
    downloadFile(csv, `${filename}.csv`, 'text/csv;charset=utf-8');
  } catch (err) {
    console.error('CSV 导出失败:', err);
  }
}

function handlePdfExport(): void {
  // 触发浏览器打印，用户可选择保存为 PDF
  setTimeout(() => {
    window.print();
  }, 100);
}

export default ExportButton;
