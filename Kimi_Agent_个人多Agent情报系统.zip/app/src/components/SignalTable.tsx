import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import VerdictBadge from './VerdictBadge';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';

interface SignalRow {
  asset: string;
  signal: string;
  entry?: string;
  target?: string;
  stop?: string;
  riskReward?: string;
  trend?: number[];
  value?: string;
  change?: number;
}

interface SignalTableProps {
  rows: SignalRow[];
  columns: string[];
  delay?: number;
  className?: string;
}

function getSignalColor(signal: string): string {
  const s = signal.toUpperCase();
  if (s === 'BULLISH' || s === 'BUY' || s === 'ADD') return '#10B981';
  if (s === 'BEARISH' || s === 'SELL' || s === 'TRIM') return '#EF4444';
  return '#F59E0B';
}

export default function SignalTable({
  rows,
  columns,
  delay = 0,
  className,
}: SignalTableProps) {
  return (
    <div className={cn('w-full overflow-x-auto', className)}>
      <table className="w-full">
        {/* Header */}
        <thead>
          <tr className="bg-bg-elevated">
            {columns.map((col) => (
              <th
                key={col}
                className="caption text-text-tertiary uppercase tracking-[0.06em] text-left px-space-4 py-space-3 font-medium"
              >
                {col}
              </th>
            ))}
          </tr>
        </thead>

        {/* Body */}
        <tbody>
          {rows.map((row, index) => {
            const signalColor = getSignalColor(row.signal);
            const chartData = row.trend
              ? row.trend.map((v, i) => ({ i, v }))
              : [];

            return (
              <motion.tr
                key={row.asset}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.3,
                  delay: delay + index * 0.04,
                  ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
                }}
                className={cn(
                  'border-b border-border-subtle cursor-pointer',
                  'transition-colors duration-150 hover:bg-bg-subtle',
                  index % 2 === 0 ? 'bg-bg-card' : 'bg-[rgba(35,40,55,0.5)]'
                )}
                style={{ borderLeft: `3px solid ${signalColor}` }}
              >
                {/* Asset */}
                <td className="px-space-4 py-space-3">
                  <span className="metric-label text-text-primary font-mono">
                    {row.asset}
                  </span>
                </td>

                {/* Signal */}
                <td className="px-space-4 py-space-3">
                  <VerdictBadge verdict={row.signal} size="sm" />
                </td>

                {/* Entry */}
                {row.entry !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span className="body-sm text-text-secondary font-mono">
                      {row.entry}
                    </span>
                  </td>
                )}

                {/* Target */}
                {row.target !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span className="body-sm text-text-secondary font-mono">
                      {row.target}
                    </span>
                  </td>
                )}

                {/* Stop */}
                {row.stop !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span className="body-sm text-text-secondary font-mono">
                      {row.stop}
                    </span>
                  </td>
                )}

                {/* Risk/Reward */}
                {row.riskReward !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span className="body-sm text-info font-mono font-medium">
                      {row.riskReward}
                    </span>
                  </td>
                )}

                {/* Value */}
                {row.value !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span className="body-sm text-text-secondary font-mono">
                      {row.value}
                    </span>
                  </td>
                )}

                {/* Change */}
                {row.change !== undefined && (
                  <td className="px-space-4 py-space-3">
                    <span
                      className={cn(
                        'body-sm font-mono font-medium',
                        row.change > 0 ? 'text-bullish' : row.change < 0 ? 'text-bearish' : 'text-neutral'
                      )}
                    >
                      {row.change > 0 ? '+' : ''}
                      {typeof row.change === 'number' ? row.change.toFixed(2) : row.change}%
                    </span>
                  </td>
                )}

                {/* Trend Sparkline */}
                {row.trend !== undefined && row.trend.length > 0 && (
                  <td className="px-space-4 py-space-3">
                    <div className="w-[60px] h-[24px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                          <defs>
                            <linearGradient id={`trend-${row.asset}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor={signalColor} stopOpacity={0.3} />
                              <stop offset="100%" stopColor={signalColor} stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <Area
                            type="monotone"
                            dataKey="v"
                            stroke={signalColor}
                            strokeWidth={1.5}
                            fill={`url(#trend-${row.asset})`}
                            isAnimationActive
                            animationDuration={600}
                            
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </td>
                )}
              </motion.tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
