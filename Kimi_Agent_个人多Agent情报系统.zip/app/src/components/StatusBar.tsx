import { useEffect, useRef, useState } from "react";
import { Wifi, Clock, RefreshCw, Code } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  纯 CSS 脉冲 keyframes（通过全局 style 标签注入，避免 Framer Motion） */
/* ------------------------------------------------------------------ */
const pulseStyles = `
@keyframes status-pulse {
  0%   { box-shadow: 0 0 0 0 rgba(34,197,94,0.5); }
  50%  { box-shadow: 0 0 0 4px rgba(34,197,94,0); }
  100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
}
@keyframes status-pulse-disconnected {
  0%   { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
  50%  { box-shadow: 0 0 0 4px rgba(239,68,68,0); }
  100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
}
@keyframes spin-once {
  0%   { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
`;

/** 格式化时间为 HH:MM:SS */
function fmtTime(d: Date): string {
  return d.toLocaleTimeString("zh-CN", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

/** 将秒数格式化为 MM:SS */
function fmtCountdown(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60)
    .toString()
    .padStart(2, "0");
  const s = (totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function StatusBar() {
  const [connected] = useState(true);
  const [latency] = useState(125); // ms，模拟值
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [countdown, setCountdown] = useState(60);
  const [spinning, setSpinning] = useState(false);

  const countdownRef = useRef(60);
  countdownRef.current = countdown;

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // 触发刷新
          setLastRefresh(new Date());
          setSpinning(true);
          setTimeout(() => setSpinning(false), 800);
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <>
      {/* 注入 CSS keyframes */}
      <style>{pulseStyles}</style>

      <footer
        className="flex items-center justify-between shrink-0"
        style={{
          height: 32,
          paddingLeft: 16,
          paddingRight: 16,
          backgroundColor: "#0a0f1a",
          borderTop: "1px solid rgba(255,255,255,0.04)",
          fontSize: 12,
          color: "#5C6375",
        }}
      >
        {/* ── 左侧：连接状态 ── */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {/* 脉冲状态点 */}
            <span
              style={{
                display: "inline-block",
                width: 6,
                height: 6,
                borderRadius: "50%",
                backgroundColor: connected ? "#22C55E" : "#EF4444",
                animation: connected
                  ? "status-pulse 2s infinite"
                  : "status-pulse-disconnected 2s infinite",
              }}
            />
            <Wifi size={12} />
            <span>{connected ? "数据连接正常" : "连接断开"}</span>
          </div>
        </div>

        {/* ── 中间：数据刷新 ── */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Clock size={12} />
            <span>数据延迟: {latency}ms</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock size={12} />
            <span>上次刷新: {fmtTime(lastRefresh)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <RefreshCw
              size={12}
              style={{
                animation: spinning ? "spin-once 0.8s linear" : "none",
              }}
            />
            <span>下次刷新: {fmtCountdown(countdown)}</span>
          </div>
        </div>

        {/* ── 右侧：系统信息 ── */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Code size={12} />
            <span>IWM v2.5.0</span>
          </div>
          <span>React 19 + TypeScript</span>
          <span>Lightweight Charts v5</span>
        </div>
      </footer>
    </>
  );
}
