import React, { useState, useCallback } from 'react';
import {
  Globe,
  Database,
  CreditCard,
  HardDrive,
  Eye,
  EyeOff,
  KeyRound,
  Activity,
  Newspaper,
  Wrench,
  Check,
  TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

// ─── 数据源类型定义 ─────────────────────────────────────

interface DataSource {
  id: string;
  name: string;
  market: string;
  apiKeyRequired: boolean;
  freeTier: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

// ─── 数据源列表 ─────────────────────────────────────────

const DATA_SOURCES: DataSource[] = [
  {
    id: 'finnhub',
    name: 'FinnHub',
    market: '美股/全球',
    apiKeyRequired: true,
    freeTier: '60次/分',
    icon: Globe,
    description: '全球股票、外汇、加密货币实时数据',
  },
  {
    id: 'akshare',
    name: 'AKShare',
    market: 'A股/期货/宏观',
    apiKeyRequired: false,
    freeTier: '完全免费',
    icon: Database,
    description: '开源中文金融数据接口库',
  },
  {
    id: 'tushare',
    name: 'Tushare Pro',
    market: 'A股/港股',
    apiKeyRequired: true,
    freeTier: '积分制',
    icon: CreditCard,
    description: '专业级中国金融数据平台',
  },
  {
    id: 'baostock',
    name: 'Baostock',
    market: 'A股/港股',
    apiKeyRequired: false,
    freeTier: '完全免费',
    icon: HardDrive,
    description: '免费开源量化数据接口',
  },
];

const A_SHARE_SOURCES = DATA_SOURCES.filter(s => s.id !== 'finnhub');

// ─── localStorage Key ───────────────────────────────────

const STORAGE_KEY = 'iwm-datasource-config';

interface DataSourceConfig {
  aShareDefault: string;
  apiKeys: Record<string, string>;
  realtimeData: boolean;
  onlineNews: boolean;
  onlineTools: boolean;
}

const DEFAULT_CONFIG: DataSourceConfig = {
  aShareDefault: 'akshare',
  apiKeys: {},
  realtimeData: true,
  onlineNews: true,
  onlineTools: false,
};

function loadConfig(): DataSourceConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_CONFIG;
    return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CONFIG;
  }
}

function saveConfig(config: DataSourceConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // 忽略存储错误
  }
}

// ─── 数据源卡片 ─────────────────────────────────────────

interface DataSourceCardProps {
  source: DataSource;
  apiKey: string;
  isDefault: boolean;
  onApiKeyChange: (id: string, key: string) => void;
  onSetDefault: (id: string) => void;
}

function DataSourceCard({
  source,
  apiKey,
  isDefault,
  onApiKeyChange,
  onSetDefault,
}: DataSourceCardProps) {
  const [showKey, setShowKey] = useState(false);
  const Icon = source.icon;

  return (
    <Card
      className={cn(
        'transition-all duration-200',
        isDefault
          ? 'border-amber-500/60 ring-1 ring-amber-500/30'
          : 'border-border/60 hover:border-border'
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                'flex size-9 items-center justify-center rounded-lg',
                isDefault ? 'bg-amber-500/15 text-amber-400' : 'bg-muted text-muted-foreground'
              )}
            >
              <Icon className="size-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <CardTitle className="text-sm font-semibold">{source.name}</CardTitle>
                {isDefault && (
                  <Badge
                    variant="outline"
                    className="border-amber-500/40 bg-amber-500/10 text-amber-400 text-[10px] px-1.5 py-0"
                  >
                    <Check className="mr-0.5 size-2.5" />
                    默认
                  </Badge>
                )}
              </div>
              <CardDescription className="text-xs">{source.market}</CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className="text-[10px]">
            {source.freeTier}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-3 pt-0">
        <p className="text-xs text-muted-foreground">{source.description}</p>

        {/* API Key 输入 */}
        {source.apiKeyRequired && (
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
              <KeyRound className="size-3" />
              API Key
            </Label>
            <div className="relative">
              <Input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => onApiKeyChange(source.id, e.target.value)}
                placeholder="输入 API Key..."
                className="h-8 pr-9 text-xs font-mono"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {showKey ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
              </button>
            </div>
          </div>
        )}

        {/* 设为默认按钮 */}
        <Button
          variant={isDefault ? 'default' : 'outline'}
          size="sm"
          className={cn(
            'h-7 text-xs gap-1.5 w-full',
            isDefault && 'bg-amber-600 hover:bg-amber-700'
          )}
          onClick={() => onSetDefault(source.id)}
          disabled={isDefault}
        >
          {isDefault ? (
            <>
              <Check className="size-3" />
              当前默认
            </>
          ) : (
            <>
              <TrendingUp className="size-3" />
              设为A股默认
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

// ─── 主面板组件 ─────────────────────────────────────────

export default function DataSourcePanel() {
  const [config, setConfig] = useState<DataSourceConfig>(loadConfig);

  // 配置变更时自动持久化
  const persist = useCallback((updates: Partial<DataSourceConfig>) => {
    setConfig(prev => {
      const next = { ...prev, ...updates };
      saveConfig(next);
      return next;
    });
  }, []);

  const handleApiKeyChange = useCallback(
    (id: string, key: string) => {
      persist({
        apiKeys: { ...config.apiKeys, [id]: key },
      });
    },
    [config.apiKeys, persist]
  );

  const handleSetDefault = useCallback(
    (id: string) => {
      persist({ aShareDefault: id });
    },
    [persist]
  );

  const handleToggle = useCallback(
    (key: keyof Pick<DataSourceConfig, 'realtimeData' | 'onlineNews' | 'onlineTools'>) => {
      return (checked: boolean) => {
        persist({ [key]: checked });
      };
    },
    [persist]
  );

  return (
    <div className="space-y-6">
      {/* 头部信息 */}
      <div>
        <h2 className="text-lg font-semibold">数据源配置</h2>
        <p className="text-sm text-muted-foreground mt-0.5">
          配置金融数据接口和在线服务开关
        </p>
      </div>

      {/* 功能开关 */}
      <Card className="border-border/60">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Activity className="size-4 text-emerald-400" />
            在线功能开关
          </CardTitle>
          <CardDescription className="text-xs">
            控制实时数据和在线服务的启用状态
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 实时数据 */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex size-8 items-center justify-center rounded-md bg-emerald-500/10 text-emerald-400">
                <Activity className="size-4" />
              </div>
              <div>
                <div className="text-sm font-medium">实时数据</div>
                <div className="text-xs text-muted-foreground">
                  获取实时行情和交易数据
                </div>
              </div>
            </div>
            <Switch
              checked={config.realtimeData}
              onCheckedChange={handleToggle('realtimeData')}
            />
          </div>

          {/* 在线新闻 */}
          <div className="flex items-center justify-between border-t border-border/40 pt-3">
            <div className="flex items-center gap-3">
              <div className="flex size-8 items-center justify-center rounded-md bg-sky-500/10 text-sky-400">
                <Newspaper className="size-4" />
              </div>
              <div>
                <div className="text-sm font-medium">在线新闻</div>
                <div className="text-xs text-muted-foreground">
                  获取财经新闻和市场资讯
                </div>
              </div>
            </div>
            <Switch
              checked={config.onlineNews}
              onCheckedChange={handleToggle('onlineNews')}
            />
          </div>

          {/* 在线工具 */}
          <div className="flex items-center justify-between border-t border-border/40 pt-3">
            <div className="flex items-center gap-3">
              <div className="flex size-8 items-center justify-center rounded-md bg-violet-500/10 text-violet-400">
                <Wrench className="size-4" />
              </div>
              <div>
                <div className="text-sm font-medium">在线工具</div>
                <div className="text-xs text-muted-foreground">
                  启用在线分析工具和计算器
                </div>
              </div>
            </div>
            <Switch
              checked={config.onlineTools}
              onCheckedChange={handleToggle('onlineTools')}
            />
          </div>
        </CardContent>
      </Card>

      {/* A股默认数据源 */}
      <Card className="border-border/60">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <TrendingUp className="size-4 text-amber-400" />
            A股默认数据源
          </CardTitle>
          <CardDescription className="text-xs">
            选择A股数据获取的优先数据源
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={config.aShareDefault} onValueChange={handleSetDefault}>
            <SelectTrigger className="h-8 text-xs w-full">
              <SelectValue placeholder="选择A股默认数据源" />
            </SelectTrigger>
            <SelectContent>
              {A_SHARE_SOURCES.map(s => (
                <SelectItem key={s.id} value={s.id} className="text-xs">
                  <span className="flex items-center gap-2">
                    <s.icon className="size-3.5" />
                    <span>{s.name}</span>
                    <span className="text-muted-foreground">— {s.market}</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* 数据源卡片网格 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {DATA_SOURCES.map(source => (
          <DataSourceCard
            key={source.id}
            source={source}
            apiKey={config.apiKeys[source.id] || ''}
            isDefault={config.aShareDefault === source.id}
            onApiKeyChange={handleApiKeyChange}
            onSetDefault={handleSetDefault}
          />
        ))}
      </div>
    </div>
  );
}
