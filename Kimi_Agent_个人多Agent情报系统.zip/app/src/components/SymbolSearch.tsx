import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { Search } from 'lucide-react';

/* ── 类型 ─────────────────────────────────────────────── */
interface Stock {
  ticker: string;
  name: string;
  sector: string;
  exchange: 'NASDAQ' | 'NYSE' | 'HKEX';
}

/* ── 标的常量数据 ────────────────────────────────────── */
const STOCKS: Stock[] = [
  { ticker: 'NVDA', name: '英伟达', sector: '科技', exchange: 'NASDAQ' },
  { ticker: 'TSLA', name: '特斯拉', sector: '科技', exchange: 'NASDAQ' },
  { ticker: 'AAPL', name: '苹果', sector: '科技', exchange: 'NASDAQ' },
  { ticker: 'MSFT', name: '微软', sector: '科技', exchange: 'NASDAQ' },
  { ticker: 'GOOGL', name: '谷歌', exchange: 'NASDAQ', sector: '科技' },
  { ticker: 'AMZN', name: '亚马逊', exchange: 'NASDAQ', sector: '消费' },
  { ticker: 'META', name: 'Meta', exchange: 'NASDAQ', sector: '科技' },
  { ticker: '0700.HK', name: '腾讯控股', exchange: 'HKEX', sector: '科技' },
  { ticker: 'BABA', name: '阿里巴巴', exchange: 'NYSE', sector: '消费' },
  { ticker: 'JD', name: '京东', exchange: 'NASDAQ', sector: '消费' },
  { ticker: 'NIO', name: '蔚来', exchange: 'NYSE', sector: '汽车' },
  { ticker: '1211.HK', name: '比亚迪', exchange: 'HKEX', sector: '汽车' },
  { ticker: 'AMD', name: 'AMD', exchange: 'NASDAQ', sector: '科技' },
  { ticker: 'AVGO', name: '博通', exchange: 'NASDAQ', sector: '科技' },
  { ticker: 'INTC', name: '英特尔', exchange: 'NASDAQ', sector: '科技' },
  { ticker: 'CRM', name: 'Salesforce', exchange: 'NYSE', sector: '科技' },
  { ticker: 'NFLX', name: 'Netflix', exchange: 'NASDAQ', sector: '消费' },
  { ticker: 'GLD', name: '黄金ETF', exchange: 'NYSE', sector: '商品' },
  { ticker: 'TLT', name: '长期国债ETF', exchange: 'NASDAQ', sector: '债券' },
  { ticker: 'VIXY', name: 'VIX短期期货', exchange: 'NYSE', sector: '衍生品' },
];

/* ── 交易所标签配色 ──────────────────────────────────── */
const EXCHANGE_COLORS: Record<string, { bg: string; text: string }> = {
  NASDAQ: { bg: '#1E3A5F', text: '#60A5FA' },
  NYSE:   { bg: '#1B4332', text: '#4ADE80' },
  HKEX:   { bg: '#4C1D1D', text: '#F87171' },
};

/* ── 主组件 ──────────────────────────────────────────── */
export default function SymbolSearch() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const selectedRef = useRef<HTMLDivElement>(null);

  /* ── 过滤结果（模糊匹配） ──────────────────────────── */
  const filtered = useMemo(() => {
    const trimmed = query.trim();
    if (!trimmed) return STOCKS;
    const lower = trimmed.toLowerCase();
    return STOCKS.filter(
      (s) =>
        s.ticker.toLowerCase().includes(lower) ||
        s.name.toLowerCase().includes(lower)
    );
  }, [query]);

  /* ── 打开面板时自动聚焦 + 重置选中 ─────────────────── */
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      // 稍微延迟确保DOM渲染后再聚焦
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  /* ── 选中项变化时滚动到可视区域 ────────────────────── */
  useEffect(() => {
    selectedRef.current?.scrollIntoView({ block: 'nearest' });
  }, [selectedIndex]);

  /* ── 全局键盘事件监听 ──────────────────────────────── */
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      /* Cmd/Ctrl + K 打开 */
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
        return;
      }

      if (!isOpen) return;

      /* ESC 关闭 */
      if (e.key === 'Escape') {
        e.preventDefault();
        setIsOpen(false);
        return;
      }

      /* 上下箭头选择 */
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.min(prev + 1, filtered.length - 1));
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
        return;
      }

      /* Enter 跳转 */
      if (e.key === 'Enter' && filtered[selectedIndex]) {
        e.preventDefault();
        handleSelect(filtered[selectedIndex].ticker);
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filtered, selectedIndex]);

  /* ── 选择结果跳转 ──────────────────────────────────── */
  const handleSelect = useCallback(
    (ticker: string) => {
      setIsOpen(false);
      setQuery('');
      navigate(`/company/${encodeURIComponent(ticker)}`);
    },
    [navigate]
  );

  /* ── 选中索引在结果变化时保护 ──────────────────────── */
  useEffect(() => {
    if (selectedIndex >= filtered.length) {
      setSelectedIndex(Math.max(filtered.length - 1, 0));
    }
  }, [filtered, selectedIndex]);

  /* ── 操作系统判断（快捷键显示） ────────────────────── */
  const isMac = useMemo(
    () => typeof navigator !== 'undefined' && /Mac/.test(navigator.platform),
    []
  );
  const shortcutLabel = isMac ? '⌘K' : 'Ctrl+K';

  return (
    <>
      {/* ── 触发按钮（搜索图标） ──────────────────────── */}
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center justify-center w-9 h-9 rounded-lg bg-[#1C1F2B] border border-[#2A2D3A] text-gray-400 hover:text-gray-200 hover:border-gray-600 transition-all duration-200 cursor-pointer"
        title={`搜索 (${shortcutLabel})`}
        type="button"
      >
        <Search size={16} />
      </button>

      {/* ── 模态覆盖层 ────────────────────────────────── */}
      {isOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[120px]"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsOpen(false);
          }}
        >
          {/* 搜索面板 */}
          <div
            className="w-[500px] max-h-[400px] flex flex-col rounded-xl border border-[#2A2D3A] shadow-2xl overflow-hidden"
            style={{ backgroundColor: '#1C1F2B' }}
          >
            {/* ── 输入框 ──────────────────────────── */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-[#2A2D3A]">
              <Search size={18} className="text-gray-500 flex-shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                placeholder="搜索股票代码或名称..."
                className="flex-1 bg-transparent text-sm text-gray-100 placeholder-gray-500 outline-none"
              />
              <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[11px] font-mono text-gray-500 bg-[#0F1117] border border-[#2A2D3A] select-none">
                {shortcutLabel}
              </span>
            </div>

            {/* ── 搜索结果列表 ──────────────────── */}
            <div ref={listRef} className="flex-1 overflow-y-auto py-2">
              {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-gray-500">
                  <Search size={28} className="mb-2 opacity-40" />
                  <p className="text-sm">未找到匹配的标的</p>
                </div>
              ) : (
                filtered.map((stock, index) => {
                  const exchangeColor = EXCHANGE_COLORS[stock.exchange] ?? {
                    bg: '#2A2D3A',
                    text: '#94A3B8',
                  };
                  const isSelected = index === selectedIndex;

                  return (
                    <div
                      key={stock.ticker}
                      ref={isSelected ? selectedRef : null}
                      onClick={() => handleSelect(stock.ticker)}
                      onMouseEnter={() => setSelectedIndex(index)}
                      className="flex items-center gap-3 px-4 py-2.5 cursor-pointer transition-colors duration-150"
                      style={{
                        backgroundColor: isSelected ? '#252836' : 'transparent',
                        borderLeft:
                          isSelected
                            ? '2px solid #D4AF37'
                            : '2px solid transparent',
                      }}
                    >
                      {/* Ticker（金色） */}
                      <span
                        className="text-sm font-bold w-[72px] flex-shrink-0"
                        style={{ color: '#D4AF37' }}
                      >
                        {stock.ticker}
                      </span>

                      {/* 中文名称 */}
                      <span className="text-sm text-gray-200 flex-1 min-w-0 truncate">
                        {stock.name}
                      </span>

                      {/* 交易所标签 */}
                      <span
                        className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium flex-shrink-0"
                        style={{
                          backgroundColor: exchangeColor.bg,
                          color: exchangeColor.text,
                        }}
                      >
                        {stock.exchange}
                      </span>

                      {/* 行业标签 */}
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium flex-shrink-0 bg-[#2A2D3A] text-gray-400">
                        {stock.sector}
                      </span>
                    </div>
                  );
                })
              )}
            </div>

            {/* ── 底部提示 ──────────────────────── */}
            {filtered.length > 0 && (
              <div className="flex items-center justify-between px-4 py-2 border-t border-[#2A2D3A] text-[11px] text-gray-500">
                <div className="flex items-center gap-3">
                  <span>
                    <kbd className="px-1 py-0.5 rounded bg-[#0F1117] border border-[#2A2D3A] font-mono">
                      ↑↓
                    </kbd>{' '}
                    导航
                  </span>
                  <span>
                    <kbd className="px-1 py-0.5 rounded bg-[#0F1117] border border-[#2A2D3A] font-mono">
                      Enter
                    </kbd>{' '}
                    选择
                  </span>
                </div>
                <span>
                  <kbd className="px-1 py-0.5 rounded bg-[#0F1117] border border-[#2A2D3A] font-mono">
                    ESC
                  </kbd>{' '}
                  关闭
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
