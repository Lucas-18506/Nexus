import { Component, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
  name?: string;
}

interface State {
  hasError: boolean;
  error?: string;
}

export default class SafeRender extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error: error.message };
  }

  componentDidCatch(error: Error) {
    console.error(`[SafeRender${this.props.name ? ' ' + this.props.name : ''}]`, error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="rounded-lg p-4 my-2" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
          <p style={{ color: '#EF4444', fontSize: 12, fontWeight: 500 }}>⚠ {this.props.name || '组件'} 渲染出错: {this.state.error}</p>
        </div>
      );
    }
    return this.props.children;
  }
}
