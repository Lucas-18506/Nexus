import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

type VerdictType = 'BULLISH' | 'BEARISH' | 'HOLD' | 'NEUTRAL' | 'BUY' | 'SELL' | 'ADD' | 'TRIM';

interface VerdictBadgeProps {
  verdict: VerdictType | string;
  size?: 'sm' | 'md' | 'lg';
  pulse?: boolean;
  className?: string;
}

function normalizeVerdict(verdict: string): 'bullish' | 'bearish' | 'neutral' {
  const v = verdict.toUpperCase();
  if (v === 'BULLISH' || v === 'BUY' || v === 'ADD') return 'bullish';
  if (v === 'BEARISH' || v === 'SELL' || v === 'TRIM') return 'bearish';
  return 'neutral';
}

const variantConfig = {
  bullish: {
    bg: 'bg-[rgba(16,185,129,0.12)]',
    text: 'text-bullish',
    border: 'border-bullish/30',
    icon: TrendingUp,
  },
  bearish: {
    bg: 'bg-[rgba(239,68,68,0.12)]',
    text: 'text-bearish',
    border: 'border-bearish/30',
    icon: TrendingDown,
  },
  neutral: {
    bg: 'bg-[rgba(245,158,11,0.12)]',
    text: 'text-neutral',
    border: 'border-neutral/30',
    icon: Minus,
  },
};

const sizeConfig = {
  sm: 'px-2 py-0.5 text-[10px] gap-1',
  md: 'px-3 py-1 text-caption gap-1.5',
  lg: 'px-4 py-1.5 text-body-sm gap-2',
};

const iconSizeMap = {
  sm: 10,
  md: 14,
  lg: 16,
};

export default function VerdictBadge({
  verdict,
  size = 'md',
  pulse = false,
  className,
}: VerdictBadgeProps) {
  const normalized = normalizeVerdict(verdict);
  const config = variantConfig[normalized];
  const Icon = config.icon;

  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className={cn(
        'inline-flex items-center rounded-radius-full border font-medium uppercase tracking-[0.04em]',
        config.bg,
        config.text,
        config.border,
        sizeConfig[size],
        pulse && 'animate-pulse-glow',
        className
      )}
    >
      <Icon size={iconSizeMap[size]} />
      {verdict}
    </motion.span>
  );
}
