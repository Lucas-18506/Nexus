import { useEffect, useRef, useCallback } from 'react';
import {
  createChart,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
  type HistogramData,
  type LineData,
  type Time,
  CandlestickSeries,
  HistogramSeries,
  LineSeries,
} from 'lightweight-charts';
import { calculateAllIndicators, type Candle } from '@/utils/technicalIndicators';

interface PriceChartProps {
  candles: Candle[];
  height?: number;
}

export default function PriceChart({ candles, height = 450 }: PriceChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartApi = useRef<IChartApi | null>(null);
  const candleSeries = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeries = useRef<ISeriesApi<'Histogram'> | null>(null);
  const ma5Series = useRef<ISeriesApi<'Line'> | null>(null);
  const ma10Series = useRef<ISeriesApi<'Line'> | null>(null);
  const ma20Series = useRef<ISeriesApi<'Line'> | null>(null);
  const ma60Series = useRef<ISeriesApi<'Line'> | null>(null);
  const bbUpperSeries = useRef<ISeriesApi<'Line'> | null>(null);
  const bbLowerSeries = useRef<ISeriesApi<'Line'> | null>(null);

  // 计算指标
  const indicators = calculateAllIndicators(candles);

  // 创建图表
  useEffect(() => {
    if (!chartRef.current) return;

    const chart = createChart(chartRef.current, {
      layout: {
        background: { color: '#0c1120' },
        textColor: '#9ca3af',
        fontSize: 12,
        fontFamily: "'Inter', sans-serif",
      },
      grid: {
        vertLines: { color: 'rgba(30, 41, 59, 0.5)' },
        horzLines: { color: 'rgba(30, 41, 59, 0.5)' },
      },
      crosshair: {
        mode: 1, // Magnet 模式
        vertLine: {
          color: 'rgba(0, 212, 255, 0.3)',
          labelBackgroundColor: '#0c1120',
        },
        horzLine: {
          color: 'rgba(0, 212, 255, 0.3)',
          labelBackgroundColor: '#0c1120',
        },
      },
      rightPriceScale: {
        borderColor: '#1e293b',
      },
      timeScale: {
        borderColor: '#1e293b',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: true,
      handleScale: true,
    });

    // K线系列
    const candle = chart.addSeries(CandlestickSeries, {
      upColor: '#00ff88',
      downColor: '#ff3366',
      borderUpColor: '#00ff88',
      borderDownColor: '#ff3366',
      wickUpColor: '#00cc6a',
      wickDownColor: '#cc2952',
    });

    // 成交量系列（放在底部）
    const volume = chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: '',
    });
    volume.priceScale().applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
    });

    // MA线系列
    const ma5 = chart.addSeries(LineSeries, { color: '#2962FF', lineWidth: 1, title: 'MA5' });
    const ma10 = chart.addSeries(LineSeries, { color: '#FF6D00', lineWidth: 1, title: 'MA10' });
    const ma20 = chart.addSeries(LineSeries, { color: '#00C853', lineWidth: 1, title: 'MA20' });
    const ma60 = chart.addSeries(LineSeries, { color: '#D500F9', lineWidth: 1, title: 'MA60' });

    // 布林带系列（虚线样式）
    const bbUpper = chart.addSeries(LineSeries, {
      color: 'rgba(255, 255, 255, 0.2)',
      lineWidth: 1,
      lastValueVisible: false,
      title: 'BB Upper',
    });
    const bbLower = chart.addSeries(LineSeries, {
      color: 'rgba(255, 255, 255, 0.2)',
      lineWidth: 1,
      lastValueVisible: false,
      title: 'BB Lower',
    });

    chartApi.current = chart;
    candleSeries.current = candle;
    volumeSeries.current = volume;
    ma5Series.current = ma5;
    ma10Series.current = ma10;
    ma20Series.current = ma20;
    ma60Series.current = ma60;
    bbUpperSeries.current = bbUpper;
    bbLowerSeries.current = bbLower;

    // Resize handler
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height: h } = entry.contentRect;
        chart.applyOptions({ width, height: h });
      }
    });
    ro.observe(chartRef.current);

    return () => {
      ro.disconnect();
      chart.remove();
      chartApi.current = null;
    };
  }, []);

  // 加载数据
  const loadData = useCallback(() => {
    if (
      !candleSeries.current ||
      !volumeSeries.current ||
      !ma5Series.current ||
      !ma10Series.current ||
      !ma20Series.current ||
      !ma60Series.current ||
      !bbUpperSeries.current ||
      !bbLowerSeries.current
    )
      return;

    // K线数据
    const candleData: CandlestickData<Time>[] = indicators
      .filter((d) => d.open > 0 && d.high > 0 && d.low > 0 && d.close > 0)
      .map((d) => ({
        time: (d.timestamp / 1000) as Time,
        open: d.open,
        high: d.high,
        low: d.low,
        close: d.close,
      }));

    // 成交量数据
    const volumeData: HistogramData<Time>[] = indicators
      .filter((d) => d.volume > 0)
      .map((d) => ({
        time: (d.timestamp / 1000) as Time,
        value: d.volume,
        color: d.close >= d.open ? 'rgba(0, 255, 136, 0.3)' : 'rgba(255, 51, 102, 0.3)',
      }));

    // MA线数据
    const toLineData = (values: (number | null)[]): LineData<Time>[] =>
      indicators
        .map((d, i) => ({
          time: (d.timestamp / 1000) as Time,
          value: values[i],
        }))
        .filter((d): d is LineData<Time> => d.value !== null);

    candleSeries.current.setData(candleData);
    volumeSeries.current.setData(volumeData);
    ma5Series.current.setData(toLineData(indicators.map((d) => d.sma5)));
    ma10Series.current.setData(toLineData(indicators.map((d) => d.sma10)));
    ma20Series.current.setData(toLineData(indicators.map((d) => d.sma20)));
    ma60Series.current.setData(toLineData(indicators.map((d) => d.sma60)));
    bbUpperSeries.current.setData(toLineData(indicators.map((d) => d.bbUpper)));
    bbLowerSeries.current.setData(toLineData(indicators.map((d) => d.bbLower)));

    // 自适应时间轴
    chartApi.current?.timeScale().fitContent();
  }, [indicators]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  return (
    <div
      ref={chartRef}
      style={{
        width: '100%',
        height: `${height}px`,
        background: '#0c1120',
        borderRadius: '8px',
        border: '1px solid #1e293b',
      }}
    />
  );
}
