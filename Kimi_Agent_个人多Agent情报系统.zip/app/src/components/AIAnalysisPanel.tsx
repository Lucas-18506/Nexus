import { useEffect, useMemo, useCallback } from 'react';
import { useLLMConfig } from '@/contexts/LLMContext';
import useLLM from '@/hooks/useLLM';
import {
  Sparkles,
  RefreshCw,
  AlertTriangle,
  Settings,
  TrendingUp,
  TrendingDown,
  Minus,
  Loader2,
  CircleDot,
  ShieldAlert,
  Target,
  Zap,
} from 'lucide-react';

// ─── 类型定义 ───────────────────────────────────────────

interface AIAnalysisPanelProps {
  ticker?: string;
  industry?: string;
  data: Record<string, unknown>;
}

interface ParsedSection {
  summary: string;
  keyPoints: string[];
  risks: Array<{ level: '低' | '中' | '高'; text: string }>;
  recommendation: { action: string; reason: string };
  targetPrice: { target?: string; stopLoss?: string; entry?: string };
}

// ─── Markdown 解析器 ──────────────────────────────────

function parseAnalysisContent(content: string): ParsedSection {
  const result: ParsedSection = {
    summary: '',
    keyPoints: [],
    risks: [],
    recommendation: { action: '持有', reason: '' },
    targetPrice: {},
  };

  // 解析投资摘要
  const summaryMatch = content.match(/## 投资摘要\s*\n\n?([\s\S]*?)(?=\n\n## |$)/);
  if (summaryMatch) {
    result.summary = summaryMatch[1].replace(/\*\*/g, '').trim();
  }

  // 解析关键要点
  const keyPointsMatch = content.match(/## 关键要点\s*\n\n?([\s\S]*?)(?=\n\n## |$)/);
  if (keyPointsMatch) {
    const lines = keyPointsMatch[1].split('\n');
    result.keyPoints = lines
      .map(line => line.replace(/^•\s*/, '').trim())
      .filter(line => line.length > 0);
  }

  // 解析风险评估
  const riskMatch = content.match(/## 风险评估\s*\n\n?([\s\S]*?)(?=\n\n## |$)/);
  if (riskMatch) {
    const lines = riskMatch[1].split('\n');
    result.risks = lines
      .map(line => {
        const text = line.replace(/^•\s*/, '').replace(/\*\*/g, '').trim();
        if (text.includes('高风险')) return { level: '高' as const, text: text.replace('高风险：', '').replace('高风险:', '') };
        if (text.includes('中风险')) return { level: '中' as const, text: text.replace('中风险：', '').replace('中风险:', '') };
        if (text.includes('低风险')) return { level: '低' as const, text: text.replace('低风险：', '').replace('低风险:', '') };
        return null;
      })
      .filter((item): item is { level: '低' | '中' | '高'; text: string } => item !== null);
  }

  // 解析操作建议
  const recMatch = content.match(/## 操作建议\s*\n\n?([\s\S]*?)(?=\n\n## |$)/);
  if (recMatch) {
    const recText = recMatch[1].trim();
    const actionMatch = recText.match(/\*\*(.+?)\*\*/);
    if (actionMatch) {
      result.recommendation.action = actionMatch[1];
    }
    result.recommendation.reason = recText.replace(/\*\*/g, '').trim();

    // 解析目标价位
    const targetMatch = recText.match(/目标价位?\s*([$￥€]?[\d\-.]+)/);
    if (targetMatch) result.targetPrice.target = targetMatch[1];

    const stopMatch = recText.match(/止损.*?([$￥€]?[\d\-.]+)/);
    if (stopMatch) result.targetPrice.stopLoss = stopMatch[1];

    const entryMatch = recText.match(/([$￥€]?[\d\-.]+)\s*区间\s*分批建仓/);
    if (entryMatch) result.targetPrice.entry = entryMatch[1];
  }

  return result;
}

// ─── Prompt 生成器 ────────────────────────────────────

function buildPrompt(props: AIAnalysisPanelProps): string {
  const { ticker, industry, data } = props;

  let prompt = '请作为一名专业的金融分析师，对以下标的进行深入分析，并以 Markdown 格式输出分析报告。\n\n';

  if (ticker) {
    prompt += `分析标的：${ticker.toUpperCase()}\n`;
  }
  if (industry) {
    prompt += `所属行业：${industry}\n`;
  }

  prompt += '\n可用数据：\n';
  prompt += '```json\n' + JSON.stringify(data, null, 2) + '\n```\n\n';

  prompt += `请按以下格式输出分析：

## 投资摘要
用一段话总结核心投资观点和评级。

## 关键要点
• 列出3-5个关键投资要点

## 风险评估
• **高风险**：描述主要风险
• **中风险**：描述次要风险
• **低风险**：描述可控风险（如有）

## 操作建议
**买入/持有/卖出**。给出具体操作价位建议（目标价、止损价、建仓区间）。

请用中文回答。`;

  return prompt;
}

// ─── 风险等级样式 ─────────────────────────────────────

function getRiskBadgeStyle(level: '低' | '中' | '高') {
  switch (level) {
    case '高':
      return 'bg-red-500/15 text-red-400 border-red-500/30';
    case '中':
      return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    case '低':
      return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
    default:
      return 'bg-gray-500/15 text-gray-400 border-gray-500/30';
  }
}

function getRecommendationStyle(action: string) {
  if (action.includes('买入') || action.includes('强力买入')) {
    return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
  }
  if (action.includes('卖出')) {
    return 'bg-red-500/20 text-red-400 border-red-500/40';
  }
  return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
}

function getRecommendationIcon(action: string) {
  if (action.includes('买入')) return <TrendingUp className="w-5 h-5" />;
  if (action.includes('卖出')) return <TrendingDown className="w-5 h-5" />;
  return <Minus className="w-5 h-5" />;
}

// ─── 组件 ──────────────────────────────────────────────

export default function AIAnalysisPanel({ ticker, industry, data }: AIAnalysisPanelProps) {
  const { getActiveProvider } = useLLMConfig();
  const provider = getActiveProvider();
  const hasApiKey = !!provider && !!provider.apiKey && provider.apiKey.trim() !== '';

  const prompt = useMemo(() => buildPrompt({ ticker, industry, data }), [ticker, industry, data]);

  const modelType = ticker ? 'deep-think' : 'quick-think';

  const { result, loading, error, tokenUsage, execute } = useLLM({
    prompt,
    model: modelType,
  });

  // 首次加载自动执行
  useEffect(() => {
    const timer = setTimeout(() => {
      execute();
    }, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ticker, industry]);

  const parsed = useMemo(() => {
    if (!result) return null;
    return parseAnalysisContent(result);
  }, [result]);

  const handleRefresh = useCallback(() => {
    execute();
  }, [execute]);

  const handleGoToSettings = useCallback(() => {
    // 通过事件或路由跳转到设置页面
    window.dispatchEvent(new CustomEvent('navigate-to-settings', { detail: { tab: 'llm' } }));
  }, []);

  const modelDisplayName = hasApiKey
    ? (provider?.name || 'AI模型')
    : '模拟模式';

  return (
    <div className="w-full rounded-xl border border-[#2A2D3A] bg-[#111827] overflow-hidden">
      {/* ── 面板头部 ── */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#2A2D3A]">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-purple-500/15">
            <Sparkles className="w-4.5 h-4.5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-[15px] font-semibold text-white tracking-tight">
              AI智能分析
            </h3>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`text-xs px-2.5 py-1 rounded-full border font-medium ${
              hasApiKey
                ? 'bg-purple-500/10 text-purple-300 border-purple-500/25'
                : 'bg-amber-500/10 text-amber-300 border-amber-500/25'
            }`}
          >
            {modelDisplayName}
          </span>
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="flex items-center justify-center w-8 h-8 rounded-lg transition-colors
                       hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed"
            title="重新生成分析"
          >
            <RefreshCw className={`w-4 h-4 text-gray-400 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* ── 模拟模式提示 ── */}
      {!hasApiKey && (
        <div className="mx-4 mt-4 px-4 py-3 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
          <AlertTriangle className="w-4.5 h-4.5 text-amber-400 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm text-amber-200/90 leading-relaxed">
              当前为模拟分析。在设置中配置 API Key 以获取真实 AI 分析。
            </p>
            <button
              onClick={handleGoToSettings}
              className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-amber-300
                         hover:text-amber-200 transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              去设置
            </button>
          </div>
        </div>
      )}

      {/* ── 加载状态 ── */}
      {loading && (
        <div className="flex flex-col items-center justify-center py-16 px-6">
          <div className="relative mb-5">
            <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
            <div className="absolute inset-0 rounded-full bg-purple-400/20 blur-xl animate-pulse" />
          </div>
          <p className="text-sm text-gray-400 mb-1">AI 正在分析中...</p>
          <p className="text-xs text-gray-600">正在生成专业投资分析报告</p>
        </div>
      )}

      {/* ── 错误状态 ── */}
      {!loading && error && (
        <div className="flex flex-col items-center justify-center py-12 px-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-500/15 mb-4">
            <ShieldAlert className="w-6 h-6 text-red-400" />
          </div>
          <p className="text-sm text-red-300 mb-1 text-center">分析生成失败</p>
          <p className="text-xs text-gray-500 text-center mb-4">{error}</p>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-sm text-gray-300
                       border border-[#2A2D3A] transition-colors"
          >
            重新尝试
          </button>
        </div>
      )}

      {/* ── 分析内容 ── */}
      {!loading && !error && parsed && (
        <div className="px-5 py-4 space-y-5">
          {/* 投资摘要 */}
          {parsed.summary && (
            <div className="relative">
              <div className="absolute -left-5 top-0 bottom-0 w-0.5 bg-purple-500/40 rounded-r" />
              <p className="text-[14px] leading-relaxed text-gray-200">
                {parsed.summary}
              </p>
            </div>
          )}

          {/* 关键要点 */}
          {parsed.keyPoints.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-purple-400" />
                <h4 className="text-sm font-semibold text-white">关键要点</h4>
              </div>
              <ul className="space-y-2.5">
                {parsed.keyPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 group">
                    <CircleDot className="w-3.5 h-3.5 text-purple-400/70 mt-1 shrink-0 group-hover:text-purple-400 transition-colors" />
                    <span className="text-[13px] leading-relaxed text-gray-300">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* 风险评估 */}
          {parsed.risks.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-semibold text-white">风险评估</h4>
              </div>
              <div className="space-y-2">
                {parsed.risks.map((risk, idx) => (
                  <div
                    key={idx}
                    className={`flex items-start gap-2.5 px-3 py-2.5 rounded-lg border ${getRiskBadgeStyle(risk.level)}`}
                  >
                    <span className="text-xs font-bold px-1.5 py-0.5 rounded shrink-0 mt-0.5">
                      {risk.level}风险
                    </span>
                    <span className="text-[13px] leading-relaxed">{risk.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 操作建议 */}
          {parsed.recommendation.reason && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Target className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-semibold text-white">操作建议</h4>
              </div>
              <div
                className={`p-4 rounded-lg border ${getRecommendationStyle(parsed.recommendation.action)}`}
              >
                <div className="flex items-center gap-2 mb-2.5">
                  {getRecommendationIcon(parsed.recommendation.action)}
                  <span className="text-base font-bold">{parsed.recommendation.action}</span>
                </div>
                <p className="text-[13px] leading-relaxed opacity-90">
                  {parsed.recommendation.reason}
                </p>
              </div>
            </div>
          )}

          {/* 目标价位 */}
          {(parsed.targetPrice.target || parsed.targetPrice.stopLoss || parsed.targetPrice.entry) && (
            <div className="grid grid-cols-3 gap-3">
              {parsed.targetPrice.entry && (
                <div className="text-center p-3 rounded-lg bg-white/[0.03] border border-[#2A2D3A]">
                  <p className="text-[11px] text-gray-500 mb-1">建仓区间</p>
                  <p className="text-sm font-semibold text-gray-200">{parsed.targetPrice.entry}</p>
                </div>
              )}
              {parsed.targetPrice.target && (
                <div className="text-center p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                  <p className="text-[11px] text-emerald-500/70 mb-1">目标价位</p>
                  <p className="text-sm font-semibold text-emerald-400">{parsed.targetPrice.target}</p>
                </div>
              )}
              {parsed.targetPrice.stopLoss && (
                <div className="text-center p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                  <p className="text-[11px] text-red-500/70 mb-1">止损价位</p>
                  <p className="text-sm font-semibold text-red-400">{parsed.targetPrice.stopLoss}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── Token 用量 ── */}
      {!loading && tokenUsage.total > 0 && (
        <div className="px-5 py-3 border-t border-[#2A2D3A] flex items-center justify-between">
          <span className="text-[11px] text-gray-600">
            本次消耗 {tokenUsage.total.toLocaleString()} tokens
          </span>
          <span className="text-[11px] text-gray-600">
            累计 {(() => {
              try {
                const stored = localStorage.getItem('iwm-llm-total-tokens');
                return stored ? parseInt(stored, 10).toLocaleString() : '0';
              } catch {
                return '0';
              }
            })()} tokens
          </span>
        </div>
      )}
    </div>
  );
}
