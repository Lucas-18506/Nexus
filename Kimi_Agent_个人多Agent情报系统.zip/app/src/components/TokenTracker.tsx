import { useState, useCallback, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import {
  Trash2,
  AlertTriangle,
  Hash,
  Coins,
  DollarSign,
  Cpu,
  Clock,
} from 'lucide-react';
import {
  getTodayStats,
  getStatsByProvider,
  getMostUsedModel,
  getRecentRecords,
  getProviderChartData,
  clearTokenHistory,
  usdToCny,
  type TokenRecord,
} from '@/utils/tokenStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

/* ─────────────────────── 颜色常量 ─────────────────────── */

const PROVIDER_COLORS: Record<string, string> = {
  deepseek: '#3B82F6',
  openai: '#10B981',
  anthropic: '#F59E0B',
  google: '#EF4444',
};

const FALLBACK_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

/* ─────────────────────── 辅助函数 ─────────────────────── */

function formatTime(ts: number): string {
  const d = new Date(ts);
  return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}`;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

function getProviderLabel(provider: string): string {
  const map: Record<string, string> = {
    deepseek: 'DeepSeek',
    openai: 'OpenAI',
    anthropic: 'Anthropic',
    google: 'Google',
  };
  return map[provider] ?? provider;
}

/* ─────────────────────── 概览卡片 ─────────────────────── */

function StatCard({
  title,
  value,
  subValue,
  icon: Icon,
  colorClass,
}: {
  title: string;
  value: string;
  subValue?: string;
  icon: React.ComponentType<{ className?: string }>;
  colorClass: string;
}) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1.5">
            <p className="text-muted-foreground text-xs">{title}</p>
            <p className={cn('text-xl font-bold tracking-tight', colorClass)}>{value}</p>
            {subValue && <p className="text-muted-foreground text-xs">{subValue}</p>}
          </div>
          <div className={cn('rounded-lg p-2.5 bg-opacity-10', colorClass.replace('text-', 'bg-'))}>
            <Icon className={cn('size-5', colorClass)} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────────────────── 主组件 ─────────────────────── */

function TokenTracker() {
  const [records, setRecords] = useState<TokenRecord[]>([]);
  const [todayStats, setTodayStats] = useState({
    totalCalls: 0,
    totalTokens: 0,
    totalCost: 0,
    byProvider: {} as Record<string, number>,
  });
  const [providerStats, setProviderStats] = useState<Record<string, { calls: number; tokens: number; cost: number }>>({});
  const [mostUsedModel, setMostUsedModel] = useState('-');
  const [chartData, setChartData] = useState<{ provider: string; tokens: number; percentage: number }[]>([]);
  const [open, setOpen] = useState(false);

  const refresh = useCallback(() => {
    setRecords(getRecentRecords(20));
    setTodayStats(getTodayStats());
    setProviderStats(getStatsByProvider());
    setMostUsedModel(getMostUsedModel());
    setChartData(getProviderChartData());
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const handleClear = useCallback(() => {
    clearTokenHistory();
    refresh();
    setOpen(false);
  }, [refresh]);

  const todayCostCny = usdToCny(todayStats.totalCost);

  // 计算本周数据
  const weekStats = (() => {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const diffToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    const startOfWeek = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - diffToMonday
    ).getTime();
    const weekRecords = records.filter((r) => r.timestamp >= startOfWeek);
    let totalTokens = 0;
    let totalCost = 0;
    for (const r of weekRecords) {
      totalTokens += r.totalTokens;
      totalCost += r.cost;
    }
    return { totalTokens, totalCost };
  })();

  return (
    <div className="space-y-6">
      {/* ── 标题 ── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Token 用量追踪</h2>
          <p className="text-muted-foreground text-sm">实时监控 API 调用与 Token 消耗</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="destructive" size="sm" className="gap-1.5">
              <Trash2 className="size-4" />
              清空历史
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-background border-border">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-foreground">
                <AlertTriangle className="size-5 text-destructive" />
                确认清空历史
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                此操作将删除所有 Token 使用记录，且无法撤销。确定要继续吗？
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="gap-2 sm:gap-0">
              <DialogClose asChild>
                <Button variant="outline" size="sm">取消</Button>
              </DialogClose>
              <Button variant="destructive" size="sm" onClick={handleClear}>
                确认清空
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* ── 今日概览卡片 ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="今日调用次数"
          value={todayStats.totalCalls.toString()}
          subValue={`本周累计 ${formatNumber(weekStats.totalTokens)} tokens`}
          icon={Hash}
          colorClass="text-blue-500"
        />
        <StatCard
          title="今日 Token 消耗"
          value={formatNumber(todayStats.totalTokens)}
          subValue={`本周 ${formatNumber(weekStats.totalTokens)} tokens`}
          icon={Coins}
          colorClass="text-emerald-500"
        />
        <StatCard
          title="预估成本"
          value={`$${todayStats.totalCost.toFixed(4)}`}
          subValue={`约 ¥${todayCostCny.toFixed(2)} CNY`}
          icon={DollarSign}
          colorClass="text-amber-500"
        />
        <StatCard
          title="最常用模型"
          value={mostUsedModel}
          subValue={`${Object.keys(providerStats).length} 个提供商`}
          icon={Cpu}
          colorClass="text-purple-500"
        />
      </div>

      {/* ── 提供商分布图 ── */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold text-foreground">提供商 Token 分布</CardTitle>
          <CardDescription className="text-muted-foreground text-xs">各提供商 Token 消耗占比</CardDescription>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <div className="space-y-3">
              {chartData.map((item, index) => {
                const color =
                  PROVIDER_COLORS[item.provider] ?? FALLBACK_COLORS[index % FALLBACK_COLORS.length];
                return (
                  <div key={item.provider} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground font-medium flex items-center gap-2">
                        <span
                          className="inline-block size-3 rounded-full"
                          style={{ backgroundColor: color }}
                        />
                        {getProviderLabel(item.provider)}
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {formatNumber(item.tokens)} ({item.percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${item.percentage}%`,
                          backgroundColor: color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}

              {/* 横向条形图 */}
              <div className="pt-4 h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    layout="vertical"
                    margin={{ top: 4, right: 16, bottom: 4, left: 16 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      type="number"
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      stroke="hsl(var(--border))"
                    />
                    <YAxis
                      type="category"
                      dataKey="provider"
                      tickFormatter={(v: string) => getProviderLabel(v)}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      stroke="hsl(var(--border))"
                      width={80}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                        fontSize: '12px',
                      }}
                      labelFormatter={(label: string) => getProviderLabel(label)}
                      formatter={(value: number) => [formatNumber(value), 'Tokens']}
                    />
                    <Bar dataKey="tokens" radius={[0, 4, 4, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell
                          key={entry.provider}
                          fill={
                            PROVIDER_COLORS[entry.provider] ??
                            FALLBACK_COLORS[index % FALLBACK_COLORS.length]
                          }
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Clock className="size-10 mb-3 opacity-40" />
              <p className="text-sm">暂无数据</p>
              <p className="text-xs mt-1">发起 API 调用后将显示统计</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── 最近调用记录表 ── */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold text-foreground">最近调用记录</CardTitle>
          <CardDescription className="text-muted-foreground text-xs">最近 20 条 API 调用</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="px-4 py-2.5 text-left text-muted-foreground text-xs font-medium">时间</th>
                  <th className="px-4 py-2.5 text-left text-muted-foreground text-xs font-medium">提供商</th>
                  <th className="px-4 py-2.5 text-left text-muted-foreground text-xs font-medium">模型</th>
                  <th className="px-4 py-2.5 text-right text-muted-foreground text-xs font-medium">输入 Token</th>
                  <th className="px-4 py-2.5 text-right text-muted-foreground text-xs font-medium">输出 Token</th>
                  <th className="px-4 py-2.5 text-right text-muted-foreground text-xs font-medium">总 Token</th>
                  <th className="px-4 py-2.5 text-right text-muted-foreground text-xs font-medium">成本</th>
                </tr>
              </thead>
              <tbody>
                {records.length > 0 ? (
                  records.map((record, idx) => (
                    <tr
                      key={`${record.timestamp}-${idx}`}
                      className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
                    >
                      <td className="px-4 py-2.5 text-foreground tabular-nums whitespace-nowrap">
                        {formatTime(record.timestamp)}
                      </td>
                      <td className="px-4 py-2.5 text-foreground whitespace-nowrap">
                        {getProviderLabel(record.provider)}
                      </td>
                      <td className="px-4 py-2.5 text-foreground whitespace-nowrap">{record.model}</td>
                      <td className="px-4 py-2.5 text-right text-muted-foreground tabular-nums">
                        {formatNumber(record.promptTokens)}
                      </td>
                      <td className="px-4 py-2.5 text-right text-muted-foreground tabular-nums">
                        {formatNumber(record.completionTokens)}
                      </td>
                      <td className="px-4 py-2.5 text-right text-foreground font-medium tabular-nums">
                        {formatNumber(record.totalTokens)}
                      </td>
                      <td className="px-4 py-2.5 text-right text-muted-foreground tabular-nums whitespace-nowrap">
                        ${record.cost.toFixed(6)}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                      <Clock className="size-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">暂无调用记录</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default TokenTracker;
