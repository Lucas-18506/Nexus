import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ProbabilitySegment {
  label: string;
  probability: number;
  color: string;
}

interface ProbabilityBarProps {
  segments: ProbabilitySegment[];
  height?: number;
  showLabels?: boolean;
  delay?: number;
  className?: string;
}

export default function ProbabilityBar({
  segments,
  height = 32,
  showLabels = true,
  delay = 0,
  className,
}: ProbabilityBarProps) {
  const total = segments.reduce((sum, s) => sum + s.probability, 0);

  return (
    <div className={cn('w-full', className)}>
      {/* Bar */}
      <div
        className="w-full flex rounded-radius-md overflow-hidden"
        style={{ height }}
      >
        {segments.map((segment, index) => {
          const widthPercent = (segment.probability / total) * 100;
          return (
            <motion.div
              key={segment.label}
              initial={{ width: 0 }}
              animate={{ width: `${widthPercent}%` }}
              transition={{
                duration: 0.6,
                delay: delay + index * 0.1,
                ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
              }}
              className="flex items-center justify-center relative"
              style={{ backgroundColor: segment.color }}
            >
              {widthPercent > 12 && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: delay + index * 0.1 + 0.4, duration: 0.3 }}
                  className="text-white font-mono text-caption font-bold"
                >
                  {segment.probability}%
                </motion.span>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Labels */}
      {showLabels && (
        <div className="flex mt-space-2">
          {segments.map((segment) => {
            const widthPercent = (segment.probability / total) * 100;
            return (
              <div
                key={segment.label}
                className="flex flex-col items-center"
                style={{ width: `${widthPercent}%` }}
              >
                <div className="flex items-center gap-1">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: segment.color }}
                  />
                  <span className="caption text-text-secondary text-center leading-tight">
                    {segment.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
