import { useState, useEffect, useMemo } from 'react';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type MarketStatus = 'open' | 'closed' | 'pre' | 'post' | 'holiday';

interface Exchange {
  name: string;        // 中文名称
  abbr: string;        // 英文缩写
  timeZone: string;    // IANA 时区
  openHour: number;    // 开盘时
  openMinute: number;  // 开盘分
  closeHour: number;   // 收盘时
  closeMinute: number; // 收盘分
  label: string;       // 标识 (美股/英股/日股/A股/港股)
}

// ------------------------------------------------------------------
// Exchange config
// ------------------------------------------------------------------
const EXCHANGES: Exchange[] = [
  {
    name: '纽约证券交易所',
    abbr: 'NYSE',
    timeZone: 'America/New_York',
    openHour: 9,
    openMinute: 30,
    closeHour: 16,
    closeMinute: 0,
    label: '美股',
  },
  {
    name: '纳斯达克',
    abbr: 'NASDAQ',
    timeZone: 'America/New_York',
    openHour: 9,
    openMinute: 30,
    closeHour: 16,
    closeMinute: 0,
    label: '美股',
  },
  {
    name: '伦敦证券交易所',
    abbr: 'LSE',
    timeZone: 'Europe/London',
    openHour: 8,
    openMinute: 0,
    closeHour: 16,
    closeMinute: 30,
    label: '英股',
  },
  {
    name: '东京证券交易所',
    abbr: 'TSE',
    timeZone: 'Asia/Tokyo',
    openHour: 9,
    openMinute: 0,
    closeHour: 15,
    closeMinute: 0,
    label: '日股',
  },
  {
    name: '上海证券交易所',
    abbr: 'SSE',
    timeZone: 'Asia/Shanghai',
    openHour: 9,
    openMinute: 30,
    closeHour: 15,
    closeMinute: 0,
    label: 'A股',
  },
  {
    name: '香港交易所',
    abbr: 'HKEX',
    timeZone: 'Asia/Hong_Kong',
    openHour: 9,
    openMinute: 30,
    closeHour: 16,
    closeMinute: 0,
    label: '港股',
  },
];

// ------------------------------------------------------------------
// Status helpers
// ------------------------------------------------------------------
const STATUS_LABEL: Record<MarketStatus, string> = {
  open: '开盘中',
  closed: '已收盘',
  pre: '盘前',
  post: '盘后',
  holiday: '休市',
};

const STATUS_COLOR: Record<MarketStatus, string> = {
  open: 'bg-emerald-500',
  closed: 'bg-red-500',
  pre: 'bg-yellow-400',
  post: 'bg-orange-500',
  holiday: 'bg-gray-500',
};

const STATUS_TEXT: Record<MarketStatus, string> = {
  open: 'text-emerald-400',
  closed: 'text-red-400',
  pre: 'text-yellow-400',
  post: 'text-orange-400',
  holiday: 'text-gray-400',
};

const STATUS_DOT_SHADOW: Record<MarketStatus, string> = {
  open: 'shadow-[0_0_6px_rgba(16,185,129,0.6)]',
  closed: 'shadow-[0_0_6px_rgba(239,68,68,0.6)]',
  pre: 'shadow-[0_0_6px_rgba(250,204,21,0.6)]',
  post: 'shadow-[0_0_6px_rgba(249,115,22,0.6)]',
  holiday: 'shadow-none',
};

/** 判断市场状态 */
function getMarketStatus(
  exchange: Exchange,
  localDate: Date
): MarketStatus {
  const day = localDate.getDay(); // 0=Sun, 6=Sat
  if (day === 0 || day === 6) {
    return 'holiday';
  }

  const hour = localDate.getHours();
  const minute = localDate.getMinutes();
  const totalMinutes = hour * 60 + minute;

  const openTotal = exchange.openHour * 60 + exchange.openMinute;
  const closeTotal = exchange.closeHour * 60 + exchange.closeMinute;

  // 盘前：开盘前 30 分钟内
  if (totalMinutes >= openTotal - 30 && totalMinutes < openTotal) {
    return 'pre';
  }

  // 开盘后：收盘后 30 分钟内
  if (totalMinutes >= closeTotal && totalMinutes < closeTotal + 30) {
    return 'post';
  }

  // 交易时段内
  if (totalMinutes >= openTotal && totalMinutes < closeTotal) {
    return 'open';
  }

  return 'closed';
}

// ------------------------------------------------------------------
// Sub-component: single market card
// ------------------------------------------------------------------
function MarketCard({
  exchange,
  formatter,
  now,
}: {
  exchange: Exchange;
  formatter: Intl.DateTimeFormat;
  now: Date;
}) {
  // 获取交易所当地时间
  const parts = formatter.formatToParts(now);
  const getPart = (type: string) =>
    parts.find((p) => p.type === type)?.value ?? '';

  const month = getPart('month');
  const day = getPart('day');
  const hour = getPart('hour');
  const minute = getPart('minute');
  const second = getPart('second');

  // 构造一个 "该时区" 的 Date 对象用于状态判断
  // 利用 formatToParts 获取年月日时分秒，再构造成本地 Date（该时区的时间数值）
  const year = getPart('year');
  const localDateStr = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${hour.padStart(2, '0')}:${minute.padStart(2, '0')}:${second.padStart(2, '0')}`;
  const localDate = new Date(localDateStr);

  const status = getMarketStatus(exchange, localDate);

  return (
    <div className="flex flex-col items-start rounded-lg bg-[#111827] p-3 sm:p-4 gap-2 border border-gray-800/60 hover:border-gray-700 transition-colors">
      {/* 第一行：名称 + 标签 */}
      <div className="flex items-center justify-between w-full">
        <span className="text-sm font-medium text-gray-100 truncate">
          {exchange.name}
        </span>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800 text-gray-400 whitespace-nowrap ml-2">
          {exchange.label}
        </span>
      </div>

      {/* 第二行：缩写 */}
      <span className="text-[11px] text-gray-500 leading-none">
        {exchange.abbr}
      </span>

      {/* 第三行：实时时间 */}
      <div className="font-mono text-lg text-gray-50 tracking-wider mt-1">
        {hour}:{minute}:{second}
      </div>

      {/* 第四行：日期 */}
      <div className="text-[11px] text-gray-500">
        {year}-{month}-{day}
      </div>

      {/* 第五行：状态 */}
      <div className="flex items-center gap-1.5 mt-1">
        <span
          className={`inline-block w-2 h-2 rounded-full ${STATUS_COLOR[status]} ${status === 'open' || status === 'pre' || status === 'post' ? STATUS_DOT_SHADOW[status] : ''} ${status === 'open' ? 'animate-pulse' : ''}`}
        />
        <span className={`text-xs font-medium ${STATUS_TEXT[status]}`}>
          {STATUS_LABEL[status]}
        </span>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// Main component
// ------------------------------------------------------------------
export default function MarketClock() {
  const [now, setNow] = useState<Date>(() => new Date());

  // 每秒更新
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 缓存每个交易所的 Intl.DateTimeFormat
  const formatters = useMemo(() => {
    const map: Record<string, Intl.DateTimeFormat> = {};
    EXCHANGES.forEach((ex) => {
      map[ex.abbr] = new Intl.DateTimeFormat('en-US', {
        timeZone: ex.timeZone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      });
    });
    return map;
  }, []);

  return (
    <section className="w-full">
      {/* 标题栏 */}
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-sm font-semibold text-gray-200 tracking-wide">
          全球市场行情
        </h2>
        <span className="text-[11px] text-gray-500">
          {now.toLocaleString('zh-CN', {
            hour12: false,
          })}
          &nbsp;本地时间
        </span>
      </div>

      {/* 市场卡片网格 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {EXCHANGES.map((exchange) => (
          <MarketCard
            key={exchange.abbr}
            exchange={exchange}
            formatter={formatters[exchange.abbr]}
            now={now}
          />
        ))}
      </div>
    </section>
  );
}
