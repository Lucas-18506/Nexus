import { motion } from 'framer-motion';
import { Bell, Settings } from 'lucide-react';
import SymbolSearch from './SymbolSearch';

interface TopBarProps {
  pageTitle?: string;
  breadcrumb?: string;
}

export default function TopBar({ pageTitle, breadcrumb }: TopBarProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.3,
        delay: 0.1,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className="fixed top-0 right-0 left-[260px] h-[56px] bg-bg-card border-b border-border-subtle flex items-center justify-between px-space-6 z-40"
    >
      {/* Left: Breadcrumb + Title */}
      <div className="flex flex-col">
        {breadcrumb && (
          <span className="body-sm text-text-secondary">{breadcrumb}</span>
        )}
        <h1 className="card-title text-text-primary">
          {pageTitle || '仪表盘'}
        </h1>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-space-2">
        <SymbolSearch />
        <button className="p-space-2 rounded-radius-md hover:bg-bg-elevated transition-colors duration-200 relative">
          <Bell size={18} className="text-text-secondary" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-bearish rounded-full" />
        </button>
        <button className="p-space-2 rounded-radius-md hover:bg-bg-elevated transition-colors duration-200">
          <Settings size={18} className="text-text-secondary" />
        </button>
      </div>
    </motion.header>
  );
}
