import { motion } from 'framer-motion';

interface Quote {
  ticker: string;
  name: string;
  price: number;
  change: number;
  changePct: number;
}

const quotes: Quote[] = [
  { ticker: 'NVDA', name: '英伟达', price: 135.20, change: 2.35, changePct: 1.77 },
  { ticker: 'TSLA', name: '特斯拉', price: 248.50, change: -3.20, changePct: -1.27 },
  { ticker: 'AAPL', name: '苹果', price: 225.80, change: 1.50, changePct: 0.67 },
  { ticker: '0700.HK', name: '腾讯', price: 412.00, change: 5.80, changePct: 1.43 },
  { ticker: 'MSFT', name: '微软', price: 442.30, change: 0.85, changePct: 0.19 },
  { ticker: 'GOOGL', name: '谷歌', price: 176.50, change: -0.40, changePct: -0.23 },
  { ticker: 'AMZN', name: '亚马逊', price: 198.20, change: 1.20, changePct: 0.61 },
  { ticker: 'META', name: 'Meta', price: 520.40, change: 3.10, changePct: 0.60 },
  { ticker: 'BABA', name: '阿里巴巴', price: 87.50, change: -1.20, changePct: -1.35 },
  { ticker: 'SPX', name: 'S&P 500', price: 5918.24, change: 24.80, changePct: 0.42 },
  { ticker: 'HSI', name: '恒生指数', price: 17852.30, change: 125.60, changePct: 0.71 },
  { ticker: 'GLD', name: '黄金ETF', price: 218.40, change: 1.80, changePct: 0.83 },
];

const formatPrice = (price: number): string => {
  if (price >= 10000) return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return price.toFixed(2);
};

const formatChange = (change: number): string => {
  const sign = change >= 0 ? '+' : '';
  return `${sign}${change.toFixed(2)}`;
};

const formatChangePct = (pct: number): string => {
  const sign = pct >= 0 ? '+' : '';
  return `${sign}${pct.toFixed(2)}%`;
};

function QuoteItem({ quote, isLast }: { quote: Quote; isLast: boolean }) {
  const isUp = quote.change >= 0;
  const colorClass = isUp ? '#00ff88' : '#ff3366';
  const arrow = isUp ? '▲' : '▼';

  return (
    <div className="flex items-center shrink-0">
      <div className="flex items-center gap-2 px-3">
        {/* Ticker + Name */}
        <span className="font-bold text-gray-100 tracking-wide">
          {quote.ticker}
        </span>
        <span className="text-gray-500 text-[12px]">
          {quote.name}
        </span>

        {/* Price */}
        <span className="font-semibold text-gray-100 ml-1">
          {formatPrice(quote.price)}
        </span>

        {/* Change & Arrow */}
        <span
          className="font-medium text-[12px] flex items-center gap-0.5"
          style={{ color: colorClass }}
        >
          <span className="text-[10px]">{arrow}</span>
          {formatChange(quote.change)}
        </span>

        {/* Change % */}
        <span
          className="font-medium text-[12px]"
          style={{ color: colorClass }}
        >
          {formatChangePct(quote.changePct)}
        </span>
      </div>

      {/* Separator */}
      {!isLast && (
        <span className="text-gray-700 text-[13px] select-none">|</span>
      )}
    </div>
  );
}

export default function QuoteTicker() {
  // Duplicate quotes for seamless infinite scroll
  const duplicatedQuotes = [...quotes, ...quotes];

  return (
    <motion.div
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="relative w-full overflow-hidden select-none"
      style={{
        height: 40,
        backgroundColor: '#0c1120',
        borderBottom: '1px solid rgba(30,41,59,0.5)',
      }}
    >
      {/* Scroll container */}
      <div
        className="flex items-center h-full whitespace-nowrap"
        style={{
          animation: 'scroll 40s linear infinite',
        }}
      >
        {duplicatedQuotes.map((quote, index) => (
          <QuoteItem
            key={`${quote.ticker}-${index}`}
            quote={quote}
            isLast={index === duplicatedQuotes.length - 1}
          />
        ))}
      </div>

      {/* Left gradient mask */}
      <div
        className="absolute top-0 left-0 h-full pointer-events-none z-10"
        style={{
          width: 40,
          background: 'linear-gradient(to right, #0c1120, transparent)',
        }}
      />

      {/* Right gradient mask */}
      <div
        className="absolute top-0 right-0 h-full pointer-events-none z-10"
        style={{
          width: 40,
          background: 'linear-gradient(to left, #0c1120, transparent)',
        }}
      />

      {/* Scroll animation keyframes - injected via style tag */}
      <style>{`
        @keyframes scroll {
          from {
            transform: translateX(0);
          }
          to {
            transform: translateX(-50%);
          }
        }
      `}</style>
    </motion.div>
  );
}
