import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { encrypt, decrypt } from '@/utils/crypto';

// ─── 类型定义 ───────────────────────────────────────────

export type ProviderId =
  | 'deepseek'
  | 'openai'
  | 'anthropic'
  | 'google'
  | 'dashscope'
  | 'siliconflow'
  | 'openrouter';

export interface LLMProvider {
  id: ProviderId;
  name: string;
  baseUrl: string;
  apiKey: string;
  models: string[];
  enabled: boolean;
}

export interface LLMConfig {
  provider: ProviderId;
  providers: LLMProvider[];
  deepThinkModel: string;
  quickThinkModel: string;
  temperature: number;
  maxTokens: number;
}

export interface LLMContextValue {
  config: LLMConfig;
  getActiveProvider: () => LLMProvider | undefined;
  updateProvider: (id: ProviderId, updates: Partial<Omit<LLMProvider, 'id'>>) => void;
  setActiveProvider: (id: ProviderId) => void;
  updateModel: (type: 'deep' | 'quick', model: string) => void;
  updateGlobalSettings: (settings: Partial<Pick<LLMConfig, 'temperature' | 'maxTokens'>>) => void;
  resetToDefaults: () => void;
}

// ─── 预设提供商 ─────────────────────────────────────────

export const DEFAULT_PROVIDERS: LLMProvider[] = [
  {
    id: 'deepseek',
    name: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/v1',
    models: ['deepseek-chat', 'deepseek-coder', 'deepseek-reasoner'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'openai',
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    models: ['gpt-4o', 'gpt-4o-mini', 'o3-mini', 'o4-mini'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'anthropic',
    name: 'Claude',
    baseUrl: 'https://api.anthropic.com/v1',
    models: ['claude-3-5-sonnet-20241022', 'claude-3-haiku-20240307'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'google',
    name: 'Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    models: ['gemini-2.0-flash', 'gemini-1.5-pro'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'dashscope',
    name: '阿里百炼',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    models: ['qwen-max', 'qwen-plus', 'qwen-turbo'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'siliconflow',
    name: '硅基流动',
    baseUrl: 'https://api.siliconflow.cn/v1',
    models: ['deepseek-ai/DeepSeek-V3', 'deepseek-ai/DeepSeek-R1'],
    enabled: false,
    apiKey: '',
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    models: [
      'anthropic/claude-3.5-sonnet',
      'openai/gpt-4o',
      'google/gemini-2.0-flash',
    ],
    enabled: false,
    apiKey: '',
  },
];

// ─── 默认配置 ───────────────────────────────────────────

const DEFAULT_CONFIG: LLMConfig = {
  provider: 'deepseek',
  providers: DEFAULT_PROVIDERS,
  deepThinkModel: 'deepseek-reasoner',
  quickThinkModel: 'deepseek-chat',
  temperature: 0.7,
  maxTokens: 4096,
};

const STORAGE_KEY = 'iwm-llm-config';

// ─── localStorage 序列化/反序列化 ──────────────────────

interface SerializedProvider {
  id: ProviderId;
  name: string;
  baseUrl: string;
  apiKey: string; // 已加密
  models: string[];
  enabled: boolean;
}

interface SerializedConfig {
  provider: ProviderId;
  providers: SerializedProvider[];
  deepThinkModel: string;
  quickThinkModel: string;
  temperature: number;
  maxTokens: number;
}

function serializeConfig(config: LLMConfig): SerializedConfig {
  return {
    ...config,
    providers: config.providers.map(p => ({
      ...p,
      apiKey: encrypt(p.apiKey),
    })),
  };
}

function deserializeConfig(data: SerializedConfig): LLMConfig {
  const savedProviderIds = new Set(data.providers.map(p => p.id));
  const mergedProviders = DEFAULT_PROVIDERS.map(defaultProvider => {
    const saved = data.providers.find(p => p.id === defaultProvider.id);
    if (saved) {
      return {
        ...defaultProvider,
        ...saved,
        apiKey: decrypt(saved.apiKey),
        models: saved.models.length > 0 ? saved.models : defaultProvider.models,
      };
    }
    return defaultProvider;
  });

  // 添加新的默认提供商（如果默认列表中有而保存数据中没有的）
  const newProviders = DEFAULT_PROVIDERS.filter(
    p => !savedProviderIds.has(p.id)
  );

  return {
    ...data,
    providers: [...mergedProviders, ...newProviders],
  };
}

function loadFromStorage(): LLMConfig | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SerializedConfig;
    return deserializeConfig(parsed);
  } catch {
    return null;
  }
}

function saveToStorage(config: LLMConfig): void {
  try {
    const serialized = serializeConfig(config);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serialized));
  } catch {
    // 忽略存储错误
  }
}

// ─── Context 创建 ──────────────────────────────────────

const LLMContext = createContext<LLMContextValue | undefined>(undefined);

export function useLLMConfig(): LLMContextValue {
  const ctx = useContext(LLMContext);
  if (!ctx) {
    throw new Error('useLLMConfig 必须在 LLMProvider 内使用');
  }
  return ctx;
}

// ─── Provider 组件 ─────────────────────────────────────

interface LLMProviderProps {
  children: React.ReactNode;
}

export default function LLMProvider({ children }: LLMProviderProps) {
  const [config, setConfig] = useState<LLMConfig>(() => {
    const saved = loadFromStorage();
    return saved ?? DEFAULT_CONFIG;
  });

  // 配置变更时自动持久化
  useEffect(() => {
    saveToStorage(config);
  }, [config]);

  const getActiveProvider = useCallback((): LLMProvider | undefined => {
    return config.providers.find(p => p.id === config.provider);
  }, [config.providers, config.provider]);

  const updateProvider = useCallback(
    (id: ProviderId, updates: Partial<Omit<LLMProvider, 'id'>>) => {
      setConfig(prev => {
        const exists = prev.providers.some(p => p.id === id);
        const newProviders = exists
          ? prev.providers.map(p => (p.id === id ? { ...p, ...updates } : p))
          : [...prev.providers, { ...DEFAULT_PROVIDERS.find(p => p.id === id)!, ...updates, id }];
        return { ...prev, providers: newProviders };
      });
    },
    []
  );

  const setActiveProvider = useCallback((id: ProviderId) => {
    setConfig(prev => {
      // 确保切换的提供商存在且已启用
      const target = prev.providers.find(p => p.id === id);
      if (!target || !target.enabled) return prev;
      return { ...prev, provider: id };
    });
  }, []);

  const updateModel = useCallback((type: 'deep' | 'quick', model: string) => {
    setConfig(prev => ({
      ...prev,
      [type === 'deep' ? 'deepThinkModel' : 'quickThinkModel']: model,
    }));
  }, []);

  const updateGlobalSettings = useCallback(
    (settings: Partial<Pick<LLMConfig, 'temperature' | 'maxTokens'>>) => {
      setConfig(prev => ({ ...prev, ...settings }));
    },
    []
  );

  const resetToDefaults = useCallback(() => {
    setConfig(DEFAULT_CONFIG);
  }, []);

  const value = useMemo<LLMContextValue>(
    () => ({
      config,
      getActiveProvider,
      updateProvider,
      setActiveProvider,
      updateModel,
      updateGlobalSettings,
      resetToDefaults,
    }),
    [
      config,
      getActiveProvider,
      updateProvider,
      setActiveProvider,
      updateModel,
      updateGlobalSettings,
      resetToDefaults,
    ]
  );

  return <LLMContext value={value}>{children}</LLMContext>;
}
