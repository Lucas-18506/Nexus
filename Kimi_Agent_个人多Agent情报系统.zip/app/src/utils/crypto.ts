/**
 * 简易加密工具（XOR加密，非军事级但防明文存储）
 * 用于localStorage中API Key的加解密
 */

const SECRET_KEY = 'iwm-local-storage-key-2024';

/**
 * XOR加密文本
 * @param text 明文
 * @returns Base64编码的密文
 */
export function encrypt(text: string): string {
  if (!text) return '';
  try {
    const key = Array.from(SECRET_KEY).map(c => c.charCodeAt(0));
    const input = Array.from(text).map(c => c.charCodeAt(0));
    const output = input.map((charCode, i) => {
      return charCode ^ key[i % key.length];
    });
    const bytes = new Uint8Array(output);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  } catch {
    return '';
  }
}

/**
 * XOR解密文本
 * @param encrypted Base64编码的密文
 * @returns 明文
 */
export function decrypt(encrypted: string): string {
  if (!encrypted) return '';
  try {
    const binary = atob(encrypted);
    const input = Array.from(binary).map(c => c.charCodeAt(0));
    const key = Array.from(SECRET_KEY).map(c => c.charCodeAt(0));
    const output = input.map((charCode, i) => {
      return charCode ^ key[i % key.length];
    });
    return output.map(c => String.fromCharCode(c)).join('');
  } catch {
    return '';
  }
}
