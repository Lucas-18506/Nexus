/**
 * Market Data Simulator
 *
 * Generates realistic OHLCV market data using Geometric Brownian Motion (GBM)
 * combined with Ornstein-Uhlenbeck mean reversion.
 *
 * All functions are pure (no side effects, deterministic output for given input).
 */

// =============================================================================
// Types & Interfaces
// =============================================================================

/** OHLCV candlestick data point */
export interface OHLCV {
  readonly timestamp: number;
  readonly open: number;
  readonly high: number;
  readonly low: number;
  readonly close: number;
  readonly volume: number;
}

/** Symbol configuration for simulation parameters */
export interface SymbolConfig {
  readonly basePrice: number;
  readonly volatility: number;
  readonly meanReversion: number;
  readonly volume: number;
}

/** Time interval for candlestick generation */
export type TimeInterval = '1d' | '1h' | '15m';

/** Quote snapshot for real-time price display */
export interface QuoteSnapshot {
  readonly price: number;
  readonly change: number;
  readonly changePct: number;
}

// =============================================================================
// Symbol Configuration
// =============================================================================

/**
 * Pre-configured symbol parameters calibrated to approximate
 * real-world volatility and trading characteristics.
 */
export const SYMBOLS: Record<string, SymbolConfig> = {
  NVDA: {
    basePrice: 135.2,
    volatility: 0.03,
    meanReversion: 0.012,
    volume: 45000000,
  },
  TSLA: {
    basePrice: 248.5,
    volatility: 0.035,
    meanReversion: 0.01,
    volume: 52000000,
  },
  AAPL: {
    basePrice: 225.8,
    volatility: 0.02,
    meanReversion: 0.015,
    volume: 28000000,
  },
  '0700.HK': {
    basePrice: 412.0,
    volatility: 0.025,
    meanReversion: 0.013,
    volume: 15000000,
  },
  MSFT: {
    basePrice: 442.3,
    volatility: 0.018,
    meanReversion: 0.016,
    volume: 22000000,
  },
  GOOGL: {
    basePrice: 176.5,
    volatility: 0.022,
    meanReversion: 0.014,
    volume: 20000000,
  },
} as const;

// =============================================================================
// Random Number Generation (Pure & Deterministic)
// =============================================================================

/**
 * Seedable linear congruential generator (LCG).
 * Produces a deterministic sequence of pseudo-random numbers in [0, 1).
 *
 * @param seed - Integer seed value
 * @returns Generator function that yields the next random number on each call
 */
function createLCG(seed: number): () => number {
  let state = seed >>> 0;
  return (): number => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

/**
 * Box-Muller transform: converts two independent uniform(0,1) samples
 * into one standard normal N(0,1) variate.
 *
 * @param rng - Random number generator returning values in [0, 1)
 * @returns Standard normal random variate
 */
function boxMuller(rng: () => number): number {
  let u = 0;
  let v = 0;
  do {
    u = rng();
  } while (u === 0);
  do {
    v = rng();
  } while (v === 0);
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// =============================================================================
// Stochastic Processes
// =============================================================================

/**
 * Geometric Brownian Motion via Euler-Maruyama discretisation.
 *
 * S(t+dt) = S(t) * exp((mu - 0.5*sigma^2)*dt + sigma*sqrt(dt)*Z)
 * where Z ~ N(0,1)
 *
 * @param S0    - Initial price (must be > 0)
 * @param mu    - Annualised drift rate (e.g. 0.08 for 8%)
 * @param sigma - Annualised volatility (e.g. 0.30 for 30%)
 * @param T     - Time horizon in years (must be >= 0)
 * @param steps - Number of discrete steps (must be > 0)
 * @param rng   - Random number generator (default: seeded LCG)
 * @returns Array of simulated prices with length `steps + 1`
 */
export function geometricBrownianMotion(
  S0: number,
  mu: number,
  sigma: number,
  T: number,
  steps: number,
  rng?: () => number,
): readonly number[] {
  if (S0 <= 0) throw new Error('S0 (initial price) must be positive');
  if (T < 0) throw new Error('T (time horizon) must be non-negative');
  if (steps <= 0) throw new Error('steps must be positive');

  const random = rng ?? createLCG(42);
  const dt = T / steps;
  const drift = (mu - 0.5 * sigma * sigma) * dt;
  const diffusion = sigma * Math.sqrt(dt);

  const prices: number[] = new Array(steps + 1);
  prices[0] = S0;

  for (let i = 1; i <= steps; i++) {
    const Z = boxMuller(random);
    prices[i] = prices[i - 1] * Math.exp(drift + diffusion * Z);
  }

  return prices;
}

/**
 * Ornstein-Uhlenbeck mean-reversion overlay.
 *
 * dX = theta * (mean - X) * dt + sigma * dW
 *
 * Applied to a GBM-generated price series to pull prices back
 * toward a long-run equilibrium and prevent unrealistic divergence.
 *
 * @param prices      - Raw GBM price series
 * @param mean        - Long-run mean price (must be > 0)
 * @param theta       - Mean-reversion speed (e.g. 0.012)
 * @param sigma       - OU volatility parameter
 * @param dt          - Time step size in years
 * @param rng         - Random number generator
 * @returns Mean-reverted price series (same length as input)
 */
export function ornsteinUhlenbeck(
  prices: readonly number[],
  mean: number,
  theta: number,
  sigma: number,
  dt: number,
  rng?: () => number,
): readonly number[] {
  if (prices.length === 0) return [];
  if (mean <= 0) throw new Error('mean must be positive');

  const random = rng ?? createLCG(123);
  const result: number[] = new Array(prices.length);
  result[0] = prices[0];

  for (let i = 1; i < prices.length; i++) {
    const prev = result[i - 1];
    // Mean-reversion force + small diffusion term
    const ouDrift = theta * (mean - prev) * dt;
    const ouDiffusion = sigma * Math.sqrt(dt) * boxMuller(random);
    const reverted = prev + ouDrift + ouDiffusion;
    // Blend GBM path with OU correction (70% GBM, 30% OU pull)
    result[i] = prices[i] * 0.7 + reverted * 0.3;
  }

  return result;
}

// =============================================================================
// OHLCV Generation
// =============================================================================

/**
 * Derives trading-interval parameters.
 *
 * @param interval - Candle interval
 * @returns Bars per trading day and dt in years
 */
function getIntervalParams(
  interval: TimeInterval,
): { readonly barsPerDay: number; readonly dt: number } {
  const tradingDaysPerYear = 252;
  const hoursPerDay = 8; // typical equity market hours
  switch (interval) {
    case '1d':
      return { barsPerDay: 1, dt: 1 / tradingDaysPerYear };
    case '1h':
      return {
        barsPerDay: hoursPerDay,
        dt: 1 / (tradingDaysPerYear * hoursPerDay),
      };
    case '15m':
      return {
        barsPerDay: hoursPerDay * 4,
        dt: 1 / (tradingDaysPerYear * hoursPerDay * 4),
      };
  }
}

/**
 * Generates a complete OHLCV candlestick series for a single symbol.
 *
 * Algorithm:
 *   1. Generate a base GBM price path using symbol-specific drift/vol.
 *   2. Apply OU mean-reversion overlay to keep prices realistic.
 *   3. Build OHLCV bars from the corrected price series.
 *
 * @param basePrice      - Starting price (must be > 0)
 * @param volatility     - Daily volatility (e.g. 0.025)
 * @param meanReversion  - Mean-reversion strength (e.g. 0.012)
 * @param volume         - Average daily volume
 * @param days           - Number of trading days to simulate
 * @param interval       - Candle interval ('1d' | '1h' | '15m')
 * @param seed           - Optional RNG seed for reproducibility
 * @returns Array of OHLCV objects, oldest first
 */
export function generateOHLCV(
  basePrice: number,
  volatility: number,
  meanReversion: number,
  volume: number,
  days: number,
  interval: TimeInterval,
  seed?: number,
): readonly OHLCV[] {
  if (basePrice <= 0) throw new Error('basePrice must be positive');
  if (volatility <= 0) throw new Error('volatility must be positive');
  if (days <= 0) throw new Error('days must be positive');

  const { barsPerDay, dt } = getIntervalParams(interval);
  const totalSteps = Math.floor(days * barsPerDay);
  if (totalSteps < 1) throw new Error('days * barsPerDay must be >= 1');

  // Seed the RNG deterministically from the optional seed
  const resolvedSeed =
    seed ?? Math.floor(Math.random() * 2147483647);
  const rng = createLCG(resolvedSeed);

  // Drift calibrated around risk-free rate minus dividend yield
  const drift = 0.06; // 6% annual drift (approx equity risk premium + risk-free)

  // Scale volatility from daily to the chosen interval
  // variance scales linearly with time => sigma_interval = sigma_daily * sqrt(bars_per_day_interval)
  const sigmaDaily = volatility;
  const sigmaInterval =
    interval === '1d'
      ? sigmaDaily
      : sigmaDaily / Math.sqrt(barsPerDay);

  // Annualised sigma for GBM
  const sigmaAnnual = sigmaInterval / Math.sqrt(dt);
  const T = totalSteps * dt;

  // 1. Raw GBM path
  const gbmPrices = geometricBrownianMotion(
    basePrice,
    drift,
    sigmaAnnual,
    T,
    totalSteps,
    rng,
  );

  // 2. OU mean-reversion overlay
  const ouPrices = ornsteinUhlenbeck(
    gbmPrices,
    basePrice,
    meanReversion,
    sigmaAnnual * 0.15, // OU diffusion is a fraction of GBM volatility
    dt,
    rng,
  );

  // 3. Build OHLCV bars
  const bars: OHLCV[] = new Array(totalSteps);
  const now = Date.now();
  const msPerBar =
    interval === '1d'
      ? 86400000
      : interval === '1h'
        ? 3600000
        : 900000;

  for (let i = 0; i < totalSteps; i++) {
    const open = i === 0 ? basePrice : ouPrices[i];
    const close = ouPrices[i + 1];
    const upper = Math.max(open, close);
    const lower = Math.min(open, close);

    // Wicks: random 0-0.3% extension above/below the body
    const wickFactor = (rng() * 0.003);
    const high = upper * (1 + wickFactor);
    const lowVal = lower * (1 - wickFactor);

    // Volume: base volume with ~50% random variation
    const volMultiplier = 0.5 + rng();
    const barVolume = Math.floor(volume * volMultiplier / barsPerDay);

    bars[i] = {
      timestamp: now - (totalSteps - i) * msPerBar,
      open: round(open, 4),
      high: round(high, 4),
      low: round(lowVal, 4),
      close: round(close, 4),
      volume: barVolume,
    };
  }

  return bars;
}

// =============================================================================
// Convenience Exports
// =============================================================================

/**
 * Generates OHLCV candlestick data for a known ticker.
 *
 * @param ticker - Symbol key (e.g. 'NVDA', 'TSLA')
 * @param days   - Number of trading days (default 60)
 * @param interval - Candle interval (default '1d')
 * @param seed   - Optional RNG seed for deterministic output
 * @returns Array of OHLCV objects, oldest first
 */
export function generateStockData(
  ticker: string,
  days: number = 60,
  interval: TimeInterval = '1d',
  seed?: number,
): readonly OHLCV[] {
  const config = SYMBOLS[ticker];
  if (!config) {
    throw new Error(
      `Unknown ticker: "${ticker}". Available: ${Object.keys(SYMBOLS).join(', ')}`,
    );
  }
  return generateOHLCV(
    config.basePrice,
    config.volatility,
    config.meanReversion,
    config.volume,
    days,
    interval,
    seed,
  );
}

/**
 * Generates OHLCV data for multiple tickers in a single call.
 *
 * @param tickers  - Array of symbol keys
 * @param days     - Number of trading days
 * @param interval - Candle interval (default '1d')
 * @param seed     - Optional RNG seed (each ticker gets a derived seed)
 * @returns Record mapping ticker -> OHLCV array
 */
export function generateMultiStockData(
  tickers: readonly string[],
  days: number,
  interval: TimeInterval = '1d',
  seed?: number,
): Record<string, readonly OHLCV[]> {
  const result: Record<string, readonly OHLCV[]> = {};
  const baseSeed = seed ?? Math.floor(Math.random() * 2147483647);

  for (let i = 0; i < tickers.length; i++) {
    const ticker = tickers[i];
    const tickerSeed = baseSeed + i * 7919; // prime offset to de-correlate streams
    result[ticker] = generateStockData(ticker, days, interval, tickerSeed);
  }

  return result;
}

/**
 * Generates a single real-time quote snapshot for a ticker.
 *
 * @param ticker - Symbol key
 * @param seed   - Optional RNG seed
 * @returns QuoteSnapshot with synthetic price, change and change%
 */
export function generateQuoteSnapshot(
  ticker: string,
  seed?: number,
): QuoteSnapshot {
  const config = SYMBOLS[ticker];
  if (!config) {
    throw new Error(
      `Unknown ticker: "${ticker}". Available: ${Object.keys(SYMBOLS).join(', ')}`,
    );
  }

  const rng = createLCG(seed ?? Math.floor(Math.random() * 2147483647));

  // Simulate a small intraday move: +/- 3% typical range
  const movePct = (rng() - 0.5) * 0.06;
  const price = config.basePrice * (1 + movePct);
  const change = price - config.basePrice;
  const changePct = (change / config.basePrice) * 100;

  return {
    price: round(price, 2),
    change: round(change, 2),
    changePct: round(changePct, 3),
  };
}

// =============================================================================
// Helpers
// =============================================================================

/**
 * Rounds a number to a fixed number of decimal places.
 *
 * @param value  - Number to round
 * @param digits - Decimal places
 * @returns Rounded number
 */
function round(value: number, digits: number): number {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}
