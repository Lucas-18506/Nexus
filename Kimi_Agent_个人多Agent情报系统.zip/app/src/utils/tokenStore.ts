/* ─────────────────────── 类型定义 ─────────────────────── */

export interface TokenRecord {
  timestamp: number;
  provider: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  cost: number;
}

interface ProviderStats {
  calls: number;
  tokens: number;
  cost: number;
}

/* ─────────────────────── 常量 ─────────────────────── */

const STORAGE_KEY = 'iwm-token-usage';

const COST_PER_1K: Record<string, { input: number; output: number }> = {
  'deepseek-chat': { input: 0.00027, output: 0.0011 },
  'gpt-4o': { input: 0.005, output: 0.015 },
  'gpt-4o-mini': { input: 0.00015, output: 0.0006 },
  'claude-3-5-sonnet': { input: 0.003, output: 0.015 },
  'gemini-2.0-flash': { input: 0.00035, output: 0.00105 },
};

const USD_TO_CNY = 7.2;

/* ─────────────────────── 存储读写 ─────────────────────── */

function readRecords(): TokenRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as TokenRecord[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeRecords(records: TokenRecord[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

/* ─────────────────────── 成本计算 ─────────────────────── */

export function calculateCost(model: string, promptTokens: number, completionTokens: number): number {
  const rates = COST_PER_1K[model] ?? { input: 0.001, output: 0.001 };
  const inputCost = (promptTokens / 1000) * rates.input;
  const outputCost = (completionTokens / 1000) * rates.output;
  return Math.round((inputCost + outputCost) * 1000000) / 1000000;
}

export function usdToCny(usd: number): number {
  return Math.round(usd * USD_TO_CNY * 100) / 100;
}

/* ─────────────────────── 公共 API ─────────────────────── */

/** 添加一条 Token 使用记录 */
export function addTokenRecord(record: TokenRecord): void {
  const records = readRecords();
  records.unshift(record);
  // 最多保留 1000 条
  if (records.length > 1000) {
    records.length = 1000;
  }
  writeRecords(records);
}

/** 获取所有记录 */
export function getTokenRecords(): TokenRecord[] {
  return readRecords();
}

/** 获取今日统计 */
export function getTodayStats(): {
  totalCalls: number;
  totalTokens: number;
  totalCost: number;
  byProvider: Record<string, number>;
} {
  const records = readRecords();
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  const todayRecords = records.filter((r) => r.timestamp >= startOfDay);

  const byProvider: Record<string, number> = {};
  let totalCalls = 0;
  let totalTokens = 0;
  let totalCost = 0;

  for (const r of todayRecords) {
    totalCalls++;
    totalTokens += r.totalTokens;
    totalCost += r.cost;
    byProvider[r.provider] = (byProvider[r.provider] ?? 0) + r.totalTokens;
  }

  return {
    totalCalls,
    totalTokens,
    totalCost: Math.round(totalCost * 1000000) / 1000000,
    byProvider,
  };
}

/** 获取本周统计 */
export function getWeekStats(): {
  totalCalls: number;
  totalTokens: number;
  totalCost: number;
} {
  const records = readRecords();
  const now = new Date();
  const dayOfWeek = now.getDay();
  const diffToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  const startOfWeek = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() - diffToMonday
  ).getTime();

  const weekRecords = records.filter((r) => r.timestamp >= startOfWeek);

  let totalCalls = 0;
  let totalTokens = 0;
  let totalCost = 0;

  for (const r of weekRecords) {
    totalCalls++;
    totalTokens += r.totalTokens;
    totalCost += r.cost;
  }

  return {
    totalCalls,
    totalTokens,
    totalCost: Math.round(totalCost * 1000000) / 1000000,
  };
}

/** 按提供商分组统计 */
export function getStatsByProvider(): Record<string, ProviderStats> {
  const records = readRecords();
  const stats: Record<string, ProviderStats> = {};

  for (const r of records) {
    if (!stats[r.provider]) {
      stats[r.provider] = { calls: 0, tokens: 0, cost: 0 };
    }
    stats[r.provider].calls++;
    stats[r.provider].tokens += r.totalTokens;
    stats[r.provider].cost += r.cost;
  }

  // 四舍五入成本
  for (const key of Object.keys(stats)) {
    stats[key].cost = Math.round(stats[key].cost * 1000000) / 1000000;
  }

  return stats;
}

/** 清空历史 */
export function clearTokenHistory(): void {
  localStorage.removeItem(STORAGE_KEY);
}

/** 获取最常用模型 */
export function getMostUsedModel(): string {
  const records = readRecords();
  const modelCount: Record<string, number> = {};

  for (const r of records) {
    modelCount[r.model] = (modelCount[r.model] ?? 0) + 1;
  }

  let maxModel = '-';
  let maxCount = 0;

  for (const [model, count] of Object.entries(modelCount)) {
    if (count > maxCount) {
      maxCount = count;
      maxModel = model;
    }
  }

  return maxModel;
}

/** 获取最近 N 条记录 */
export function getRecentRecords(limit: number = 20): TokenRecord[] {
  return readRecords().slice(0, limit);
}

/** 获取提供商分布数据（用于图表） */
export function getProviderChartData(): { provider: string; tokens: number; percentage: number }[] {
  const stats = getStatsByProvider();
  const totalTokens = Object.values(stats).reduce((sum, s) => sum + s.tokens, 0);

  if (totalTokens === 0) return [];

  return Object.entries(stats)
    .map(([provider, data]) => ({
      provider,
      tokens: data.tokens,
      percentage: Math.round((data.tokens / totalTokens) * 1000) / 10,
    }))
    .sort((a, b) => b.tokens - a.tokens);
}

/* ─────────────────────── 成本估算参考 ─────────────────────── */

export { COST_PER_1K };
export type { ProviderStats };
