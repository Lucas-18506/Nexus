/**
 * 技术指标引擎
 * 从 galafis/trading-dashboard 复用并适配TypeScript
 * 全部纯函数，输入输出类型安全
 */

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorResult extends Candle {
  sma5: number | null;
  sma10: number | null;
  sma20: number | null;
  sma60: number | null;
  ema12: number | null;
  ema26: number | null;
  rsi14: number | null;
  macd: number | null;
  macdSignal: number | null;
  macdHistogram: number | null;
  bbUpper: number | null;
  bbMiddle: number | null;
  bbLower: number | null;
  vwap: number | null;
}

/** 简单移动平均线 SMA */
export function sma(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sum += data[j];
    }
    result.push(sum / period);
  }
  return result;
}

/** 指数移动平均线 EMA */
export function ema(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  const multiplier = 2 / (period + 1);

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    if (i === period - 1) {
      let sum = 0;
      for (let j = 0; j < period; j++) sum += data[j];
      result.push(sum / period);
      continue;
    }
    const prev = result[i - 1];
    if (prev === null) {
      result.push(null);
      continue;
    }
    result.push((data[i] - prev) * multiplier + prev);
  }
  return result;
}

/** 相对强弱指数 RSI (Wilder平滑法) */
export function rsi(closes: number[], period = 14): (number | null)[] {
  const result: (number | null)[] = [];
  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (i === 0) {
      result.push(null);
      continue;
    }
    const change = closes[i] - closes[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? -change : 0);

    if (i < period) {
      result.push(null);
      continue;
    }

    if (i === period) {
      let avgGain = 0;
      let avgLoss = 0;
      for (let j = 0; j < period; j++) {
        avgGain += gains[j];
        avgLoss += losses[j];
      }
      avgGain /= period;
      avgLoss /= period;

      if (avgLoss === 0) {
        result.push(100);
      } else {
        const rs = avgGain / avgLoss;
        result.push(100 - 100 / (1 + rs));
      }
      continue;
    }

    // Wilder's smoothing: use recent gains/losses window
    const recentGains = gains.slice(i - period, i);
    const recentLosses = losses.slice(i - period, i);
    const avgGain = recentGains.reduce((a, b) => a + b, 0) / period;
    const avgLoss = recentLosses.reduce((a, b) => a + b, 0) / period;

    if (avgLoss === 0) {
      result.push(100);
    } else {
      const rs = avgGain / avgLoss;
      result.push(100 - 100 / (1 + rs));
    }
  }
  return result;
}

/** MACD 指标 */
export function macd(
  closes: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9
): { macd: (number | null)[]; signal: (number | null)[]; histogram: (number | null)[] } {
  const fastEma = ema(closes, fastPeriod);
  const slowEma = ema(closes, slowPeriod);

  const macdLine = closes.map((_, i) => {
    if (fastEma[i] === null || slowEma[i] === null) return null;
    return (fastEma[i] as number) - (slowEma[i] as number);
  });

  const validMacd = macdLine.filter((v): v is number => v !== null);
  const signalEma = ema(validMacd, signalPeriod);

  const signal: (number | null)[] = [];
  let validIdx = 0;
  for (let i = 0; i < macdLine.length; i++) {
    if (macdLine[i] === null) {
      signal.push(null);
    } else {
      signal.push(signalEma[validIdx] ?? null);
      validIdx++;
    }
  }

  const histogram = closes.map((_, i) => {
    if (macdLine[i] === null || signal[i] === null) return null;
    return (macdLine[i] as number) - (signal[i] as number);
  });

  return { macd: macdLine, signal, histogram };
}

/** 布林带 Bollinger Bands */
export function bollingerBands(
  closes: number[],
  period = 20,
  stdDevMultiplier = 2
): { upper: (number | null)[]; middle: (number | null)[]; lower: (number | null)[] } {
  const middle = sma(closes, period);
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (middle[i] === null) {
      upper.push(null);
      lower.push(null);
      continue;
    }
    let sumSqDiff = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = closes[j] - (middle[i] as number);
      sumSqDiff += diff * diff;
    }
    const stdDev = Math.sqrt(sumSqDiff / period);
    upper.push((middle[i] as number) + stdDevMultiplier * stdDev);
    lower.push((middle[i] as number) - stdDevMultiplier * stdDev);
  }
  return { upper, middle, lower };
}

/** 成交量加权平均价 VWAP */
export function vwap(candles: Candle[]): (number | null)[] {
  const result: (number | null)[] = [];
  let cumulativeVolumePrice = 0;
  let cumulativeVolume = 0;

  for (const candle of candles) {
    const typicalPrice = (candle.high + candle.low + candle.close) / 3;
    cumulativeVolumePrice += typicalPrice * candle.volume;
    cumulativeVolume += candle.volume;
    result.push(cumulativeVolume > 0 ? cumulativeVolumePrice / cumulativeVolume : null);
  }
  return result;
}

/** 一键计算所有技术指标 */
export function calculateAllIndicators(candles: Candle[]): IndicatorResult[] {
  const closes = candles.map((c) => c.close);

  const sma5 = sma(closes, 5);
  const sma10 = sma(closes, 10);
  const sma20 = sma(closes, 20);
  const sma60 = sma(closes, 60);
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const rsi14 = rsi(closes, 14);
  const macdResult = macd(closes);
  const bbands = bollingerBands(closes);
  const vwapResult = vwap(candles);

  return candles.map((candle, i) => ({
    ...candle,
    sma5: sma5[i],
    sma10: sma10[i],
    sma20: sma20[i],
    sma60: sma60[i],
    ema12: ema12[i],
    ema26: ema26[i],
    rsi14: rsi14[i],
    macd: macdResult.macd[i],
    macdSignal: macdResult.signal[i],
    macdHistogram: macdResult.histogram[i],
    bbUpper: bbands.upper[i],
    bbMiddle: bbands.middle[i],
    bbLower: bbands.lower[i],
    vwap: vwapResult[i],
  }));
}
