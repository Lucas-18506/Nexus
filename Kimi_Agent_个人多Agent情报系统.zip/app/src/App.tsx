import { Routes, Route } from 'react-router';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Macro from './pages/Macro';
import MorningReport from './pages/MorningReport';
import EveningReport from './pages/EveningReport';
import Industry from './pages/Industry';
import Company from './pages/Company';
import Devil from './pages/Devil';
import CIO from './pages/CIO';
import Portfolio from './pages/Portfolio';
import Settings from './pages/Settings';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/macro" element={<Macro />} />
        <Route path="/morning" element={<MorningReport />} />
        <Route path="/evening" element={<EveningReport />} />
        <Route path="/industry" element={<Industry />} />
        <Route path="/company/:ticker?" element={<Company />} />
        <Route path="/devil" element={<Devil />} />
        <Route path="/cio" element={<CIO />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
    </Routes>
  );
}
