# IWM 个人投资参谋系统 - SPEC.md

## 1. 项目概述

**名称**: IWM (Investment World Model) 个人版
**定位**: 个人AI投资参谋系统，非产品，非推广，仅供个人研究使用
**核心能力**: 自动采集数据 → 沉淀知识 → 多Agent辩证分析 → CIO汇总判断
**输出形式**: 日报、行业分析、机会提醒、持仓影响分析（文本报告）

## 2. 架构总览

```
┌─────────────────────────────────────────────────────────────┐
│                    API Layer (FastAPI)                        │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐               │
│  │ /api/news  │ │ /api/report│ │ /api/agent │               │
│  │ /api/data  │ │ /api/thesis│ │ /api/kb    │               │
│  └────────────┘ └────────────┘ └────────────┘               │
├─────────────────────────────────────────────────────────────┤
│                   Scheduler (APScheduler)                     │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐               │
│  │ 宏观数据   │ │ 行情数据   │ │ 新闻采集   │               │
│  │ (每日)     │ │ (盘中)     │ │ (定时)     │               │
│  └────────────┘ └────────────┘ └────────────┘               │
├─────────────────────────────────────────────────────────────┤
│                    Agent Layer (LangGraph)                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  Data Agents │  │ Analysis     │  │ CIO Committee│       │
│  │  - Collector │  │  Agents      │  │  - Macro     │       │
│  │  - Processor │  │  - Macro     │  │  - Industry  │       │
│  │  - Indexer   │  │  - Industry  │  │  - Devil     │       │
│  │              │  │  - Company   │  │  - Consensus │       │
│  │              │  │  - Devil     │  │  - CIO Final │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
├─────────────────────────────────────────────────────────────┤
│                   Storage Layer                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ PostgreSQL   │  │ Qdrant       │  │ Local JSON   │       │
│  │ (结构化数据)  │  │ (向量检索)   │  │ (配置文件)   │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
```

## 3. 目录结构

```
/mnt/agents/output/iwm/
├── .env                          # 环境变量
├── requirements.txt              # 依赖
├── config.yaml                   # 系统配置
├── run.py                        # 启动入口
├── scheduler.py                  # 定时任务调度器
├── alembic/                      # 数据库迁移
│
├── app/
│   ├── __init__.py
│   ├── main.py                   # FastAPI主应用
│   ├── config.py                 # 配置管理
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── news.py               # 新闻相关API
│   │   ├── report.py             # 报告相关API
│   │   ├── data.py               # 数据查询API
│   │   ├── thesis.py             # 投资逻辑API
│   │   ├── kb.py                 # 知识库API
│   │   └── agent.py              # Agent触发API
│   │
│   ├── core/
│   │   ├── __init__.py
│   │   ├── database.py           # PostgreSQL连接
│   │   ├── vector_store.py       # Qdrant连接
│   │   └── exceptions.py         # 自定义异常
│   │
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base.py               # SQLAlchemy Base
│   │   ├── news.py               # 新闻/事件模型
│   │   ├── company.py            # 公司模型
│   │   ├── industry.py           # 行业模型
│   │   ├── thesis.py             # 投资逻辑模型
│   │   ├── macro.py              # 宏观数据模型
│   │   ├── opportunity.py        # 机会模型
│   │   ├── report.py             # 报告模型
│   │   └── agent_log.py          # Agent运行日志
│   │
│   ├── schemas/
│   │   ├── __init__.py
│   │   ├── news.py               # Pydantic Schemas
│   │   ├── company.py
│   │   ├── industry.py
│   │   ├── thesis.py
│   │   ├── macro.py
│   │   ├── opportunity.py
│   │   └── report.py
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── data_service.py       # 数据查询服务
│   │   ├── report_service.py     # 报告生成服务
│   │   ├── kb_service.py         # 知识库服务
│   │   └── thesis_service.py     # 投资逻辑服务
│   │
│   ├── data_collection/          # 数据采集模块
│   │   ├── __init__.py
│   │   ├── collectors/
│   │   │   ├── __init__.py
│   │   │   ├── base.py           # 采集器基类
│   │   │   ├── macro_collector.py    # 宏观数据采集
│   │   │   ├── stock_collector.py    # 个股数据采集
│   │   │   └── news_collector.py     # 新闻采集
│   │   ├── processors/
│   │   │   ├── __init__.py
│   │   │   ├── base.py           # 处理器基类
│   │   │   ├── news_processor.py     # 新闻→事件提取
│   │   │   └── entity_extractor.py   # 实体抽取
│   │   └── scheduler_tasks.py    # 定时任务定义
│   │
│   ├── agents/                   # Agent集群模块
│   │   ├── __init__.py
│   │   ├── prompts/              # Agent提示词
│   │   │   ├── macro_analyst.txt
│   │   │   ├── industry_analyst.txt
│   │   │   ├── company_analyst.txt
│   │   │   ├── devil_advocate.txt
│   │   │   ├── supply_chain.txt
│   │   │   ├── risk_analyst.txt
│   │   │   └── cio_synthesizer.txt
│   │   ├── agent_configs.py      # Agent配置定义
│   │   ├── committee.py          # 委员会工作流
│   │   ├── analysis_engine.py    # 分析引擎
│   │   ├── report_generator.py   # 报告生成
│   │   └── memory/               # Agent记忆
│   │       ├── __init__.py
│   │       ├── base.py
│   │       └── local_memory.py
│   │
│   ├── knowledge_base/           # 知识库管理
│   │   ├── __init__.py
│   │   ├── kb_manager.py         # 知识库管理器
│   │   ├── industry_kb.py        # 行业知识操作
│   │   ├── company_kb.py         # 公司知识操作
│   │   ├── thesis_kb.py          # 投资逻辑操作
│   │   └── sync/                 # 与数据库同步
│   │       ├── __init__.py
│   │       └── sync_service.py
│   │
│   └── reports/                  # 报告模板与生成
│       ├── __init__.py
│       ├── templates/
│       │   ├── daily_report.md    # 日报模板
│       │   ├── opportunity_scan.md # 机会扫描模板
│       │   └── industry_deep.md  # 行业深度模板
│       └── renderer.py           # 报告渲染器
│
├── data/                         # 本地数据目录
│   ├── news/                     # 原始新闻缓存
│   ├── reports/                  # 生成报告输出
│   └── vector_backup/            # 向量库备份
│
└── tests/                        # 测试
    └── ...
```

## 4. 数据模型（PostgreSQL）

### 4.1 核心表

```sql
-- 行业表
CREATE TABLE industries (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    lifecycle_stage VARCHAR(20),  -- seed/emerging/growth/mature/decline
    growth_rate VARCHAR(20),
    market_size TEXT,
    key_drivers JSONB DEFAULT '[]',
    supply_chain TEXT,
    bottleneck TEXT,
    prosperity_indicators JSONB DEFAULT '[]',
    risk_factors JSONB DEFAULT '[]',
    opportunities JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(name)
);

-- 公司表
CREATE TABLE companies (
    id SERIAL PRIMARY KEY,
    ticker VARCHAR(20) NOT NULL,
    market VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    industry_id INTEGER REFERENCES industries(id),
    description TEXT,
    business_model TEXT,
    moat TEXT,
    risk_points JSONB DEFAULT '[]',
    revenue_sources JSONB DEFAULT '[]',
    cost_structure TEXT,
    customer_structure TEXT,
    competitive_position TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(ticker, market)
);

-- 宏观指标表
CREATE TABLE macro_indicators (
    id SERIAL PRIMARY KEY,
    indicator_name VARCHAR(100) NOT NULL,  -- "US_Fed_Funds_Rate", "CPI_China"
    indicator_type VARCHAR(50),             -- rate/inflation/pmi/gdp/liquidity
    country VARCHAR(50),
    current_value DECIMAL(20, 6),
    previous_value DECIMAL(20, 6),
    unit VARCHAR(20),
    frequency VARCHAR(20),                  -- daily/monthly/quarterly
    source VARCHAR(100),
    collected_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(indicator_name, collected_at)
);

-- 个股行情表
CREATE TABLE stock_prices (
    id SERIAL PRIMARY KEY,
    ticker VARCHAR(20) NOT NULL,
    market VARCHAR(20) NOT NULL,
    date DATE NOT NULL,
    open DECIMAL(15, 4),
    high DECIMAL(15, 4),
    low DECIMAL(15, 4),
    close DECIMAL(15, 4),
    volume BIGINT,
    market_cap DECIMAL(20, 2),
    pe_ratio DECIMAL(10, 2),
    pb_ratio DECIMAL(10, 2),
    ps_ratio DECIMAL(10, 2),
    ev_ebitda DECIMAL(10, 2),
    collected_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(ticker, market, date)
);

-- 新闻表
CREATE TABLE news (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT,
    source VARCHAR(100),
    url TEXT,
    published_at TIMESTAMP,
    category VARCHAR(50),         -- macro/industry/company/policy/market
    impact_level INTEGER DEFAULT 0,  -- 0-5
    extracted_events JSONB DEFAULT '[]',
    related_tickers JSONB DEFAULT '[]',
    related_industries JSONB DEFAULT '[]',
    sentiment VARCHAR(20),        -- positive/negative/neutral
    collected_at TIMESTAMP DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE
);

-- 事件表
CREATE TABLE events (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    summary TEXT,
    event_type VARCHAR(50),       -- macro/policy/earnings/war/tech/industry
    event_date DATE,
    source VARCHAR(100),
    impact_level INTEGER DEFAULT 0,
    confidence DECIMAL(3, 2) DEFAULT 0.5,
    related_industries JSONB DEFAULT '[]',
    related_companies JSONB DEFAULT '[]',
    related_macro JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT NOW()
);

-- 投资逻辑(Thesis)表
CREATE TABLE theses (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    confidence DECIMAL(3, 2) DEFAULT 0.5,
    status VARCHAR(20) DEFAULT 'draft',  -- draft/active/validated/invalidated
    owner VARCHAR(50) DEFAULT 'system',
    source_type VARCHAR(50),        -- agent/user/analysis
    related_industry VARCHAR(100),
    related_tickers JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 投资逻辑证据表
CREATE TABLE thesis_evidence (
    id SERIAL PRIMARY KEY,
    thesis_id INTEGER REFERENCES theses(id) ON DELETE CASCADE,
    evidence_type VARCHAR(20),      -- supporting/opposing
    content TEXT NOT NULL,
    source VARCHAR(200),
    confidence DECIMAL(3, 2) DEFAULT 0.5,
    created_at TIMESTAMP DEFAULT NOW()
);

-- 机会表
CREATE TABLE opportunities (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    theme VARCHAR(200),
    industry VARCHAR(100),
    catalyst TEXT,
    confidence DECIMAL(3, 2) DEFAULT 0.5,
    opportunity_score INTEGER DEFAULT 0,  -- 0-100
    risk_score INTEGER DEFAULT 50,
    stage VARCHAR(20) DEFAULT 'discovery', -- discovery/watch/entry/active/exit
    related_thesis_id INTEGER REFERENCES theses(id),
    related_tickers JSONB DEFAULT '[]',
    analysis_summary TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 报告表
CREATE TABLE reports (
    id SERIAL PRIMARY KEY,
    report_type VARCHAR(50) NOT NULL,  -- daily/weekly/opportunity/industry
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    summary TEXT,
    key_points JSONB DEFAULT '[]',
    related_tickers JSONB DEFAULT '[]',
    related_industries JSONB DEFAULT '[]',
    confidence_overall DECIMAL(3, 2) DEFAULT 0.5,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Agent运行日志表
CREATE TABLE agent_runs (
    id SERIAL PRIMARY KEY,
    agent_name VARCHAR(100) NOT NULL,
    run_type VARCHAR(50),         -- analysis/debate/consensus
    input_context JSONB DEFAULT '{}',
    output_result JSONB DEFAULT '{}',
    confidence DECIMAL(3, 2),
    execution_time_ms INTEGER,
    status VARCHAR(20) DEFAULT 'success',
    created_at TIMESTAMP DEFAULT NOW()
);

-- 用户配置表（个人使用）
CREATE TABLE user_config (
    id SERIAL PRIMARY KEY,
    watchlist JSONB DEFAULT '[]',       -- 关注列表 [{ticker, market, reason}]
    portfolio JSONB DEFAULT '[]',       -- 持仓 [{ticker, market, quantity, cost}]
    industries_focus JSONB DEFAULT '[]', -- 关注行业
    macro_indicators_focus JSONB DEFAULT '[]', -- 关注宏观指标
    risk_level VARCHAR(20) DEFAULT 'medium',
    report_schedule VARCHAR(20) DEFAULT 'daily',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### 4.2 Qdrant Collections

```
Collection: industry_docs
  - 行业研究报告、分析文档的向量索引
  - Payload: {industry_name, source, date, confidence}

Collection: company_docs
  - 公司分析、财报要点的向量索引
  - Payload: {ticker, market, source, date}

Collection: event_docs
  - 事件描述、影响分析的向量索引
  - Payload: {event_type, impact_level, date}

Collection: thesis_docs
  - 投资逻辑、论点的向量索引
  - Payload: {thesis_id, status, confidence}

Collection: macro_docs
  - 宏观分析文档的向量索引
  - Payload: {indicator_type, country, date}
```

## 5. 核心接口定义

### 5.1 FastAPI路由

```python
# /app/api/data.py
@router.get("/api/data/macro")
async def get_macro_indicators(indicator_type: str = None, country: str = None)

@router.get("/api/data/stock/{ticker}")
async def get_stock_data(ticker: str, market: str, period: str = "1y")

@router.get("/api/data/market/summary")
async def get_market_summary()

# /app/api/news.py
@router.get("/api/news")
async def get_news(category: str = None, limit: int = 20, processed: bool = None)

@router.get("/api/news/{news_id}/events")
async def get_news_events(news_id: int)

# /app/api/kb.py
@router.get("/api/kb/industries")
async def get_industries()

@router.get("/api/kb/industries/{industry_id}")
async def get_industry_detail(industry_id: int)

@router.put("/api/kb/industries/{industry_id}")
async def update_industry(industry_id: int, data: IndustryUpdate)

@router.get("/api/kb/companies")
async def get_companies(industry_id: int = None)

@router.get("/api/kb/companies/{company_id}")
async def get_company_detail(company_id: int)

@router.put("/api/kb/companies/{company_id}")
async def update_company(company_id: int, data: CompanyUpdate)

# /app/api/thesis.py
@router.get("/api/thesis")
async def get_theses(status: str = None, industry: str = None)

@router.post("/api/thesis")
async def create_thesis(data: ThesisCreate)

@router.get("/api/thesis/{thesis_id}/evidence")
async def get_thesis_evidence(thesis_id: int)

# /app/api/report.py
@router.get("/api/reports")
async def get_reports(report_type: str = None, limit: int = 10)

@router.get("/api/reports/{report_id}")
async def get_report_detail(report_id: int)

@router.post("/api/reports/generate/daily")
async def generate_daily_report()

@router.post("/api/reports/generate/opportunity")
async def generate_opportunity_report()

# /app/api/agent.py
@router.post("/api/agent/analyze")
async def trigger_analysis(analysis_type: str, context: dict = None)

@router.post("/api/agent/committee/debate")
async def trigger_committee_debate(topic: str, context: dict = None)

@router.get("/api/agent/runs")
async def get_agent_runs(agent_name: str = None, limit: int = 20)
```

### 5.2 数据采集器接口

```python
# /app/data_collection/collectors/base.py
class BaseCollector(ABC):
    @abstractmethod
    async def collect(self, **kwargs) -> List[Dict]:
        """执行数据采集，返回原始数据列表"""
    
    @abstractmethod
    def get_name(self) -> str:
        """返回采集器名称"""

# /app/data_collection/processors/base.py
class BaseProcessor(ABC):
    @abstractmethod
    async def process(self, raw_data: List[Dict]) -> List[Dict]:
        """处理原始数据，返回结构化数据"""
```

### 5.3 Agent接口

```python
# /app/agents/agent_configs.py
class AgentConfig:
    name: str                    # Agent名称
    role: str                    # 角色描述
    prompt_file: str            # 提示词文件路径
    model: str                  # 使用的LLM模型
    temperature: float          # 温度参数
    memory_type: str            # 记忆类型
    expertise: List[str]        # 专业领域

# /app/agents/committee.py
class CommitteeOrchestrator:
    async def run_debate(self, topic: str, context: dict) -> CommitteeReport:
        """运行委员会辩论流程"""
    
    async def run_daily_pipeline(self) -> DailyReport:
        """运行每日分析流水线"""

@dataclass
class CommitteeReport:
    topic: str
    conclusion: str
    probability: float
    supporting_views: List[str]
    opposing_views: List[str]
    max_risk: str
    action_suggestion: str
    agent_contributions: List[AgentContribution]
    created_at: datetime
```

## 6. Agent集群设计

### 6.1 Agent角色定义

| Agent名称 | 角色 | 职责 | 分析维度 |
|-----------|------|------|---------|
| macro_analyst | 宏观分析师 | 分析宏观环境，判断周期位置 | 利率、CPI、PMI、流动性、汇率 |
| industry_analyst | 行业分析师 | 分析行业景气度和产业链 | 景气度、增速、生命周期、竞争格局 |
| supply_chain_analyst | 产业链分析师 | 分析产业链传导和瓶颈 | 上下游关系、瓶颈节点、替代方案 |
| scarcity_analyst | 稀缺性分析师 | 寻找稀缺资源和预期差 | 供需缺口、卡脖子、未定价因素 |
| company_analyst | 公司分析师 | 分析具体公司 | 商业模式、护城河、估值、风险 |
| sentiment_analyst | 情绪分析师 | 分析市场情绪 | FOMO、恐慌、散户/机构行为 |
| risk_analyst | 风险分析师 | 识别风险 | 估值、政策、流动性、周期风险 |
| devil_advocate | 反驳者 | 专门反驳所有正面观点 | 寻找漏洞、反例、替代解释 |
| cio_synthesizer | CIO汇总者 | 综合所有观点，输出最终判断 | 加权评分、概率估计、操作建议 |

### 6.2 委员会工作流（LangGraph）

```
阶段1: 独立分析（并行）
  [Input: 主题/事件/机会]
    ├── macro_analyst → MacroAnalysis
    ├── industry_analyst → IndustryAnalysis
    ├── supply_chain_analyst → SupplyChainAnalysis
    ├── scarcity_analyst → ScarcityAnalysis
    ├── company_analyst → CompanyAnalysis
    ├── sentiment_analyst → SentimentAnalysis
    └── risk_analyst → RiskAnalysis

阶段2: 交叉质询（并行）
  [Input: 所有独立分析结果]
    ├── devil_advocate 阅读所有分析 → DevilReport（反驳意见）
    └── risk_analyst 阅读所有分析 → RiskAssessment（综合风险评估）

阶段3: 共识合成（串行）
  [Input: 所有分析 + 反驳 + 风险]
    └── cio_synthesizer → CommitteeReport（最终报告）

阶段4: 报告生成
  [Input: CommitteeReport]
    └── report_generator → 结构化Markdown报告
```

### 6.3 Agent提示词核心要求

每个Agent的提示词必须包含：
1. **角色定义**: 你是谁，你的专业领域
2. **输入格式**: 你会收到什么数据
3. **分析框架**: 你的分析方法和思考步骤
4. **输出格式**: 必须输出JSON格式的结构化结论
5. **约束**: 禁止跳过证据、禁止直接下结论、必须考虑反例

### 6.4 CIO汇总Agent的加权逻辑

```python
# 初始权重（可根据历史表现调整）
AGENT_WEIGHTS = {
    "macro_analyst": 0.15,
    "industry_analyst": 0.20,
    "supply_chain_analyst": 0.15,
    "scarcity_analyst": 0.15,
    "company_analyst": 0.10,
    "sentiment_analyst": 0.05,
    "risk_analyst": 0.10,
    "devil_advocate": 0.10,  # 反驳意见作为负权重
}

# 加权评分公式
weighted_score = sum(
    agent.confidence * agent.recommendation_score * AGENT_WEIGHTS[agent.name]
    for agent in agents
) - devil_advocate.impact_score * AGENT_WEIGHTS["devil_advocate"]
```

## 7. 定时任务设计

```python
# /app/data_collection/scheduler_tasks.py

TASKS = {
    # 宏观数据 - 每日早8点
    "macro_daily": {
        "collector": "macro_collector",
        "schedule": "cron",  # 每天 08:00
        "targets": ["US_Fed_Funds_Rate", "CPI_US", "CPI_China", "PMI_China", 
                     "US_10Y_Yield", "DXY", "USD_CNY"]
    },
    
    # 个股行情 - 收盘后
    "stock_eod": {
        "collector": "stock_collector",
        "schedule": "cron",  # 每天 16:30 (美股收盘后)
        "targets": ["watchlist + portfolio tickers"]
    },
    
    # 新闻采集 - 每4小时
    "news_regular": {
        "collector": "news_collector",
        "schedule": "interval",  # 每4小时
        "sources": ["财联社", "Reuters", "华尔街见闻"]
    },
    
    # 每日报告生成 - 早9点
    "daily_report": {
        "action": "generate_daily_report",
        "schedule": "cron",  # 每天 09:00
    },
    
    # 机会扫描 - 每周一
    "opportunity_scan": {
        "action": "generate_opportunity_report",
        "schedule": "cron",  # 每周一 09:30
    }
}
```

## 8. 数据采集源

### 8.1 宏观数据
- **美国**: FRED API (联邦基金利率、CPI、PMI、国债收益率)
- **中国**: 手动录入或通过数据源获取 (CPI、PMI、社融)
- **汇率**: yahoo_finance API (DXY、USD/CNY)

### 8.2 个股数据
- **美股**: yahoo_finance API
- **港股**: yahoo_finance API
- **A股**: 备选数据源

### 8.3 新闻
- **数据源**: Web搜索 + 网页抓取
- **采集方式**: 通过搜索引擎API定期搜索关键词
- **关键词**: 关注的行业、公司、宏观主题

## 9. 初始知识库内容

### 9.1 预置行业（7个）
AI、机器人、稳定币、电力、半导体、消费电子、新能源汽车

### 9.2 预置公司（首批）
美股: NVDA, TSLA, AAPL, MSFT, GOOGL, META, AMD, COIN
港股: 0700.HK, 9988.HK, 1211.HK, 1810.HK
A股: 比亚迪、宁德时代、中芯国际、贵州茅台

### 9.3 预置宏观指标
US_Fed_Funds_Rate, CPI_US, CPI_China, PMI_China, PMI_US, 
US_10Y_Yield, US_2Y_Yield, DXY, USD_CNY, US_M2

## 10. 报告模板

### 10.1 日报
```markdown
# IWM 投资参谋日报 - {date}

## 1. 市场概况
- A股: {summary}
- 港股: {summary}
- 美股: {summary}
- 风险等级: {level}

## 2. 今日重点事件（Top 5）
{events}

## 3. 持仓影响分析
{portfolio_impact}

## 4. 关注标的动态
{watchlist_updates}

## 5. 新发现机会
{new_opportunities}

## 6. 风险提示
{risk_alerts}

## 7. Agent委员会观点摘要
{committee_summary}

---
生成时间: {timestamp}
```

### 10.2 机会分析报告
```markdown
# 机会分析: {opportunity_title}

## 核心逻辑
{thesis}

## 支持观点
{supporting_views}

## 反对观点（Devil's Advocate）
{opposing_views}

## 产业链分析
{supply_chain}

## 稀缺性评估
{scarcity_assessment}

## 风险评估
{risk_assessment}

## 概率估计
{probability}

## 操作建议
{action_suggestion}

## 置信度: {confidence}/1.0
```

## 11. 配置管理

### 11.1 环境变量 (.env)
```
# 数据库
POSTGRES_URL=postgresql://user:pass@localhost/iwm
QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_COLLECTION=iwm

# API
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-...
TAVILY_API_KEY=tvly-...

# 服务
API_PORT=8000
LOG_LEVEL=INFO
```

### 11.2 系统配置 (config.yaml)
```yaml
# 数据采集配置
data_collection:
  macro:
    indicators:
      - name: US_Fed_Funds_Rate
        source: yahoo_finance
        frequency: daily
      - name: US_CPI
        source: web_search
        frequency: monthly
  news:
    keywords:
      - "AI artificial intelligence"
      - "semiconductor chip"
      - "Federal Reserve interest rate"
      - "China economy"
    sources:
      - reuters
      - bloomberg
      - 财联社
    max_articles_per_run: 20

# Agent配置
agents:
  macro_analyst:
    model: gpt-4o
    temperature: 0.3
  industry_analyst:
    model: gpt-4o
    temperature: 0.3
  devil_advocate:
    model: gpt-4o
    temperature: 0.5
  cio_synthesizer:
    model: gpt-4o
    temperature: 0.2

# 报告配置
reports:
  daily:
    max_events: 10
    max_opportunities: 5
  opportunity:
    min_score_threshold: 60
```

## 12. 实现优先级

### Phase 1: 骨架（Sprint 1）
1. PostgreSQL数据库 + 所有表
2. FastAPI API层
3. 基础CRUD服务
4. 配置管理

### Phase 2: 数据采集（Sprint 2）
1. 宏观数据采集器
2. 个股数据采集器
3. 新闻采集器
4. 定时任务调度器

### Phase 3: 知识库（Sprint 3）
1. 行业知识库初始化
2. 公司知识库初始化
3. Thesis管理
4. Qdrant向量存储

### Phase 4: Agent集群（Sprint 4）
1. 9个Agent提示词和配置
2. LangGraph工作流
3. 委员会辩论流程
4. 报告生成器

### Phase 5: 整合验证（Sprint 5）
1. 日报生成端到端测试
2. 委员会分析验证
3. 性能优化
4. 个人使用调优

## 13. 质量标准

- **数据新鲜度**: 宏观数据当日更新，行情数据收盘后更新，新闻4小时内
- **Agent响应时间**: 单Agent分析 < 30秒，完整委员会 < 5分钟
- **报告质量**: 包含证据引用、概率估计、风险提示、反面观点
- **可用性**: 个人启动系统后，每日自动生成报告到本地文件
